# Pass 3 intermediate handoff —origin ledger context freeze pending

Ogent now provides named versioned tool calls, complete bounded read/search
pages, guarded continuation, read-only batching, asynchronous result delivery,
live schemas/examples, optional model JSON and actual build/test JSON. If terminal
ledger storage fails after effects complete, callers receive retained tool data
and a storage error with advice not to rerun effects merely to repair the ledger.

The user's second full implementation batch ships eleven tested production
behavior upgrades on `master` inside `/workspace/ogent`. Baseline is
`b3caf9300c7336ef812ed061158f851c5a47ccf7`; intermediate production snapshot is `10f86bb12a03f3122a60ba085be7289eb5277f5e`; the origin-context final freeze is pending. No branch, PR, provider
authentication or inference was used. This document records completed evidence
and explicitly unfinished delivery gates.

## What changed

| ID | Implemented behavior | Primary commit | Regression wrapper |
|---|---|---|---|
| R013 | Named approval-aware calls with typed outcomes | `2fbc156` | `audit/regression_tests/R013__named_calls.test.sh` |
| R014 | Bounded file pages with exact long-line continuation | `0829b08` | `audit/regression_tests/R014__structured_reads.test.sh` |
| R015 | Complete discovery through structured file pagination | `a1793a8` | `audit/regression_tests/R015__complete_glob_pages.test.sh` |
| R016 | Follow guarded tool continuations in one call | `e9c9af4` | `audit/regression_tests/R016__continuation_calls.test.sh` |
| R017 | Familiar exact verbs with collision-safe policy resolution | `a2b3922` | `audit/regression_tests/R017__common_verbs.test.sh` |
| R018 | Structured search and bounded real process outcomes | `1cde7ab` | `audit/regression_tests/R018__structured_processes.test.sh` |
| R019 | Async agent calls with one precise terminal callback and ledger | `3ced858` | `audit/regression_tests/R019__async_sdk.test.sh` |
| R020 | Preflighted batches of declared read-only calls | `974eb31` | `audit/regression_tests/R020__read_only_batches.test.sh` |
| R021 | Live callable contracts, executable examples and result schema | `d6263d1` | `audit/regression_tests/R021__live_contracts.test.sh` |
| R022 | Structured JSON contracts for registered model tools | `66bc5e8` | `audit/regression_tests/R022__model_json_contract.test.sh` |
| R023 | Actual build/test JSON with typed failures and recovery | `b974cd7` | `audit/regression_tests/R023__actual_build_reports.test.sh` |


Versioned named calls, complete bounded file/search pages and guarded continuations
let agents consume results without parsing presentation text or guessing restart
positions. Real process outcomes separate channels, exit/timeout/cancellation and
retained partial output. Async callbacks and read-only batches share the existing
approval/review/ledger owners. Live descriptions/examples/schema expose real call
shapes; optional model JSON and actual makem JSON extend explicit contracts.

Followups include frozen arguments/targets and object hash content, schema cache
refresh, Unicode ripgrep candidate groups, correct structured history replay/status,
JSON-safe boundary failures and compiler EOF/source locations. They remain part
of the original eleven changes, not additional recommendation counts.

## Paired measurements and final refresh

Completed paired calibration for intermediate `10f86bb` compares 19 original
surfaces with genuine b3caf93: mean **605.26 → 656.21**, all-surface median
**+11**, and median **77.5** over the ten positively changed originals. Nine
original surfaces gain at least 100 points on a dimension. No paired surface or
dimension regresses. Six new APIs remain unpaired current-only records, excluded
from the mean. All A/B/third readings and root aggregation are complete for this
snapshot, without inventing measurements of the future origin-context fix.

Eleven tested behavior upgrades overlap surfaces; they are not eleven uniquely
caused numerical gains. Historical pass 1/2's 38 original rows preserve exact
JSON values against b3caf93, and historical scorecard/heatmap bytes are unchanged.
`evidence/pass_3/triangulation/aggregation.json` records the intermediate10f
arithmetic. `rubric_reconciliation_pass_3.md` retains applicability/third-reading
decisions. Paired artifacts use baseline pass 3/current pass 4; these pass_3
files identify the implementation batch. Prior967 scoring/audit states are in
`evidence/pass_3/interim_967eb05_scoring.tar.gz`,
`evidence/pass_3/interim_967eb05_audit.tar.gz`, and
`evidence/pass_3/interim_967eb05_archive.json`. Root will archive the complete
10f snapshot before a later production freeze is introduced.


Build JSON credit is limited to historical help/compile/recompile and new
lint/test/runner extension coverage. The unchanged offline-test target receives
no build-JSON output credit.

## Completed proof and pending promotion gates

Intermediate production snapshot is `10f86bb12a03f3122a60ba085be7289eb5277f5e`; the origin-context final freeze is pending. Source/test-only correction
`967eb05` belongs to R018. GNU and ripgrep now share metadata-selected sorted
files, include file-link paths, and skip descendant directory links. Selected
non-UTF-8 filenames fail explicitly; excluded file contents are not opened.
Raw-NUL binary classification, including late NUL and UTF BOM cases, runs inside
the owned async process before matching/counting. Ripgrep receives exact ordered
file argv in 128-name batches, without JSON path remapping or new dependencies.

The deliberate cost is a per-file classifier read plus a second read of text
candidates, all under the existing process timeout/cancel/cleanup owner.
Focused SDK/process/debug suites pass 193 tests (43/51/99) on Emacs 29/30;
style/checkdoc and warning-gated compilation also pass. Full native checks remain
separate.

Intermediate source snapshot is `10f86bb12a03f3122a60ba085be7289eb5277f5e`. Commit10f86bb repairs the
accepted round7 callback defect. Terminal ledger recording is attempted once;
a storage error produces `ledger_write_failed` with retained completed tool data.
An existing tool failure is preserved as `error.tool_error`. Recovery says effects
already completed, directs callers to inspect retained data and choose a writable
ledger file for future calls, and warns against rerunning effects merely to repair
storage. Legacy text/UI paths retain output and show the warning. A failed finish
write cannot certify persisted ledger completion; start recording must still
succeed before effects. Terminal result-construction failures likewise deliver
a typed retained result rather than suppressing the callback.

`evidence/pass_3/ledger_recovery/results.json` records source-forced210/210 focused
tests plus4/4 existing UI tests on both Emacs29/30, zero skipped/unexpected in the
focused suites, and scoped style/checkdoc/warning-gated compilation. This is
focused validation, not the final full native matrix. The familiar final_freeze
replay completed9/9 at10f86bb in89 round trips; it is not a fresh exercise.

The `verification/pass_3/regression_proof.json` is complete: all11 genuine
baseline failures/current passes are proven at intermediate10f86bb. Expected current counts are R01351 SDK tests,
R01853 (51 process+2 integration), and R02323 actual shell-runner cases. The
fully valid967 proof is archived in
`verification/pass_3/regressions/interim-967eb05/`. Do not relabel that evidence
as10f86bb proof, add overlapping selectors, or mix ERT and shell count units.

The reviewed10f86bb snapshot is **intermediate**. Round8 reported a new P2,
accepted by the integration owner: a default relative ledger path is resolved
again from ambient `default-directory` at async completion, so a project switch
can split the start and finish across different ledgers while the caller receives
status `ok`. The origin-context repair and its new source freeze are pending.
The completed report is `phase7_pass_3_review_round8.md`, with direct evidence
under `evidence/pass_3/review_round8/`. No future repair is claimed here.

Round8 is **NOT_CLEAN**. Prior round5 was clean, but rounds6/7/8 break the clean
streak. After the new origin-context freeze, **PENDING_REVIEW_ROUND_9** and
**PENDING_REVIEW_ROUND_10** must run clean consecutively. Full native validation
remains **PENDING_FINAL_NATIVE_REPORT**, and root delivery/CI remains
**PENDING_ROOT_FINAL_VALIDATION_AND_DELIVERY**. This artifact state is paused
for archival until explicit followup; completed10f tests/scores/proofs remain
valid evidence for that intermediate source, not certification of a later fix.


| Gate | Current result |
|---|---|
| Intermediate production source | `10f86bb12a03f3122a60ba085be7289eb5277f5e` |
| Shared paired measurements | Intermediate10f:605.26→656.21, median+11; future source pending |
| Positively changed originals | Intermediate10f:ten, median77.5 |
| ≥100-point dimensional gains | Intermediate10f:nine original surfaces; no unique per-commit attribution |
| New API measurements | Six current-only records; separate from paired uplift |
| R013…R023 baseline/current proofs | All11 proven at intermediate10f86bb; future freeze needs new proof |
| Fresh source-blind tasks | 9/9 completed, 7/9 first strategy, 94 defined round trips on historical revisions |
| Final-freeze repeated regression tasks | 9/9 completed, 89 round trips; familiarity prevents fresh-discovery/efficiency claims |
| Prior reviews 5/6 | Round 5 clean at9ac; round 6 unclean breaks streak |
| New clean-review gate | Round8 NOT_CLEAN; new origin-context freeze then clean9/10 required |
| Full supported-version native tests/lint/offline/isolation | **PENDING_FINAL_NATIVE_REPORT** |
| Root final validation, commit/delivery and CI | **PENDING_ROOT_FINAL_VALIDATION_AND_DELIVERY** |

Initial native lint failed before correction. Initial and invalidated-freeze
proofs remain intermediate evidence; they cannot stand for final native checks.
The archived967 proof has no skipped current ERT cases or timeouts. Its R023 shell cases use a
different count unit, and the broad R013 selector overlaps later wrappers.

## Practical task evidence and limits

The original fresh source-blind exercise completed **9/9** tasks, **7/9** with
the first strategy, in **94** public round trips, mostly at `07f775a` with batch `895bed7`.
The seven-line README exercise accounts for 63 calls. Its preserved
`agent_simulations/post_pass_3/summary.json` supports no comparative efficiency
claim.

The familiar `10f86bb` repeated replay completed **9/9** tasks in **89** round trips,
with identical start/end SHA. It reused workflows/fixtures, so gets no fresh
first-strategy or efficiency metric. See
`agent_simulations/post_pass_3/final_freeze/summary.json`; prior967 replay is archived under `replay_967eb05/`.
Both observed GNU fallback, a protected helper that can supply gptel doubles,
and isolated builds. Neither certifies live provider transport or full native
checks. No provider login/inference occurred.


## Durable artifacts and next operator

- `recommendations_pass_3.jsonl`: exactly R013…R023, primary commits/Beads,
  intended dimensions, source references and global numeric-attribution limits.
- `applied_changes_pass_3.jsonl`: 33 exact selected source hunks and line
  coordinates, full followup SHAs, baseline/freeze proof paths and case units.
- `recommendation_hunks_pass_3.md`: readable primary-commit source hunks and
  final evidence/status appendix. Primary hunks compare each commit to its parent.
- `playbook_pass_3.md`: verification method, review corrections, replay and limits.
- `ambition_bar_pass_3.md`: mandatory verbatim self-prompt, eleven qualitative
  upgrades versus nine numeric original surfaces, and honest median-uplift limits.
- `phase7_pass_3_review_initial.md` and round 2/3/4 reports: real findings,
  corrected in followups; no clean streak certification.

The integration owner handles root manifest/HANDOFF reconciliation, main score
promotion, final validation, source archives, staging/commits, delivery and CI.
This evidence writer does not edit production/tests, stage or commit files.
When final review/native reports arrive, replace pending fields only with actual
freeze-bound results. Any substantive finding requires a corrected new freeze
and rerunning dependent verification; preserve the same eleven recommendation IDs.

## Source archive and scope boundaries

Raw baseline source and isolated build/test fixtures under audit evidence must
stay out of tracked `.el` discovery: `makem.sh` uses `git ls-files`. The integration
owner controls exact ignore exclusions and source archives after writers finish;
these reporting files do not move, gzip or stage live scorer inputs. Baseline
source is reproducible with `git archive b3caf9300c7336ef812ed061158f851c5a47ccf7 lisp makem.sh`; the recorder
checks extracted bytes against Git and retains source hash manifests. Cite any
final archive index only after its members and hashes are recorded.


Persistent resume tokens, dependent batches and transport redesign remain future
features. Fuzzy guesses are not auto-executed. Unsupported undecodable filenames
fail explicitly; snapshot guards do not promise filesystem transactions. No
provider transport, latency or comparative efficiency claim is supported.

10f integrity verification and all six recorder controls pass for this intermediate
snapshot. Its complete wrapper proof records source/fixture identities, selected
execution, zero skips/timeouts and actual exits; future source remains uncertified.

# Pass 3 implementation playbook —10f86bb intermediate state

This is the user's second full implementation batch. Scope is the existing
local tool/SDK/build surfaces: call, inspect, continue, compose and diagnose them.
Work lands directly on `master` inside `/workspace/ogent`; no branch, PR,
provider authentication or inference belongs to this pass.

## Implemented recommendations

| ID | Implemented behavior | Primary commit | Regression wrapper |
|---|---|---|---|
| R013 | Named approval-aware calls with typed outcomes | `2fbc156` | `audit/regression_tests/R013__named_calls.test.sh` |
| R014 | Bounded file pages with exact long-line continuation | `0829b08` | `audit/regression_tests/R014__structured_reads.test.sh` |
| R015 | Complete discovery through structured file pagination | `a1793a8` | `audit/regression_tests/R015__complete_glob_pages.test.sh` |
| R016 | Follow guarded tool continuations in one call | `e9c9af4` | `audit/regression_tests/R016__continuation_calls.test.sh` |
| R017 | Familiar exact verbs with collision-safe policy resolution | `a2b3922` | `audit/regression_tests/R017__common_verbs.test.sh` |
| R018 | Structured search and bounded real process outcomes | `1cde7ab` | `audit/regression_tests/R018__structured_processes.test.sh` |
| R019 | Async agent calls with one precise terminal callback and ledger | `3ced858` | `audit/regression_tests/R019__async_sdk.test.sh` |
| R020 | Preflighted batches of declared read-only calls | `974eb31` | `audit/regression_tests/R020__read_only_batches.test.sh` |
| R021 | Live callable contracts, executable examples and result schema | `d6263d1` | `audit/regression_tests/R021__live_contracts.test.sh` |
| R022 | Structured JSON contracts for registered model tools | `66bc5e8` | `audit/regression_tests/R022__model_json_contract.test.sh` |
| R023 | Actual build/test JSON with typed failures and recovery | `b974cd7` | `audit/regression_tests/R023__actual_build_reports.test.sh` |


Eleven distinct production behaviors landed through eleven primary Conventional
Commits. Exact parent/current source coordinates and 33 complete selected hunks
are in `applied_changes_pass_3.jsonl` and `recommendation_hunks_pass_3.md`.
Those primary hunks preserve the implementation trail; final behavior also
includes the followup fixes listed in the applied ledger. Tests, whitespace,
documentation-only commits and correction followups do not increase the count.
The retrospective `priority: 0` field is explicitly unranked; empty expected
uplift maps avoid inventing ex ante estimates.

## Paired measurements and final refresh

Completed paired calibration for intermediate `10f86bb` compares 19 original
surfaces with genuine b3caf93: mean **605.26 → 656.21**, all-surface median
**+11**, and median **77.5** over the ten positively changed originals. Nine
original surfaces gain at least 100 points on a dimension. No paired surface or
dimension regresses. Six new APIs remain unpaired current-only records, excluded
from the mean. All A/B/third readings and root aggregation are complete for this
snapshot, without inventing measurements of the future origin-context fix.

Eleven tested behavior upgrades overlap surfaces; they are not eleven uniquely
caused numerical gains. Historical pass 1/2's 38 original rows preserve exact
JSON values against b3caf93, and historical scorecard/heatmap bytes are unchanged.
`evidence/pass_3/triangulation/aggregation.json` records the intermediate10f
arithmetic. `rubric_reconciliation_pass_3.md` retains applicability/third-reading
decisions. Paired artifacts use baseline pass 3/current pass 4; these pass_3
files identify the implementation batch. Prior967 scoring/audit states are in
`evidence/pass_3/interim_967eb05_scoring.tar.gz`,
`evidence/pass_3/interim_967eb05_audit.tar.gz`, and
`evidence/pass_3/interim_967eb05_archive.json`. Root will archive the complete
10f snapshot before a later production freeze is introduced.


Build JSON attribution covers historical make help/compile/recompile. Newly
supported lint/test and runner JSON are extension coverage. The unchanged
`make offline-test` target receives no build-JSON output credit; offline checks
validate actual local dependency integration.

## Verification and remaining gates

Intermediate production snapshot is `10f86bb12a03f3122a60ba085be7289eb5277f5e`; the origin-context final freeze is pending. Source/test-only correction
`967eb05` belongs to R018. GNU and ripgrep now share metadata-selected sorted
files, include file-link paths, and skip descendant directory links. Selected
non-UTF-8 filenames fail explicitly; excluded file contents are not opened.
Raw-NUL binary classification, including late NUL and UTF BOM cases, runs inside
the owned async process before matching/counting. Ripgrep receives exact ordered
file argv in 128-name batches, without JSON path remapping or new dependencies.

The deliberate cost is a per-file classifier read plus a second read of text
candidates, all under the existing process timeout/cancel/cleanup owner.
Focused SDK/process/debug suites pass 193 tests (43/51/99) on Emacs 29/30;
style/checkdoc and warning-gated compilation also pass. Full native checks remain
separate.

Intermediate source snapshot is `10f86bb12a03f3122a60ba085be7289eb5277f5e`. Commit10f86bb repairs the
accepted round7 callback defect. Terminal ledger recording is attempted once;
a storage error produces `ledger_write_failed` with retained completed tool data.
An existing tool failure is preserved as `error.tool_error`. Recovery says effects
already completed, directs callers to inspect retained data and choose a writable
ledger file for future calls, and warns against rerunning effects merely to repair
storage. Legacy text/UI paths retain output and show the warning. A failed finish
write cannot certify persisted ledger completion; start recording must still
succeed before effects. Terminal result-construction failures likewise deliver
a typed retained result rather than suppressing the callback.

`evidence/pass_3/ledger_recovery/results.json` records source-forced210/210 focused
tests plus4/4 existing UI tests on both Emacs29/30, zero skipped/unexpected in the
focused suites, and scoped style/checkdoc/warning-gated compilation. This is
focused validation, not the final full native matrix. The familiar final_freeze
replay completed9/9 at10f86bb in89 round trips; it is not a fresh exercise.

The `verification/pass_3/regression_proof.json` is complete: all11 genuine
baseline failures/current passes are proven at intermediate10f86bb. Expected current counts are R01351 SDK tests,
R01853 (51 process+2 integration), and R02323 actual shell-runner cases. The
fully valid967 proof is archived in
`verification/pass_3/regressions/interim-967eb05/`. Do not relabel that evidence
as10f86bb proof, add overlapping selectors, or mix ERT and shell count units.

The reviewed10f86bb snapshot is **intermediate**. Round8 reported a new P2,
accepted by the integration owner: a default relative ledger path is resolved
again from ambient `default-directory` at async completion, so a project switch
can split the start and finish across different ledgers while the caller receives
status `ok`. The origin-context repair and its new source freeze are pending.
The completed report is `phase7_pass_3_review_round8.md`, with direct evidence
under `evidence/pass_3/review_round8/`. No future repair is claimed here.

Round8 is **NOT_CLEAN**. Prior round5 was clean, but rounds6/7/8 break the clean
streak. After the new origin-context freeze, **PENDING_REVIEW_ROUND_9** and
**PENDING_REVIEW_ROUND_10** must run clean consecutively. Full native validation
remains **PENDING_FINAL_NATIVE_REPORT**, and root delivery/CI remains
**PENDING_ROOT_FINAL_VALIDATION_AND_DELIVERY**. This artifact state is paused
for archival until explicit followup; completed10f tests/scores/proofs remain
valid evidence for that intermediate source, not certification of a later fix.


Initial native lint failed before correction. Earlier native outputs and proofs
at invalidated `3cb0cd7`/`90818f8` remain intermediate evidence. Never relabel
them as final freeze checks. Source/fixture identities in the final proof distinguish
real baseline failures from timeouts, missing selections or invented stubs.

## Review-driven corrections

The initial review drove bounded descendant stderr drains, post-approval registry
replacement checks, failure-aware ledger terminals, component-safe glob stars,
empty-candidate regex validation and final-newline metadata. Round 2 drove
in-place metadata snapshots, JSON-safe unsupported filenames with callback-once
completion, smaller configured read defaults, explicit-file search filter parity
and structured debug history replay/error/status plus actual JSON history arrays.
Round 3 drove frozen batch tool/argument plans and shared component/recursive
filter rules. Round 4 drove copied supported object hash tables, deep metadata
content comparison, nested model schema cache refresh and Unicode wildcard
candidate parity. Existing focused suites passed before these additional probes
found real defects; review breadth matters independently of test count.

Shared corrections include `a820ac0`, `07f775a`, `0d2fea6`, `7c0d9d8`,
`895bed7`, `0f7273e`, `8e93242`, `5b0f158`, `3cb0cd7`, `ed044fb`,
`19f154a`, `90818f8`, `08dfaad`, `a99000d`, `9ac13b2`, and `967eb05`. The applied
ledger stores full SHAs and relevant mappings; none is a twelfth recommendation.

## Practical task evidence

The original fresh source-blind exercise completed **9/9** tasks, **7/9** with
the first strategy, in **94** public round trips, mostly at `07f775a` with batch `895bed7`.
The seven-line README exercise accounts for 63 calls. Its preserved
`agent_simulations/post_pass_3/summary.json` supports no comparative efficiency
claim.

The familiar `10f86bb` repeated replay completed **9/9** tasks in **89** round trips,
with identical start/end SHA. It reused workflows/fixtures, so gets no fresh
first-strategy or efficiency metric. See
`agent_simulations/post_pass_3/final_freeze/summary.json`; prior967 replay is archived under `replay_967eb05/`.
Both observed GNU fallback, a protected helper that can supply gptel doubles,
and isolated builds. Neither certifies live provider transport or full native
checks. No provider login/inference occurred.


## Evidence source archiving and build discovery

Raw baseline source and isolated build/test fixtures under audit evidence must
stay out of tracked `.el` discovery: `makem.sh` uses `git ls-files`. The integration
owner controls exact ignore exclusions and source archives after writers finish;
these reporting files do not move, gzip or stage live scorer inputs. Baseline
source is reproducible with `git archive b3caf9300c7336ef812ed061158f851c5a47ccf7 lisp makem.sh`; the recorder
checks extracted bytes against Git and retains source hash manifests. Cite any
final archive index only after its members and hashes are recorded.


## Next operator workflow and scope

Use `ogent-agent-describe`, capabilities and the guide for live call shapes.
Use `ogent-agent-call` for named policy-aware execution, `ogent-agent-next` for
returned guarded continuations, `ogent-agent-call-async` for process callbacks,
and `ogent-agent-batch` for at most 20 declared read-only calls. Select JSON
explicitly for SDK output or registered model tools. Actual build JSON uses
`makem.sh --json` or `make TASK format=json`; doctor is a different surface.

Read the regression recorder's `--help` before replay. Bind the recorded final
freeze and actual portable ripgrep path from its runtime manifest; do not assume
the host tools. Run full native checks only with supported Emacs versions and
actual local dependencies. Providers remain outside this task.

Persistent crash-resume tokens, dependent batches and transport redesign remain
future feature work. Exact aliases do not automatically execute fuzzy guesses.
Unsupported undecodable filenames fail explicitly. Snapshot guards refuse changed
pages without promising filesystem transactions. Any substantive final-review
finding requires correction, a new freeze and rerunning dependent verification.

10f integrity verification and all six recorder controls pass for this intermediate
snapshot. Its complete wrapper proof records source/fixture identities, selected
execution, zero skips/timeouts and actual exits; future source remains uncertified.

# Second-pass score regression investigation

Measured intermediate source: `10f86bb12a03f3122a60ba085be7289eb5277f5e`.
Round 8 found a ledger destination-context defect; repair and a new final
verification freeze are pending. The numerical results below remain valid for
this snapshot and do not negate that behavioral finding.

No paired aggregate surface regresses by more than 50 points. All nineteen
paired surface changes are nonnegative after independently rescoring the
baseline and final production freeze with consistent applicability.

Comparing historical pass 2 directly to pass 4 would mix rubric judgments with
source changes. Primitive method aliases, raw mutation safety, bytecode cleanup
and subprocess variability were interpreted differently. That apparent
regression is not dismissed: the original rows are preserved, genuine archived
baseline probes are rerun, and [paired calibration](rubric_reconciliation_pass_3.md)
records the criteria and dissent. The paired baseline is pass 3; post is pass 4.

Behavioral regression evidence is stronger than numerical scoring: all eleven
recommendation wrappers fail against archived baseline and pass against the
unchanged final source, with selected/executed counts, no skips/timeouts, and
fixture/source hashes checked. See [proof](verification/pass_3/regression_proof.json)
and [independent integrity check](verification/pass_3/regressions/integrity_check.json).
The final replay also completes all nine canonical workflows; it is a repeated
regression run rather than a new blind efficiency comparison.

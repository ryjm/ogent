# Pass 3 ambition-bar record —10f86bb intermediate state

Source: `/home/agent/.claude/skills/agent-ergonomics-and-intuitiveness-maximization-for-cli-tools/SKILL.md`,
“Ambition Bar”, and `references/methodology/PHASES.md`. The user's request for
much more practical value triggered the second full implementation batch.

## Mandatory self-prompt, verbatim

```
That's it?? I was hoping you would get a lot more practical value out of this skill.
Where are the dramatic improvements? Re-read the playbook, look at the surfaces still
scoring below 500 on output_parseability / error_pedagogy / intent_inference /
self_documentation, and ship a substantially larger batch of high-leverage changes.
You're allowed to be ambitious. Default to acting, not deliberating.
```

The self-prompt is applied to the implemented batch and intermediate paired evidence below.
It does not authorize substituting commit count for numerical surface evidence.

## Larger apply round

| ID | Implemented behavior | Primary commit | Regression wrapper |
|---|---|---|---|
| R013 | Named approval-aware calls with typed outcomes | `2fbc156` | `audit/regression_tests/R013__named_calls.test.sh` |
| R014 | Bounded file pages with exact long-line continuation | `0829b08` | `audit/regression_tests/R014__structured_reads.test.sh` |
| R015 | Complete discovery through structured file pagination | `a1793a8` | `audit/regression_tests/R015__complete_glob_pages.test.sh` |
| R016 | Follow guarded tool continuations in one call | `e9c9af4` | `audit/regression_tests/R016__continuation_calls.test.sh` |
| R017 | Familiar exact verbs with collision-safe policy resolution | `a2b3922` | `audit/regression_tests/R017__common_verbs.test.sh` |
| R018 | Structured search and bounded real process outcomes | `1cde7ab` | `audit/regression_tests/R018__structured_processes.test.sh` |
| R019 | Async agent calls with one precise terminal callback and ledger | `3ced858` | `audit/regression_tests/R019__async_sdk.test.sh` |
| R020 | Preflighted batches of declared read-only calls | `974eb31` | `audit/regression_tests/R020__read_only_batches.test.sh` |
| R021 | Live callable contracts, executable examples and result schema | `d6263d1` | `audit/regression_tests/R021__live_contracts.test.sh` |
| R022 | Structured JSON contracts for registered model tools | `66bc5e8` | `audit/regression_tests/R022__model_json_contract.test.sh` |
| R023 | Actual build/test JSON with typed failures and recovery | `b974cd7` | `audit/regression_tests/R023__actual_build_reports.test.sh` |


Eleven tested external behavior upgrades landed through eleven primary commits.
All eleven wrappers genuinely fail on baseline and pass at intermediate10f.
The accepted round8 origin-context finding requires a new source freeze. The count excludes tests, style, docs and correctness followups.

Completed paired calibration for intermediate `10f86bb` compares 19 original
surfaces with genuine b3caf93: mean **605.26 → 656.21**, all-surface median
**+11**, and median **77.5** over the ten positively changed originals. Nine
original surfaces gain at least 100 points on a dimension. No paired surface or
dimension regresses. Six new APIs remain unpaired current-only records, excluded
from the mean. All A/B/third readings and root aggregation are complete for this
snapshot, without inventing measurements of the future origin-context fix.

Eleven tested behavior upgrades overlap surfaces; they are not eleven uniquely
caused numerical gains. Historical pass 1/2's 38 original rows preserve exact
JSON values against b3caf93, and historical scorecard/heatmap bytes are unchanged.
`evidence/pass_3/triangulation/aggregation.json` records the intermediate10f
arithmetic. `rubric_reconciliation_pass_3.md` retains applicability/third-reading
decisions. Paired artifacts use baseline pass 3/current pass 4; these pass_3
files identify the implementation batch. Prior967 scoring/audit states are in
`evidence/pass_3/interim_967eb05_scoring.tar.gz`,
`evidence/pass_3/interim_967eb05_audit.tar.gz`, and
`evidence/pass_3/interim_967eb05_archive.json`. Root will archive the complete
10f snapshot before a later production freeze is introduced.


The skill's numeric substantive-change definition requires at least 100 points
on one dimension. Nine original surfaces meet it at intermediate10f; the six new APIs
have no baseline counterpart. Because recommendations share surfaces, the
ledger does not claim eleven unique per-commit numeric qualifications. The
all-surface median of 11 is also below the self-prompt's 50-point trigger. The
mandatory larger apply round has been completed and its practical/numeric limits
are stated openly; final review/native gates still prevent completion.

## Breadth and required types

At least three dimensions receive concrete work: versioned read/search/process
and real-build JSON improve parseability; continuations/async/batches improve
composability; approval-aware execution and whole-batch preflight improve safety
with recovery. Exact familiar aliases address intuitiveness/intent inference;
live arguments/examples/schema address self-documentation; typed failures and
copyable corrections address error pedagogy. The dimension mapping records
intended behavior coverage rather than claiming every dimension improved.

- `ogent-agent-batch` supplies a read-investigation macro shape after complete
  preflight. Local triage already existed and is not counted as a new command.
- Existing capabilities/guide now expose live SDK/model shapes, aliases and
  examples; new describe/schema APIs make the contract inspectable.
- Explicit JSON reaches read/search/process SDKs, registered model tools and
  actual makem compilation/lint/ERT execution.
- Errors teach exact offset/column/limit/restart/review alternatives and distinguish
  real command/build failure from prerequisites and arguments.
- Declared aliases accept familiar first guesses while preserving exact-name
  precedence, collision refusal and canonical approval decisions.

## Practical evidence and remaining gates

The original fresh source-blind exercise completed **9/9** tasks, **7/9** with
the first strategy, in **94** public round trips, mostly at `07f775a` with batch `895bed7`.
The seven-line README exercise accounts for 63 calls. Its preserved
`agent_simulations/post_pass_3/summary.json` supports no comparative efficiency
claim.

The familiar `10f86bb` repeated replay completed **9/9** tasks in **89** round trips,
with identical start/end SHA. It reused workflows/fixtures, so gets no fresh
first-strategy or efficiency metric. See
`agent_simulations/post_pass_3/final_freeze/summary.json`; prior967 replay is archived under `replay_967eb05/`.
Both observed GNU fallback, a protected helper that can supply gptel doubles,
and isolated builds. Neither certifies live provider transport or full native
checks. No provider login/inference occurred.


Intermediate production snapshot is `10f86bb12a03f3122a60ba085be7289eb5277f5e`; the origin-context final freeze is pending. Source/test-only correction
`967eb05` belongs to R018. GNU and ripgrep now share metadata-selected sorted
files, include file-link paths, and skip descendant directory links. Selected
non-UTF-8 filenames fail explicitly; excluded file contents are not opened.
Raw-NUL binary classification, including late NUL and UTF BOM cases, runs inside
the owned async process before matching/counting. Ripgrep receives exact ordered
file argv in 128-name batches, without JSON path remapping or new dependencies.

The deliberate cost is a per-file classifier read plus a second read of text
candidates, all under the existing process timeout/cancel/cleanup owner.
Focused SDK/process/debug suites pass 193 tests (43/51/99) on Emacs 29/30;
style/checkdoc and warning-gated compilation also pass. Full native checks remain
separate.

Intermediate source snapshot is `10f86bb12a03f3122a60ba085be7289eb5277f5e`. Commit10f86bb repairs the
accepted round7 callback defect. Terminal ledger recording is attempted once;
a storage error produces `ledger_write_failed` with retained completed tool data.
An existing tool failure is preserved as `error.tool_error`. Recovery says effects
already completed, directs callers to inspect retained data and choose a writable
ledger file for future calls, and warns against rerunning effects merely to repair
storage. Legacy text/UI paths retain output and show the warning. A failed finish
write cannot certify persisted ledger completion; start recording must still
succeed before effects. Terminal result-construction failures likewise deliver
a typed retained result rather than suppressing the callback.

`evidence/pass_3/ledger_recovery/results.json` records source-forced210/210 focused
tests plus4/4 existing UI tests on both Emacs29/30, zero skipped/unexpected in the
focused suites, and scoped style/checkdoc/warning-gated compilation. This is
focused validation, not the final full native matrix. The familiar final_freeze
replay completed9/9 at10f86bb in89 round trips; it is not a fresh exercise.

The `verification/pass_3/regression_proof.json` is complete: all11 genuine
baseline failures/current passes are proven at intermediate10f86bb. Expected current counts are R01351 SDK tests,
R01853 (51 process+2 integration), and R02323 actual shell-runner cases. The
fully valid967 proof is archived in
`verification/pass_3/regressions/interim-967eb05/`. Do not relabel that evidence
as10f86bb proof, add overlapping selectors, or mix ERT and shell count units.

The reviewed10f86bb snapshot is **intermediate**. Round8 reported a new P2,
accepted by the integration owner: a default relative ledger path is resolved
again from ambient `default-directory` at async completion, so a project switch
can split the start and finish across different ledgers while the caller receives
status `ok`. The origin-context repair and its new source freeze are pending.
The completed report is `phase7_pass_3_review_round8.md`, with direct evidence
under `evidence/pass_3/review_round8/`. No future repair is claimed here.

Round8 is **NOT_CLEAN**. Prior round5 was clean, but rounds6/7/8 break the clean
streak. After the new origin-context freeze, **PENDING_REVIEW_ROUND_9** and
**PENDING_REVIEW_ROUND_10** must run clean consecutively. Full native validation
remains **PENDING_FINAL_NATIVE_REPORT**, and root delivery/CI remains
**PENDING_ROOT_FINAL_VALIDATION_AND_DELIVERY**. This artifact state is paused
for archival until explicit followup; completed10f tests/scores/proofs remain
valid evidence for that intermediate source, not certification of a later fix.


Persistent resume tokens, dependent batches and transport redesign are deferred
as feature work. Provider-backed throughput or latency was not measured. Exact
alias resolution deliberately does not auto-run fuzzy guesses; unsupported path
bytes fail explicitly. The handoff must retain these limits and may replace
pending gates only with actual freeze-bound reports.

10f integrity verification and all six recorder controls pass for this intermediate
snapshot. Its complete wrapper proof records source/fixture identities, selected
execution, zero skips/timeouts and actual exits; future source remains uncertified.

;;; ogent-zen.el --- Zen Org interaction for ogent -*- lexical-binding: t; -*-

;;; Commentary:
;; ogent-zen turns a plain Org buffer into a quiet notebook: write normal
;; bullets, run any bullet as a prompt with `ogent-run-subtree', and read
;; the result as a compact nested transcript.  Parent bullets travel with
;; the run as explicit context.  All presentation is overlays, folds, and
;; star compositions; the stored text remains a standard `Request:' /
;; `Response (...)' transcript so history replay and regex helpers keep
;; working unchanged.

;;; Code:

(require 'transient)
(require 'ogent-zen-core)
(require 'ogent-zen-tools)
(require 'ogent-zen-workspace)
(require 'ogent-zen-edit)
(require 'ogent-ui-theme)
(require 'ogent-ui-section)

(declare-function ogent-ui--dispatch-request "ogent-ui-send"
                  (source-buffer region-start region-end raw-prompt
                                 models preset templates
                                 &optional org-point context-transform))
(declare-function ogent-status--get-face "ui/ogent-ui-status" (status))
(declare-function org-fold-region "org-fold" (from to flag &optional spec))
(declare-function org-fold-hide-subtree "org-fold")
(declare-function org-fold-show-subtree "org-fold")
(declare-function ogent-completion-next "ogent-completions")
(declare-function ogent-completion-prev "ogent-completions")
(declare-function ogent-completion-reject "ogent-completions")
(declare-function ogent-evil-display-mode-setup "ogent-keys"
                  (mode mode-map mode-hook &optional refresh-fn refresh-force-fn))
(declare-function magit-section-hide "ext:magit-section" (section))

;; Autoloaded entry points relocated to extracted Zen modules.
;;;###autoload (autoload 'ogent-zen-show-tool-calls "ogent-zen" nil t)
;;;###autoload (autoload 'ogent-zen-apply-last-edit "ogent-zen" nil t)
;;;###autoload (autoload 'ogent-zen-accept-edit "ogent-zen" nil t)
;;;###autoload (autoload 'ogent-zen-reject-edit "ogent-zen" nil t)
;;;###autoload (autoload 'ogent-zen-copy-response "ogent-zen" nil t)

(defun ogent-zen--tool-active-label (info)
  "Return an active tool label for tool INFO."
  (let* ((name (or (plist-get info :name) "tool"))
         (context (truncate-string-to-width
                   (or (plist-get info :context) "") 32 nil nil "..."))
         (target (if (string-empty-p context) name context))
         (lower (downcase name)))
    (cond
     ((member lower '("read" "read-file")) (format "reading %s" target))
     ((member lower '("grep" "search")) (format "searching %s" target))
     ((string= lower "bash") (format "bash %s" target))
     ((string= lower "edit") (format "editing %s" target))
     ((string= lower "write") (format "writing %s" target))
     (t (if (string-empty-p context)
            name
          (format "%s %s" name context))))))

(defun ogent-zen--request-tool-label (status infos end)
  "Return a concrete tool-use label for STATUS, tool INFOS, and END."
  (let* ((error-info (cl-find-if
                      (lambda (info)
                        (eq (plist-get info :status) 'error))
                      infos))
         (active-info (car (last (cl-remove-if-not
                                  (lambda (info)
                                    (memq (plist-get info :status)
                                          '(running pending)))
                                  infos))))
         (count (length infos))
         (explicit (ogent-zen--request-tool-grounded-p end)))
    (cond
     (error-info
      (let ((detail (plist-get error-info :error-detail)))
        (if (and detail (not (string-empty-p detail)))
            (format "tool error: %s · %s"
                    (plist-get error-info :name) detail)
          (format "tool error: %s" (plist-get error-info :name)))))
     ((and active-info (memq status '(wait tool type)))
      (ogent-zen--tool-active-label active-info))
     ((> count 1)
      (format "%d tools" count))
     ((= count 1)
      "1 tool")
     (explicit "tools"))))

(defun ogent-zen--subtree-folded-p ()
  "Return non-nil when the current Org subtree is folded at its heading."
  (save-excursion
    (end-of-line)
    (and (< (point) (point-max))
         (invisible-p (1+ (point))))))

(defun ogent-zen--request-error-message (end)
  "Return the first ogent error quote body in the current request before END."
  (save-excursion
    (forward-line 1)
    (when (re-search-forward
           "^[ \t]*#\\+begin_quote[ \t]+ogent-error\\b.*$" end t)
      (let ((start (progn
                     (forward-line 1)
                     (point))))
        (when (re-search-forward "^[ \t]*#\\+end_quote\\b" end t)
          (string-trim
           (buffer-substring-no-properties
            start (line-beginning-position))))))))

(defun ogent-zen--request-error-labels (src-status end)
  "Return diagnostic labels for SRC-STATUS and error content before END."
  (let* ((message (ogent-zen--request-error-message end))
         (detail (ogent-zen--detail-snippet message))
         (lower (downcase (or message ""))))
    (cond
     ((or (equal src-status "aborted")
          (string-match-p "abort\\|cancel" lower))
      (list "aborted" (or (and detail
                               (if (string-match-p "aborted by user" lower)
                                   "user cancelled"
                                 detail))
                          "user cancelled")))
     ((string-match-p
       "network\\|transport\\|econn\\|connection\\|timeout\\|dns\\|tls\\|ssl"
       lower)
      (list "network error" detail))
     ((or detail (string-match-p "\\b429\\b\\|rate limit\\|quota" lower))
      (list "model error" detail))
     (t
      (list "failed")))))

(defun ogent-zen--request-status-labels (status meta end)
  "Return diagnostic status labels for request STATUS, META, and END."
  (pcase status
    ('empty
     (list (or (ogent-zen--char-count-label
                (ogent-zen--request-response-char-count end))
               "0 chars")))
    ('error
     (ogent-zen--request-error-labels (plist-get meta :status) end))
    (_
     (list (ogent-zen--status-label status)))))

(defun ogent-zen--request-response-char-count (end)
  "Return the trimmed response body length in the current request before END."
  (save-excursion
    (let (count)
      (forward-line 1)
      (while (and (not count)
                  (re-search-forward org-heading-regexp end t))
        (beginning-of-line)
        (when (string-prefix-p "Response (" (org-get-heading t t t t))
          (setq count
                (length
                 (string-trim
                  (ogent-zen--response-body-text (point))))))
        (forward-line 1))
      count)))

(defun ogent-zen--preferred-response-heading (end)
  "Return the selected or first response child before END for this request."
  (save-excursion
    (let ((request-level (org-current-level))
          (selected-model (org-entry-get (point) "OGENT_SELECTED_MODEL"))
          first selected)
      (forward-line 1)
      (while (and (not selected)
                  (re-search-forward org-heading-regexp end t))
        (beginning-of-line)
        (when (and (= (org-current-level) (1+ request-level))
                   (string-prefix-p "Response (" (org-get-heading t t t t)))
          (let ((model (ogent-zen--response-model-id
                        (org-get-heading t t t t))))
            (unless first
              (setq first (point)))
            (when (and selected-model (equal selected-model model))
              (setq selected (point)))))
        (forward-line 1))
      (or selected first))))

(defun ogent-zen--response-summary-at (response)
  "Return a quoted compact semantic summary for RESPONSE."
  (save-excursion
    (goto-char response)
    (let ((body-end (ogent-zen--subtree-end))
          summary)
      (forward-line 1)
      (while (and (not summary) (< (point) body-end))
        (cond
         ((ogent-zen--skip-drawer-at-point body-end '("TOOL" "PROPERTIES")))
         ((ogent-zen--skip-source-block-at-point body-end))
         (t
          (let ((line (string-trim
                       (buffer-substring-no-properties
                        (line-beginning-position)
                        (line-end-position)))))
            (unless (or (string-empty-p line)
                        (string-prefix-p "*" line)
                        (string-prefix-p "#+" line)
                        (string-prefix-p ":" line))
              (setq summary
                    (format "“%s”"
                            (truncate-string-to-width
                             line ogent-zen-response-summary-width
                             nil nil "...")))))
          (forward-line 1))))
      summary)))

(defun ogent-zen--response-summary (end)
  "Return a compact semantic summary from the preferred response before END."
  (when-let ((response (ogent-zen--preferred-response-heading end)))
    (ogent-zen--response-summary-at response)))

(defun ogent-zen--folded-result-title (end stats)
  "Return the unquoted result title for current request before END and STATS."
  (or (ogent-zen--result-title-clean
       (org-entry-get (point) "OGENT_RESULT_TITLE"))
      (ogent-zen--response-aggregate-label 'done stats)
      (ogent-zen--result-title-clean
       (ogent-zen--strip-summary-quotes
        (ogent-zen--response-summary end)))
      (ogent-zen--char-count-label
       (ogent-zen--request-response-char-count end))))

(defun ogent-zen--response-stats (end)
  "Return aggregate response stats for the current request before END."
  (save-excursion
    (let ((request-level (org-current-level))
          (selected-model (org-entry-get (point) "OGENT_SELECTED_MODEL"))
          (count 0)
          (done 0)
          (failed 0)
          (active 0)
          (empty 0)
          selected
          models)
      (forward-line 1)
      (while (re-search-forward org-heading-regexp end t)
        (beginning-of-line)
        (when (and (= (org-current-level) (1+ request-level))
                   (string-prefix-p "Response (" (org-get-heading t t t t)))
          (let* ((heading (org-get-heading t t t t))
                 (model (ogent-zen--response-model-id heading))
                 (review (ogent-zen--effective-review-state))
                 (state (car (ogent-zen--response-state)))
                 (selectedp (and selected-model
                                 (equal selected-model model))))
            (cl-incf count)
            (pcase state
              ('done (cl-incf done))
              ('error (cl-incf failed))
              ('empty (cl-incf empty))
              (_ (cl-incf active)))
            (push (list :model model
                        :status state
                        :review review
                        :selected selectedp)
                  models)
            (when selectedp
              (setq selected
                    (ogent-zen--response-review-badge
                     model (or review 'accepted))))
            (when (and (not selected)
                       (memq review '(accepted useful needs-review
                                               rejected failed)))
              (setq selected (ogent-zen--response-review-badge
                              model review)))))
        (forward-line 1))
      (list :count count :done done :failed failed
            :active active :empty empty :selected selected
            :models (nreverse models)))))

(defun ogent-zen--response-aggregate-label (status stats)
  "Return a compact aggregate response label for STATUS and STATS."
  (let ((count (plist-get stats :count))
        (done (plist-get stats :done))
        (failed (plist-get stats :failed)))
    (cond
     ((<= count 1) nil)
     ((> failed 0)
      (format "%d failed, %d done" failed done))
     ((= done count)
      (format "%d responses" count))
     ((> done 0)
      (format "%d/%d done" done count))
     ((memq status '(wait tool type))
      (format "%d models writing" count)))))

(defun ogent-zen--folded-result-label (end stats)
  "Return the folded result summary for current request before END and STATS."
  (ogent-zen--folded-result-title end stats))

(defun ogent-zen--action-hints (status folded)
  "Return optional action hint labels for STATUS and FOLDED state."
  (when ogent-zen-heading-actions
    (delq nil
          (list (when (memq status '(done error empty))
                  "r rerun")
                "u review"
                (if folded "RET expand" "RET fold")))))

(defun ogent-zen--model-chip-name (model)
  "Return compact display name for MODEL in a headline chip."
  (truncate-string-to-width (or model "model") 12 nil nil "..."))

(defun ogent-zen--response-chip (model-info)
  "Return a compact model chip for MODEL-INFO."
  (let* ((model (plist-get model-info :model))
         (status (plist-get model-info :status))
         (review (plist-get model-info :review))
         (selected (plist-get model-info :selected))
         (icon (nth 1 (ogent-zen--status-icon-parts status)))
         (glyph (cond
                 ((or selected (memq review '(accepted useful))) "✓")
                 ((memq review '(needs-review stale superseded rejected)) "◇")
                 (t icon)))
         (face (cond
                ((or selected (memq review '(accepted useful needs-review)))
                 'ogent-zen-review-face)
                ((eq status 'error)
                 (ogent-zen--compose-face 'ogent-zen-muted-face 'error))
                (t 'ogent-zen-muted-face))))
    (propertize (format "[%s %s]"
                        (ogent-zen--model-chip-name model)
                        glyph)
                'face face)))

(defun ogent-zen--response-chips (stats)
  "Return model chips for multi-response STATS."
  (when (> (or (plist-get stats :count) 0) 1)
    (string-join
     (mapcar #'ogent-zen--response-chip
             (plist-get stats :models))
     " ")))

(defun ogent-zen--sibling-run-position-label (_review)
  "Return a lineage label for the current request."
  (if (eq (ogent-zen--review-lineage) 'superseded)
      "superseded by newer run"
    (save-excursion
      (let ((self (point))
            requests
            has-superseded)
        (org-back-to-heading t)
        (let ((level (org-current-level)))
          (when (org-up-heading-safe)
            (let ((end (ogent-zen--subtree-end)))
              (while (and (outline-next-heading) (< (point) end))
                (when (and (= (org-current-level) level)
                           (ogent-zen--request-heading-p))
                  (push (point) requests)
                  (when (eq (ogent-zen--review-lineage) 'superseded)
                    (setq has-superseded t)))))))
        (setq requests (nreverse requests))
        (when (and has-superseded (> (length requests) 1))
          (if (= self (car (last requests)))
              "latest"
            "previous"))))))

(defun ogent-zen--active-tool-info-p (info)
  "Return non-nil when tool INFO is pending or running."
  (memq (plist-get info :status) '(running pending)))

(defun ogent-zen--request-active-primary-label (status tool-infos tool-label)
  "Return a primary transient label for STATUS, TOOL-INFOS, and TOOL-LABEL."
  (let ((active (cl-find-if #'ogent-zen--active-tool-info-p tool-infos))
        (count (length tool-infos)))
    (cond
     ((and active (memq status '(wait tool type)))
      (ogent-zen--tool-active-label active))
     ((eq status 'type)
      (if (> count 0)
          (format "writing answer · %d %s used"
                  count (if (= count 1) "tool" "tools"))
        "writing answer"))
     ((and (eq status 'tool) tool-label
           (not (string-prefix-p "tool error:" tool-label)))
      "using tools"))))

(defun ogent-zen--quote-title (title)
  "Return TITLE as a short quoted label."
  (format "“%s”"
          (truncate-string-to-width
           (substring-no-properties (or title "request"))
           36 nil nil "...")))

(defun ogent-zen--request-primary-title (fallback status folded end stats
                                                  active-label)
  "Return the request headline title for FALLBACK and display state.
STATUS, FOLDED, END, STATS, and ACTIVE-LABEL decide whether the title is
prompt-first, result-first, or transient-work-first."
  (let ((prompt-title (ogent-zen--request-display-title fallback)))
    (truncate-string-to-width
     (cond
      (active-label
       (format "%s · %s" active-label prompt-title))
      ((and folded (eq status 'done))
       (if-let ((result-title (ogent-zen--folded-result-title end stats)))
           (format "%s · from %s"
                   result-title
                   (ogent-zen--quote-title prompt-title))
         prompt-title))
      (t prompt-title))
     96 nil nil "...")))

(defun ogent-zen--request-preview-after-string (status folded end)
  "Return a virtual preview line for STATUS, FOLDED, and END."
  (when (and ogent-zen-folded-result-preview
             folded
             (eq status 'done))
    (when-let ((summary (ogent-zen--response-summary end)))
      (concat "\n"
              (propertize (format "  %s" summary)
                          'face 'ogent-zen-muted-face)))))

(defun ogent-zen--valid-density ()
  "Return the active Zen headline density."
  (if (memq ogent-zen-result-headline-density
            '(minimal balanced rich debug))
      ogent-zen-result-headline-density
    'rich))

(defun ogent-zen--right-alignable-p ()
  "Return non-nil when right-aligned overlay metadata should be used."
  (and ogent-zen-right-align-metadata
       (display-graphic-p)
       (>= (window-body-width nil t) 100)))

(defun ogent-zen--suffix-lanes (left-parts right-parts)
  "Return a suffix with LEFT-PARTS and lower-priority RIGHT-PARTS."
  (let ((left (ogent-zen--suffix left-parts))
        (right (ogent-zen--suffix right-parts)))
    (cond
     ((and left right (ogent-zen--right-alignable-p))
      (concat left
              (propertize
               " "
               'display
               `(space :align-to
                       (- right ,(1+ (string-width
                                      (substring-no-properties right))))))
              right))
     ((and left right)
      (concat left
              (propertize " · " 'face 'ogent-zen-muted-face)
              right))
     (left left)
     (right right))))

(defun ogent-zen--request-display-parts (status meta)
  "Return semantic display parts for request STATUS and META."
  (let* ((end (ogent-zen--subtree-end))
         (path (org-entry-get (point) "OGENT_PATH"))
         (review (ogent-zen--review-state))
         (review-badges (ogent-zen--review-badges))
         (folded (ogent-zen--subtree-folded-p))
         (tool-infos (ogent-zen--request-tool-infos end))
         (tool-label (ogent-zen--request-tool-label status tool-infos end))
         (tool-error (and tool-label
                          (string-prefix-p "tool error:" tool-label)))
         (active-label
          (ogent-zen--request-active-primary-label
           status tool-infos tool-label))
         (workspace (unless tool-error
                      (ogent-zen--workspace-label tool-infos)))
         (stats (ogent-zen--response-stats end))
         (aggregate (ogent-zen--response-aggregate-label status stats))
         (chips (ogent-zen--response-chips stats))
         (selected (and (> (or (plist-get stats :count) 0) 1)
                        (plist-get stats :selected)))
         (lineage (ogent-zen--sibling-run-position-label review))
         (status-labels
          (unless (or tool-error active-label)
            (ogent-zen--request-status-labels status meta end)))
         (debug-status
          (when (eq (ogent-zen--valid-density) 'debug)
            (format "raw %s" (or (plist-get meta :status) status)))))
    (list :end end
          :path path
          :review review
          :review-badges review-badges
          :folded folded
          :tool-infos tool-infos
          :tool-label tool-label
          :tool-error tool-error
          :active-label active-label
          :workspace workspace
          :stats stats
          :aggregate aggregate
          :chips chips
          :selected selected
          :lineage lineage
          :status-labels status-labels
          :debug-status debug-status)))

(defun ogent-zen--request-help (status meta parts)
  "Return help text for a Zen request overlay.
STATUS is the display status, META is parsed src-block metadata, and
PARTS is the semantic display plist."
  (let* ((path (plist-get parts :path))
         (workspace (plist-get parts :workspace))
         (stats (plist-get parts :stats))
         (tool-label (plist-get parts :tool-label)))
    (string-join
     (delq nil
           (list (when path (format "Bullet: %s" path))
                 (when workspace (format "Workspace: %s" workspace))
                 (when (plist-get meta :model)
                   (format "Model: %s" (plist-get meta :model)))
                 (when (plist-get meta :latency)
                   (format "Latency: %s" (plist-get meta :latency)))
                 (when tool-label (format "Tools: %s" tool-label))
                 (when (> (or (plist-get stats :count) 0) 0)
                   (format "Responses: %d done, %d active, %d failed"
                           (or (plist-get stats :done) 0)
                           (or (plist-get stats :active) 0)
                           (or (plist-get stats :failed) 0)))
                 (format "Status: %s"
                         (or (ogent-zen--status-label status) "done"))
                 (format "Density: %s" (ogent-zen--valid-density))
                 (when ogent-zen-heading-actions
                   "RET/mouse-1: fold or expand; r: rerun; u: review; e: error")))
     "\n")))

(defun ogent-zen--request-suffix (status meta &optional parts)
  "Return the muted suffix for a Zen request STATUS and META.
PARTS, when non-nil, is the value from `ogent-zen--request-display-parts'."
  (let* ((parts (or parts (ogent-zen--request-display-parts status meta)))
         (density (ogent-zen--valid-density))
         (folded (plist-get parts :folded))
         (lineage (plist-get parts :lineage))
         (tool-label (plist-get parts :tool-label))
         (tool-error (plist-get parts :tool-error))
         (active-label (plist-get parts :active-label))
         (workspace (plist-get parts :workspace))
         (stats (plist-get parts :stats))
         (aggregate (plist-get parts :aggregate))
         (chips (plist-get parts :chips))
         (selected (plist-get parts :selected))
         (left (delq nil
                     (append
                      (plist-get parts :review-badges)
                      (list lineage
                            (when tool-error tool-label))
                      (plist-get parts :status-labels)
                      (list chips
                            (and (not chips) aggregate)
                            (when (memq density '(rich debug)) selected)))))
         (right
          (pcase density
            ('minimal nil)
            ('balanced
             (list (plist-get meta :model)
                   (plist-get meta :latency)))
            ('rich
             (append
              (list (when ogent-zen-show-breadcrumbs
                      (ogent-zen--path-parent-label
                       (plist-get parts :path)))
                    workspace
                    (unless (or tool-error active-label) tool-label)
                    (plist-get meta :model)
                    (plist-get meta :latency)
                    (and (> (or (plist-get stats :count) 0) 1)
                         aggregate)
                    (when folded "folded"))
              (ogent-zen--action-hints status folded)))
            ('debug
             (append
              (list (ogent-zen--path-parent-label
                     (plist-get parts :path))
                    workspace
                    tool-label
                    (plist-get meta :model)
                    (plist-get meta :latency)
                    aggregate
                    selected
                    (plist-get parts :debug-status)
                    (format "%d responses"
                            (or (plist-get stats :count) 0))
                    (when folded "folded"))
              (ogent-zen--action-hints status folded))))))
    (ogent-zen--suffix-lanes left right)))

(defun ogent-zen--response-char-count ()
  "Return the trimmed response body character count at point."
  (length (string-trim (ogent-zen--response-body-text (point)))))

(defun ogent-zen--response-local-summary ()
  "Return a folded summary for the response at point."
  (ogent-zen--response-summary-at (point)))

(defun ogent-zen--response-suffix (status latency)
  "Return the rich muted suffix for a Zen response STATUS and LATENCY."
  (let ((folded (ogent-zen--subtree-folded-p))
        (density (ogent-zen--valid-density)))
    (ogent-zen--suffix
     (append
      (append (ogent-zen--review-badges)
              (list (when (and folded (eq status 'done))
                      (ogent-zen--response-local-summary))
                    (if (eq status 'empty)
                        (ogent-zen--char-count-label
                         (ogent-zen--response-char-count))
                      (ogent-zen--status-label status))
                    (unless (eq density 'minimal)
                      (and latency
                           (propertize latency 'face 'ogent-theme-muted)))
                    (when (and folded
                               (eq status 'done)
                               (memq density '(rich debug)))
                      (ogent-zen--char-count-label
                       (ogent-zen--response-char-count)))
                    (when (and folded (memq density '(rich debug))) "folded")))
      (unless (eq density 'minimal)
        (ogent-zen--action-hints status folded))))))

;;; Overlay rendering

(defun ogent-zen--heading-text-bounds ()
  "Return bounds of the visible heading text at point."
  (save-excursion
    (beginning-of-line)
    (when (looking-at "^\\*+[ \t]+\\(.*\\)$")
      (cons (match-beginning 1) (match-end 1)))))

(defvar ogent-zen--heading-overlay-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "RET") #'ogent-zen-toggle-transcript)
    (define-key map (kbd "r") #'ogent-zen-rerun)
    (define-key map (kbd "u") #'ogent-zen-review-menu)
    (define-key map (kbd "?") #'ogent-zen-dispatch)
    (define-key map (kbd "n") #'ogent-zen-next-run)
    (define-key map (kbd "p") #'ogent-zen-previous-run)
    (define-key map (kbd "e") #'ogent-zen-show-error)
    (define-key map [mouse-1] #'ogent-zen--mouse-toggle-transcript)
    map)
  "Keymap active on Zen transcript heading overlays.")

(defun ogent-zen--icon (name fallback &optional face)
  "Return theme icon NAME with FALLBACK and optional FACE."
  (if (fboundp 'ogent-theme-icon)
      (condition-case nil
          (let ((icon (ogent-theme-icon name face)))
            (if (and (stringp icon) (not (string-empty-p icon)))
                icon
              (if face (propertize fallback 'face face) fallback)))
        (error (if face (propertize fallback 'face face) fallback)))
    (if face (propertize fallback 'face face) fallback)))

(defun ogent-zen--compose-face (base status)
  "Return a face list combining BASE with STATUS face when available."
  (let ((status-face
         (if (fboundp 'ogent-status--get-face)
             (condition-case nil
                 (ogent-status--get-face status)
               (error nil))
           (pcase status
             ('error 'ogent-theme-error)
             ('done 'ogent-theme-success)
             (_ nil)))))
    (if (and status-face (not (eq status-face 'default)))
        (list status-face base)
      base)))

(defun ogent-zen--overlay-label (icon-name fallback text base-face status
                                           &optional suffix)
  "Return a propertized overlay label using ICON-NAME and FALLBACK.
TEXT is rendered with BASE-FACE and STATUS; SUFFIX is appended as metadata."
  (let* ((face (ogent-zen--compose-face base-face status))
         (icon (ogent-zen--icon icon-name fallback face))
         (label (propertize (concat icon " " (string-trim text)) 'face face)))
    (if suffix
        (concat label " "
                (propertize "· " 'face 'ogent-zen-muted-face)
                suffix)
      label)))

(defun ogent-zen--lane-before-string (icon-name fallback status)
  "Return an optional margin lane for ICON-NAME, FALLBACK, and STATUS."
  (when ogent-zen-visual-lanes
    (let* ((face (ogent-zen--compose-face 'ogent-zen-run-face status))
           (icon (ogent-zen--icon icon-name fallback face)))
      (propertize " "
                  'display `((margin left-margin)
                             ,(concat icon " "))
                  'face face))))

(defun ogent-zen--add-heading-overlay (display face &optional help
                                               after-string before-string)
  "Overlay the current heading text with DISPLAY using FACE and HELP.
AFTER-STRING and BEFORE-STRING are optional virtual display strings."
  (when-let* ((bounds (ogent-zen--heading-text-bounds))
              (start (car bounds))
              (end (cdr bounds)))
    (let ((overlay (make-overlay start end nil t nil)))
      (overlay-put overlay 'display display)
      (overlay-put overlay 'face face)
      (overlay-put overlay 'evaporate t)
      (overlay-put overlay 'help-echo help)
      (when after-string
        (overlay-put overlay 'after-string after-string))
      (when before-string
        (overlay-put overlay 'before-string before-string))
      (when ogent-zen-heading-actions
        (overlay-put overlay 'mouse-face 'highlight)
        (overlay-put overlay 'keymap ogent-zen--heading-overlay-map))
      (push overlay ogent-zen--overlays))))

(defun ogent-zen--overlay-request (heading)
  "Add a Zen request overlay for HEADING."
  (let* ((fallback (string-trim
                    (substring heading (length "Request:"))))
         (end (ogent-zen--subtree-end))
         (meta (or (ogent-zen--src-meta end) nil))
         (status (ogent-zen--request-status))
         (icon (ogent-zen--status-icon-parts status))
         (parts (ogent-zen--request-display-parts status meta))
         (stats (plist-get parts :stats))
         (folded (plist-get parts :folded))
         (summary (ogent-zen--request-primary-title
                   fallback status folded end stats
                   (plist-get parts :active-label)))
         (suffix (ogent-zen--request-suffix status meta parts))
         (help (ogent-zen--request-help status meta parts))
         (after-string
          (ogent-zen--request-preview-after-string status folded end))
         (before-string
          (ogent-zen--lane-before-string
           (nth 0 icon) (nth 1 icon) (nth 2 icon)))
         (display (ogent-zen--overlay-label
                   (nth 0 icon) (nth 1 icon) summary 'ogent-zen-run-face
                   (nth 2 icon) suffix)))
    (ogent-zen--add-heading-overlay
     display 'ogent-zen-run-face help after-string before-string)))

(defun ogent-zen--response-overlay-label (model-id status suffix)
  "Return a quiet response overlay label for MODEL-ID, STATUS, and SUFFIX."
  (ignore status)
  (let ((label (concat (propertize "↳ " 'face 'ogent-theme-muted)
                       (propertize model-id 'face 'ogent-theme-muted))))
    (if suffix
        (concat label " "
                (propertize "· " 'face 'ogent-zen-muted-face)
                suffix)
      label)))

(defun ogent-zen--overlay-response (heading)
  "Add a Zen response overlay for HEADING."
  (let* ((model-id (ogent-zen--response-model-id heading))
         (state (ogent-zen--response-state))
         (status (car state))
         (latency (cdr state))
         (suffix (ogent-zen--response-suffix status latency))
         (help (string-join
                (delq nil
                      (list (format "Response: %s" model-id)
                            (format "Status: %s"
                                    (or (ogent-zen--status-label status) "done"))
                            (when ogent-zen-heading-actions
                              "RET/mouse-1: fold or expand; r: rerun; u: review")))
                "\n"))
         (display (ogent-zen--response-overlay-label model-id status suffix)))
    (ogent-zen--add-heading-overlay display 'ogent-zen-response-face help)))

(defun ogent-zen--overlay-entry ()
  "Add a Zen overlay for the heading at point when it is a transcript node.
Runs widened so parent and subtree lookups work when the surrounding
scan is narrowed to a refresh region."
  (condition-case nil
      (save-restriction
        (widen)
        (let ((heading (org-get-heading t t t t)))
          (cond
           ((string-prefix-p "Request:" heading)
            (when (equal (org-entry-get (point) "OGENT_STYLE") "zen")
              (ogent-zen--overlay-request heading)))
           ((string-prefix-p "Response (" heading)
            (when (ogent-zen--parent-zen-request-p)
              (ogent-zen--overlay-response heading))))))
    (error nil)))

(defun ogent-zen--build-overlays (&optional begin end)
  "Build Zen overlays in the buffer, or only between BEGIN and END."
  (save-excursion
    (save-restriction
      (widen)
      (when (and begin end)
        (narrow-to-region begin end))
      (condition-case nil
          (org-map-entries #'ogent-zen--overlay-entry nil nil)
        (error nil)))))

(defun ogent-zen--delete-overlays (&optional begin end)
  "Delete Zen overlays; with BEGIN and END only those starting inside."
  (if (and begin end)
      (setq ogent-zen--overlays
            (cl-delete-if (lambda (overlay)
                            (let ((start (overlay-start overlay)))
                              (when (or (null start)
                                        (and (>= start begin) (< start end)))
                                (delete-overlay overlay)
                                t)))
                          ogent-zen--overlays))
    (mapc #'delete-overlay ogent-zen--overlays)
    (setq ogent-zen--overlays nil)))

(defun ogent-zen-refresh (&optional begin end)
  "Refresh Zen presentation overlays in the current Org buffer.
With BEGIN and END, rebuild only the overlays inside that region;
overlays elsewhere are left untouched."
  (interactive)
  (ogent-zen--delete-overlays begin end)
  (when (and ogent-zen-pretty-headings
             (derived-mode-p 'org-mode))
    (ogent-zen--build-overlays begin end)))

(defun ogent-zen-refresh-at (position)
  "Refresh Zen overlays for the transcript containing POSITION.
Falls back to a full refresh when the transcript cannot be resolved."
  (let ((bounds (condition-case nil
                    (save-excursion
                      (goto-char position)
                      (when-let* ((request
                                   (ogent-zen--transcript-request-heading)))
                        (goto-char request)
                        (cons request (ogent-zen--subtree-end))))
                  (error nil))))
    (if bounds
        (ogent-zen-refresh (car bounds) (cdr bounds))
      (ogent-zen-refresh))))

;;; Active run animation

(defun ogent-zen--active-request-p ()
  "Return non-nil when point is on an active Zen request heading."
  (and (ogent-zen--request-heading-p)
       (memq (ogent-zen--request-status) '(wait tool type))))

(defun ogent-zen--active-request-positions ()
  "Return active Zen request heading positions in the current buffer."
  (save-excursion
    (save-restriction
      (widen)
      (let (positions)
        (goto-char (point-min))
        (while (re-search-forward org-heading-regexp nil t)
          (beginning-of-line)
          (when (ogent-zen--active-request-p)
            (push (point) positions))
          (forward-line 1))
        (nreverse positions)))))

(defun ogent-zen--buffer-has-active-request-p ()
  "Return non-nil when the current buffer has an active Zen request."
  (consp (ogent-zen--active-request-positions)))

(defun ogent-zen--animation-buffers ()
  "Return visible Zen buffers with active request headings."
  (cl-remove-if-not
   (lambda (buffer)
     (and (buffer-live-p buffer)
          (buffer-local-value 'ogent-zen-mode buffer)
          (get-buffer-window-list buffer nil t)
          (with-current-buffer buffer
            (ogent-zen--buffer-has-active-request-p))))
   (buffer-list)))

(defun ogent-zen--animation-tick ()
  "Advance active Zen overlay animation in visible buffers."
  (let ((buffers (ogent-zen--animation-buffers)))
    (if buffers
        (dolist (buffer buffers)
          (with-current-buffer buffer
            (let ((positions (ogent-zen--active-request-positions)))
              (setq ogent-zen--stream-frame
                    (mod (1+ ogent-zen--stream-frame) 4))
              (dolist (pos positions)
                (ogent-zen-refresh-at pos)))))
      (when (timerp ogent-zen--animation-timer)
        (cancel-timer ogent-zen--animation-timer))
      (setq ogent-zen--animation-timer nil))))

(defun ogent-zen--ensure-animation-timer ()
  "Start the Zen animation timer when needed."
  (when (and (numberp ogent-zen-active-animation-delay)
             (> ogent-zen-active-animation-delay 0)
             (not (timerp ogent-zen--animation-timer)))
    (setq ogent-zen--animation-timer
          (run-at-time ogent-zen-active-animation-delay
                       ogent-zen-active-animation-delay
                       #'ogent-zen--animation-tick))))

(defun ogent-zen--remove-animation-timer ()
  "Cancel the Zen animation timer when no Zen buffer remains."
  (unless (cl-some (lambda (buffer)
                     (and (buffer-live-p buffer)
                          (buffer-local-value 'ogent-zen-mode buffer)))
                   (buffer-list))
    (when (timerp ogent-zen--animation-timer)
      (cancel-timer ogent-zen--animation-timer))
    (setq ogent-zen--animation-timer nil)))

;;; Folding

(defun ogent-zen--fold-region-safe (from to spec)
  "Fold FROM..TO with SPEC when org-fold is available."
  (when (fboundp 'org-fold-region)
    (ignore-errors (org-fold-region from to t spec))))

(defun ogent-zen--fold-drawer-at (heading-pos)
  "Fold the property drawer of the heading at HEADING-POS."
  (save-excursion
    (goto-char heading-pos)
    (forward-line 1)
    (when (looking-at org-property-drawer-re)
      (ogent-zen--fold-region-safe (line-end-position) (match-end 0)
                                   'drawer))))

(defun ogent-zen--fold-block-at (pos)
  "Fold the src block whose #+begin_src line begins at POS."
  (save-excursion
    (goto-char pos)
    (when (looking-at-p "^#\\+begin_src")
      (let ((from (line-end-position))
            (to (when (re-search-forward "^#\\+end_src" nil t)
                  (line-end-position))))
        (when to
          (ogent-zen--fold-region-safe from to 'block))))))

(defun ogent-zen--fold-tool-drawers (end)
  "Fold all tool drawers before END in the current request subtree.
Unlike normal Org drawer folding, hide the `:TOOL:' line too; Zen run
cards already summarize tool state in the request headline."
  (save-excursion
    (forward-line 1)
    (while (re-search-forward "^[ \t]*:TOOL:[ \t]*$" end t)
      (let ((from (line-beginning-position))
            (to (save-excursion
                  (when (re-search-forward "^[ \t]*:END:[ \t]*$" end t)
                    (line-end-position)))))
        (when to
          (ogent-zen--fold-region-safe from to 'drawer)
          (goto-char to))))))

(defun ogent-zen--fold-transcript-noise (request)
  "Fold the drawers and prompt block of the Zen request at REQUEST."
  (save-excursion
    (goto-char request)
    (let ((end (ogent-zen--subtree-end)))
      (ogent-zen--fold-drawer-at request)
      (goto-char request)
      (when (re-search-forward "^#\\+begin_src text " end t)
        (ogent-zen--fold-block-at (line-beginning-position)))
      (goto-char request)
      (ogent-zen--fold-tool-drawers end))))

(defun ogent-zen--fold-noise-buffer ()
  "Fold drawers, tool drawers, and prompt blocks of every Zen transcript."
  (when (and ogent-zen-fold-noise (fboundp 'org-fold-region))
    (org-with-wide-buffer
     (goto-char (point-min))
     (while (re-search-forward "^\\*+ Request:" nil t)
       (save-excursion
         (beginning-of-line)
         (when (ogent-zen--request-heading-p)
           (ogent-zen--fold-transcript-noise (point))))))))

(defun ogent-zen--collapse-sibling-runs (request)
  "Fold and supersede older Zen sibling transcripts of REQUEST."
  (save-excursion
    (goto-char request)
    (org-back-to-heading t)
    ;; Track the *new* request heading with a live marker.  Marking older
    ;; siblings below inserts property and drawer lines that shift every
    ;; following heading -- including this one -- downward.  A raw integer
    ;; position would go stale and the new request would drift out from
    ;; under the self-exclusion test and get marked superseded too (the
    ;; bug this guards against); a marker follows the shift.
    (let ((self (point-marker))
          (level (org-current-level)))
      (when (org-up-heading-safe)
        ;; Point is on the parent bullet; walk its child headings.  END is a
        ;; marker so it grows as siblings gain metadata and later runs stay
        ;; in range.
        (let ((end (copy-marker (ogent-zen--subtree-end) t)))
          (while (and (outline-next-heading) (< (point) end))
            (when (and (eql (org-current-level) level)
                       (/= (point) (marker-position self))
                       (ogent-zen--request-heading-p))
              (let ((review (or (org-entry-get (point) "OGENT_LINEAGE")
                                (org-entry-get (point) "OGENT_REVIEW"))))
                (when (or (null review)
                          (member review '("needs-review" "stale"
                                           "superseded")))
                  (org-entry-put (point) "OGENT_LINEAGE" "superseded")
                  (ogent-zen--sync-legacy-review (point))
                  (ogent-zen--sync-review-drawer (point))))
              (when (fboundp 'org-fold-hide-subtree)
                (ignore-errors (org-fold-hide-subtree)))))
          (set-marker end nil)))
      (set-marker self nil))))

(defun ogent-zen-after-insert (request-pos)
  "Apply Zen presentation after a transcript was inserted at REQUEST-POS.
Folds the new request's drawer and prompt block, collapses earlier
sibling runs, and refreshes overlays for the enclosing bullet subtree."
  (when (derived-mode-p 'org-mode)
    (let ((request (if (markerp request-pos)
                       (marker-position request-pos)
                     request-pos)))
      (when (integerp request)
        (when ogent-zen-fold-noise
          (ogent-zen--fold-transcript-noise request))
        (when ogent-zen-collapse-previous-runs
          (ogent-zen--collapse-sibling-runs request))
        (let ((bounds (condition-case nil
                          (save-excursion
                            (goto-char request)
                            (org-back-to-heading t)
                            (when (org-up-heading-safe)
                              (cons (point) (ogent-zen--subtree-end))))
                        (error nil))))
          (if bounds
              (ogent-zen-refresh (car bounds) (cdr bounds))
            (ogent-zen-refresh-at request)))))))

;;; Quiet bullets (star composition)

(defconst ogent-zen--star-regexp "^\\(\\*+\\) "
  "Regexp matching the leading stars of an Org heading.")

(defun ogent-zen--bullets-allowed-p ()
  "Return non-nil when star composition should be installed."
  (and ogent-zen-bullet
       (not (string-empty-p ogent-zen-bullet))
       (not (bound-and-true-p org-modern-mode))
       (not (bound-and-true-p org-bullets-mode))
       (not (bound-and-true-p org-superstar-mode))))

(defun ogent-zen--prettify-stars ()
  "Font-lock helper: compose the matched star run into `ogent-zen-bullet'."
  (compose-region (match-beginning 1) (match-end 1) ogent-zen-bullet)
  nil)

(defun ogent-zen--compose-buffer-stars ()
  "Compose every heading's leading stars into `ogent-zen-bullet'."
  (org-with-wide-buffer
   (goto-char (point-min))
   (with-silent-modifications
     (while (re-search-forward ogent-zen--star-regexp nil t)
       (compose-region (match-beginning 1) (match-end 1) ogent-zen-bullet)))))

(defun ogent-zen--decompose-buffer-stars ()
  "Remove star compositions installed by `ogent-zen-mode'."
  (org-with-wide-buffer
   (goto-char (point-min))
   (with-silent-modifications
     (while (re-search-forward ogent-zen--star-regexp nil t)
       (decompose-region (match-beginning 1) (match-end 1))))))

(defun ogent-zen--install-bullets ()
  "Install quiet bullet composition for heading stars."
  (when (ogent-zen--bullets-allowed-p)
    (setq ogent-zen--bullet-keywords
          `((,ogent-zen--star-regexp (0 (ogent-zen--prettify-stars)))))
    (font-lock-add-keywords nil ogent-zen--bullet-keywords)
    (ogent-zen--compose-buffer-stars)
    (when font-lock-mode
      (font-lock-flush))))

(defun ogent-zen--remove-bullets ()
  "Remove quiet bullet composition installed by `ogent-zen-mode'."
  (when ogent-zen--bullet-keywords
    (font-lock-remove-keywords nil ogent-zen--bullet-keywords)
    (setq ogent-zen--bullet-keywords nil)
    (ogent-zen--decompose-buffer-stars)
    (when font-lock-mode
      (font-lock-flush))))

;;; Centered page (window margins)

(defun ogent-zen--sync-margins (&optional _frame)
  "Synchronize centered margins for windows showing Zen buffers."
  (dolist (frame (frame-list))
    (dolist (window (window-list frame 'no-minibuf))
      (let* ((buffer (window-buffer window))
             (column (and (buffer-live-p buffer)
                          (buffer-local-value 'ogent-zen-mode buffer)
                          (buffer-local-value 'ogent-zen-center-column
                                              buffer))))
        (cond
         ((integerp column)
          (let ((margin (max 0 (/ (- (window-total-width window) column) 2))))
            (set-window-parameter window 'ogent-zen-centered t)
            (set-window-margins window margin margin)))
         ((window-parameter window 'ogent-zen-centered)
          (set-window-parameter window 'ogent-zen-centered nil)
          (set-window-margins window nil nil)))))))

(defun ogent-zen--margins-needed-p ()
  "Return non-nil when some live buffer still has `ogent-zen-mode'."
  (cl-some (lambda (buffer)
             (buffer-local-value 'ogent-zen-mode buffer))
           (buffer-list)))

(defun ogent-zen--install-margins ()
  "Install global margin synchronization hooks."
  (add-hook 'window-configuration-change-hook #'ogent-zen--sync-margins)
  (add-hook 'window-size-change-functions #'ogent-zen--sync-margins)
  (ogent-zen--sync-margins))

(defun ogent-zen--remove-margins ()
  "Clear margins for this buffer and drop hooks when no Zen buffer remains."
  (ogent-zen--sync-margins)
  (unless (ogent-zen--margins-needed-p)
    (remove-hook 'window-configuration-change-hook #'ogent-zen--sync-margins)
    (remove-hook 'window-size-change-functions #'ogent-zen--sync-margins)))

;;; Minor mode

;;;###autoload
(define-minor-mode ogent-zen-mode
  "Minor mode for Zen-style ogent interaction in Org buffers.

Write normal Org bullets; \\[ogent-run-subtree] runs the bullet at
point as the prompt with its parent bullets as context.
\\[org-ctrl-c-ctrl-c] on a generated transcript re-runs that bullet
\(`ogent-zen-rerun').

Presentation is non-destructive: generated `Request:' / `Response'
headings get compact status overlays, leading stars are composed into
`ogent-zen-bullet', transcript drawers, tool drawers, and prompt blocks
fold away \(`ogent-zen-fold-noise'), earlier runs collapse when a new
run starts \(`ogent-zen-collapse-previous-runs'), active runs animate
only in visible buffers, and the page can be centered via
`ogent-zen-center-column'.  Disabling the mode restores plain Org."
  :lighter " Zen"
  (if ogent-zen-mode
      (when (derived-mode-p 'org-mode)
        (visual-line-mode 1)
        (setq-local line-spacing 0.15)
        (when (and (fboundp 'org-indent-mode)
                   (not (bound-and-true-p org-indent-mode)))
          (setq-local ogent-zen--enabled-org-indent t)
          (org-indent-mode 1))
        (ogent-zen--install-bullets)
        (add-hook 'org-ctrl-c-ctrl-c-hook #'ogent-zen--ctrl-c-ctrl-c nil t)
        (ogent-zen--install-margins)
        (ogent-zen--fold-noise-buffer)
        (ogent-zen--ensure-animation-timer)
        (ogent-zen-refresh))
    (ogent-zen--delete-overlays)
    (when (derived-mode-p 'org-mode)
      (ogent-zen--remove-bullets)
      (remove-hook 'org-ctrl-c-ctrl-c-hook #'ogent-zen--ctrl-c-ctrl-c t)
      (when (and ogent-zen--enabled-org-indent
                 (fboundp 'org-indent-mode))
        (setq-local ogent-zen--enabled-org-indent nil)
        (org-indent-mode -1)))
    (ogent-zen--remove-margins)
    (ogent-zen--remove-animation-timer)))

(defun ogent-zen--turn-on ()
  "Enable `ogent-zen-mode' for `global-ogent-zen-mode'.
Activate only in Org buffers, skipping internal temporary buffers whose
names begin with a space so prompt-extraction scratch buffers stay
untouched."
  (when (and (derived-mode-p 'org-mode)
             (not (derived-mode-p 'ogent-zen-tool-calls-mode))
             (not ogent-zen-mode)
             (not (string-prefix-p " " (buffer-name))))
    (ogent-zen-mode 1)))

;;;###autoload
(define-globalized-minor-mode global-ogent-zen-mode
  ogent-zen-mode ogent-zen--turn-on
  :group 'ogent-zen
  :predicate '(org-mode))

;;; Prompt extraction

(defun ogent-zen--delete-generated-subtrees ()
  "Delete generated ogent child subtrees from the current temp Org buffer."
  (let (positions)
    (save-excursion
      (goto-char (point-min))
      (while (re-search-forward org-heading-regexp nil t)
        (beginning-of-line)
        (unless (= (point) (point-min))
          (when (ogent-zen--generated-heading-p)
            (push (copy-marker (point)) positions)))
        (forward-line 1)))
    (dolist (marker positions)
      (when (marker-position marker)
        (goto-char marker)
        (let ((start (point))
              (end (save-excursion
                     (org-end-of-subtree t t)
                     (point))))
          (delete-region start end)))
      (set-marker marker nil))))

(defun ogent-zen--delete-property-drawers ()
  "Delete Org property drawers from the current buffer."
  (save-excursion
    (goto-char (point-min))
    (while (re-search-forward "^[ \t]*:PROPERTIES:[ \t]*$" nil t)
      (let ((start (line-beginning-position)))
        (when (re-search-forward "^[ \t]*:END:[ \t]*$" nil t)
          (delete-region start (min (point-max) (1+ (line-end-position)))))))))

(defun ogent-zen--root-level ()
  "Return the level of the first Org heading in the current buffer."
  (save-excursion
    (goto-char (point-min))
    (when (re-search-forward org-heading-regexp nil t)
      (length (match-string 1)))))

(defun ogent-zen--markdown-lines (root-level)
  "Return markdown-like bullet lines relative to ROOT-LEVEL."
  (let ((current-relative 0)
        lines)
    (save-excursion
      (goto-char (point-min))
      (while (not (eobp))
        (cond
         ((looking-at org-heading-regexp)
          (let* ((level (length (match-string 1)))
                 (relative (max 0 (- level root-level)))
                 (indent (make-string (* 2 relative) ?\s))
                 (title (org-get-heading t t t t)))
            (setq current-relative relative)
            (push (concat indent "- " title) lines)))
         (t
          (let ((line (buffer-substring-no-properties
                       (line-beginning-position)
                       (line-end-position))))
            (push (if (string-empty-p line)
                      ""
                    (concat (make-string (* 2 (1+ current-relative)) ?\s)
                            line))
                  lines))))
        (forward-line 1)))
    (nreverse lines)))

(defun ogent-zen--subtree-prompt (point)
  "Return POINT's Org subtree as a markdown-like prompt string."
  (let ((text (save-excursion
                (goto-char point)
                (org-back-to-heading t)
                (let* ((element (org-element-at-point))
                       (begin (org-element-property :begin element))
                       (end (org-element-property :end element)))
                  (buffer-substring-no-properties begin end)))))
    (with-temp-buffer
      (org-mode)
      (insert text)
      (goto-char (point-min))
      (ogent-zen--delete-generated-subtrees)
      (ogent-zen--delete-property-drawers)
      (let* ((root-level (or (ogent-zen--root-level) 1))
             (prompt (string-trim
                      (string-join (ogent-zen--markdown-lines root-level)
                                   "\n"))))
        (when (string-empty-p prompt)
          (user-error "Current subtree is empty after removing ogent output"))
        prompt))))

(defun ogent-zen--element-target-bounds ()
  "Return editable Org element bounds at point, or nil."
  (let* ((element (org-element-context))
         (type (org-element-type element)))
    (when (memq type '(paragraph item src-block quote-block verse-block
                                 example-block special-block table-row
                                 table fixed-width plain-list))
      (let ((beg (or (org-element-property :contents-begin element)
                     (org-element-property :begin element)))
            (end (or (org-element-property :contents-end element)
                     (org-element-property :end element))))
        (when (and beg end (< beg end))
          (cons beg end))))))

(defun ogent-zen--thing-target-bounds (thing)
  "Return bounds for THING at point, constrained to the current heading."
  (when-let ((bounds (bounds-of-thing-at-point thing)))
    (save-excursion
      (let ((beg (car bounds))
            (end (cdr bounds))
            (heading (ogent-zen--heading-point)))
        (when heading
          (goto-char heading)
          (let ((subtree-end (ogent-zen--subtree-end))
                (body-beg (save-excursion
                            (goto-char heading)
                            (forward-line 1)
                            (point))))
            (setq beg (max beg body-beg)
                  end (min end subtree-end))
            (when (< beg end)
              (cons beg end))))))))

(defun ogent-zen--scope-target-bounds (kind)
  "Return text target bounds for scope KIND at point."
  (pcase kind
    ('region
     (unless (use-region-p)
       (user-error "Region scope requires an active region"))
     (cons (region-beginning) (region-end)))
    ('element (or (ogent-zen--element-target-bounds)
                  (ogent-zen--thing-target-bounds 'paragraph)))
    ('sentence (ogent-zen--thing-target-bounds 'sentence))
    ('paragraph (or (ogent-zen--element-target-bounds)
                    (ogent-zen--thing-target-bounds 'paragraph)))
    (_ nil)))

(defun ogent-zen--scope-at-point (&optional preferred-kind instruction edit-p)
  "Return an `ogent-zen-scope' for the current Org location.
PREFERRED-KIND chooses `subtree', `region', `element', `sentence', or
`paragraph'.  INSTRUCTION is attached to edit and region prompts.  When
EDIT-P is non-nil, the scope expects a SEARCH/REPLACE edit response."
  (unless (derived-mode-p 'org-mode)
    (user-error "Zen scope requires an Org buffer"))
  (let ((heading-point (ogent-zen--heading-point)))
    (unless heading-point
      (user-error "Zen scope requires point inside a user Org heading"))
    (let* ((kind (or preferred-kind
                     (and (use-region-p) 'region)
                     'element))
           (breadcrumb (ogent-zen--breadcrumb heading-point)))
      (if (eq kind 'subtree)
          (make-ogent-zen-scope
           :kind 'subtree
           :heading-point heading-point
           :prompt-text (ogent-zen--subtree-prompt heading-point)
           :breadcrumb breadcrumb
           :instruction instruction
           :edit-p edit-p)
        (let ((bounds (or (ogent-zen--scope-target-bounds kind)
                          (and (not preferred-kind)
                               (ogent-zen--scope-target-bounds 'sentence))
                          (and (not preferred-kind)
                               (ogent-zen--scope-target-bounds 'paragraph)))))
          (unless bounds
            (user-error "No editable text scope at point"))
          (let* ((beg (car bounds))
                 (end (cdr bounds))
                 (text (ogent-zen--scope-text beg end)))
            (when (string-empty-p (string-trim text))
              (user-error "Selected Zen scope is empty"))
            (make-ogent-zen-scope
             :kind kind
             :heading-point heading-point
             :start-marker (copy-marker beg)
             :end-marker (copy-marker end t)
             :original-text text
             :prompt-text text
             :breadcrumb breadcrumb
             :instruction instruction
             :edit-p edit-p)))))))

(defun ogent-zen--scope-edit-instruction (scope)
  "Return the edit instruction for SCOPE."
  (let ((instruction (ogent-zen-scope-instruction scope)))
    (if (and instruction (not (string-empty-p (string-trim instruction))))
        instruction
      "Improve the selected text while preserving its meaning and Org structure.")))

(defun ogent-zen--scope-prompt (scope)
  "Return the direct model prompt for Zen SCOPE."
  (if (eq (ogent-zen-scope-kind scope) 'subtree)
      (ogent-zen-scope-prompt-text scope)
    (let ((selected (or (ogent-zen-scope-original-text scope)
                        (ogent-zen-scope-prompt-text scope)
                        "")))
      (if (ogent-zen-scope-edit-p scope)
          (format
           "Rewrite the selected text according to this instruction:\n\n%s\n\nSelected text:\n#+begin_quote\n%s\n#+end_quote\n\nReturn exactly one SEARCH/REPLACE block for the selected text:\n\n<<<<<<< SEARCH\n[exact selected text]\n=======\n[replacement text]\n>>>>>>> REPLACE"
           (ogent-zen--scope-edit-instruction scope)
           selected)
        (format
         "Answer the following question about the selected text with the surrounding tree as context:\n\n%s\n\nSelected text:\n#+begin_quote\n%s\n#+end_quote"
         (or (ogent-zen-scope-instruction scope)
             "Explain this selected text.")
         selected)))))

(defun ogent-zen--transcript-request-or-error ()
  "Return the Zen request owning point, or signal a user error."
  (or (ogent-zen--transcript-request-heading)
      (user-error "Point is not inside a Zen transcript")))

;;;###autoload
(defun ogent-zen-toggle-transcript ()
  "Toggle folding for the Zen transcript at point."
  (interactive)
  (unless (derived-mode-p 'org-mode)
    (user-error "Zen transcript commands require an Org buffer"))
  (let ((request (ogent-zen--transcript-request-or-error)))
    (save-excursion
      (goto-char request)
      (if (ogent-zen--subtree-folded-p)
          (when (fboundp 'org-fold-show-subtree)
            (org-fold-show-subtree))
        (when (fboundp 'org-fold-hide-subtree)
          (org-fold-hide-subtree))))
    (ogent-zen-refresh-at request)))

(defun ogent-zen--mouse-toggle-transcript (event)
  "Toggle the Zen transcript clicked by mouse EVENT."
  (interactive "e")
  (mouse-set-point event)
  (ogent-zen-toggle-transcript))

;;;###autoload
(defun ogent-zen-show-error ()
  "Jump to the error output in the Zen transcript at point."
  (interactive)
  (unless (derived-mode-p 'org-mode)
    (user-error "Zen transcript commands require an Org buffer"))
  (let ((request (ogent-zen--transcript-request-or-error)))
    (goto-char request)
    (when (fboundp 'org-fold-show-subtree)
      (org-fold-show-subtree))
    (let ((end (ogent-zen--subtree-end)))
      (unless (re-search-forward
               "^[ \t]*#\\+begin_quote[ \t]+ogent-error\\b\\|\\bTool error:"
               end t)
        (user-error "This Zen transcript has no visible error"))
      (beginning-of-line)
      (recenter))))

;;; Run navigation and display controls

(defun ogent-zen--move-run (direction)
  "Move to the next Zen request heading in DIRECTION."
  (unless (derived-mode-p 'org-mode)
    (user-error "Zen run navigation requires an Org buffer"))
  (let (found)
    (save-restriction
      (widen)
      (if (> direction 0)
          (progn
            (when (save-excursion
                    (beginning-of-line)
                    (looking-at org-heading-regexp))
              (forward-line 1))
            (while (and (not found)
                        (re-search-forward org-heading-regexp nil t))
              (beginning-of-line)
              (if (ogent-zen--request-heading-p)
                  (setq found (point))
                (forward-line 1))))
        (unless (and (bolp) (looking-at org-heading-regexp))
          (beginning-of-line))
        (while (and (not found)
                    (re-search-backward org-heading-regexp nil t))
          (beginning-of-line)
          (when (ogent-zen--request-heading-p)
            (setq found (point))))))
    (unless found
      (user-error "No more runs"))
    (goto-char found)
    (beginning-of-line)))

;;;###autoload
(defun ogent-zen-next-run ()
  "Move point to the next Zen run heading."
  (interactive)
  (ogent-zen--move-run 1))

;;;###autoload
(defun ogent-zen-previous-run ()
  "Move point to the previous Zen run heading."
  (interactive)
  (ogent-zen--move-run -1))

;;;###autoload
(defun ogent-zen-cycle-density ()
  "Cycle Zen result headline density and refresh overlays."
  (interactive)
  (setq ogent-zen-result-headline-density
        (pcase (ogent-zen--valid-density)
          ('minimal 'balanced)
          ('balanced 'rich)
          ('rich 'debug)
          (_ 'minimal)))
  (ogent-zen-refresh)
  (message "Zen density: %s" ogent-zen-result-headline-density))

(defun ogent-zen--toggle-breadcrumbs ()
  "Toggle Zen breadcrumb metadata and refresh overlays."
  (interactive)
  (setq ogent-zen-show-breadcrumbs (not ogent-zen-show-breadcrumbs))
  (ogent-zen-refresh)
  (message "Zen breadcrumbs %s"
           (if ogent-zen-show-breadcrumbs "enabled" "disabled")))

(defun ogent-zen--toggle-visual-lanes ()
  "Toggle Zen visual status lanes and refresh overlays."
  (interactive)
  (setq ogent-zen-visual-lanes (not ogent-zen-visual-lanes))
  (ogent-zen-refresh)
  (message "Zen visual lanes %s"
           (if ogent-zen-visual-lanes "enabled" "disabled")))

(defconst ogent-zen--review-properties
  '("OGENT_DECISION"
    "OGENT_REVIEW_STATUS"
    "OGENT_USEFULNESS"
    "OGENT_LINEAGE"
    "OGENT_OUTCOME"
    "OGENT_REVIEWED_AT"
    "OGENT_REVIEWER"
    "OGENT_REVIEW_NOTE")
  "Structured review properties persisted on Zen transcripts.")

(defun ogent-zen--review-timestamp ()
  "Return the current timestamp for review metadata."
  (format-time-string "%Y-%m-%dT%H:%M:%S%z"))

(defun ogent-zen--reviewer-id ()
  "Return the current reviewer identifier."
  (or user-login-name user-real-login-name user-full-name "unknown"))

(defun ogent-zen--set-entry-value (target property value)
  "Set PROPERTY on TARGET to VALUE, or clear it when VALUE is nil."
  (if value
      (org-entry-put target property value)
    (org-entry-delete target property)))

(defun ogent-zen--top-review-drawer-region (target)
  "Return the top-level review drawer region for TARGET, or nil."
  (save-excursion
    (goto-char target)
    (let ((end (ogent-zen--subtree-end))
          region)
      (forward-line 1)
      (when (looking-at "^[ \t]*:PROPERTIES:[ \t]*$")
        (ogent-zen--skip-drawer-at-point end '("PROPERTIES")))
      (skip-chars-forward "\n\t ")
      (when (looking-at "^[ \t]*:REVIEW:[ \t]*$")
        (let ((start (line-beginning-position)))
          (when (re-search-forward "^[ \t]*:END:[ \t]*$" end t)
            (forward-line 1)
            (setq region (cons start (point))))))
      region)))

(defun ogent-zen--review-drawer-point (target)
  "Return the insertion point for a review drawer under TARGET."
  (save-excursion
    (goto-char target)
    (let ((end (ogent-zen--subtree-end)))
      (forward-line 1)
      (when (looking-at "^[ \t]*:PROPERTIES:[ \t]*$")
        (ogent-zen--skip-drawer-at-point end '("PROPERTIES")))
      (point))))

(defun ogent-zen--review-drawer-lines (target)
  "Return visible review drawer lines for TARGET."
  (save-excursion
    (goto-char target)
    (let ((decision (ogent-zen--review-decision))
          (review-status (ogent-zen--review-status-value))
          (usefulness (ogent-zen--review-usefulness))
          (lineage (ogent-zen--review-lineage))
          (outcome (ogent-zen--review-outcome))
          (selected-model (org-entry-get (point) "OGENT_SELECTED_MODEL"))
          (reviewed-at (org-entry-get (point) "OGENT_REVIEWED_AT"))
          (reviewer (org-entry-get (point) "OGENT_REVIEWER"))
          (note (org-entry-get (point) "OGENT_REVIEW_NOTE")))
      (delq nil
            (list (when decision
                    (format "Decision: %s" decision))
                  (when review-status
                    (format "Review status: %s" review-status))
                  (when usefulness
                    (format "Usefulness: %s" usefulness))
                  (when lineage
                    (format "Lineage: %s" lineage))
                  (when outcome
                    (format "Outcome: %s" outcome))
                  (when selected-model
                    (format "Selected model: %s" selected-model))
                  (when reviewed-at
                    (format "Reviewed at: %s" reviewed-at))
                  (when reviewer
                    (format "Reviewer: %s" reviewer))
                  (when note
                    (format "Reason: %s" note)))))))

(defun ogent-zen--sync-legacy-review (target)
  "Mirror structured review metadata into legacy `OGENT_REVIEW' on TARGET."
  (let ((legacy (save-excursion
                  (goto-char target)
                  (or (let ((decision (ogent-zen--review-decision)))
                        (and (memq decision '(accepted rejected)) decision))
                      (let ((usefulness (ogent-zen--review-usefulness)))
                        (and (eq usefulness 'useful) usefulness))
                      (let ((review-status
                             (ogent-zen--review-status-value)))
                        (and (eq review-status 'needs-review) review-status))
                      (let ((lineage (ogent-zen--review-lineage)))
                        (and (memq lineage '(stale superseded)) lineage))
                      (let ((outcome (ogent-zen--review-outcome)))
                        (and (eq outcome 'failed) outcome))))))
    (ogent-zen--set-entry-value
     target "OGENT_REVIEW" (and legacy (symbol-name legacy)))))

(defun ogent-zen--sync-review-drawer (target)
  "Upsert or remove the visible review drawer for TARGET."
  (let ((region (ogent-zen--top-review-drawer-region target))
        (lines (ogent-zen--review-drawer-lines target)))
    (save-excursion
      (when region
        (delete-region (car region) (cdr region)))
      (when lines
        (goto-char (ogent-zen--review-drawer-point target))
        (insert ":REVIEW:\n")
        (dolist (line lines)
          (insert line "\n"))
        (insert ":END:\n")))))

(defun ogent-zen--clear-review-properties (target)
  "Delete structured review properties from TARGET."
  (dolist (property ogent-zen--review-properties)
    (org-entry-delete target property)))

(defun ogent-zen--sync-request-selected-model (request)
  "Synchronize `OGENT_SELECTED_MODEL' on REQUEST from accepted responses."
  (save-excursion
    (goto-char request)
    (let ((request-level (org-current-level))
          (end (ogent-zen--subtree-end))
          accepted useful)
      (forward-line 1)
      (while (re-search-forward org-heading-regexp end t)
        (beginning-of-line)
        (when (and (= (org-current-level) (1+ request-level))
                   (ogent-zen--response-heading-p))
          (let* ((heading (org-get-heading t t t t))
                 (model (ogent-zen--response-model-id heading))
                 (decision (ogent-zen--review-decision))
                 (usefulness-state (ogent-zen--review-usefulness)))
            (when (and (null accepted) (eq decision 'accepted))
              (setq accepted model))
            (when (and (null useful) (eq usefulness-state 'useful))
              (setq useful model))))
        (forward-line 1))
      (ogent-zen--set-entry-value
       request "OGENT_SELECTED_MODEL" (or accepted useful)))))

(defun ogent-zen--clear-sibling-accepted-responses (request keep-response)
  "Clear accepted sibling responses under REQUEST except KEEP-RESPONSE."
  (save-excursion
    (goto-char request)
    (let ((request-level (org-current-level))
          (end (ogent-zen--subtree-end)))
      (forward-line 1)
      (while (re-search-forward org-heading-regexp end t)
        (beginning-of-line)
        (when (and (= (org-current-level) (1+ request-level))
                   (ogent-zen--response-heading-p)
                   (/= (point) keep-response)
                   (eq (ogent-zen--effective-review-state) 'accepted))
          (org-entry-delete (point) "OGENT_DECISION")
          (org-entry-delete (point) "OGENT_REVIEW")
          (ogent-zen--sync-legacy-review (point))
          (ogent-zen--sync-review-drawer (point)))
        (forward-line 1)))))

(defun ogent-zen--stamp-review (target note)
  "Record review timestamp, reviewer, and NOTE on TARGET."
  (ogent-zen--set-entry-value target "OGENT_REVIEWED_AT"
                              (ogent-zen--review-timestamp))
  (ogent-zen--set-entry-value target "OGENT_REVIEWER"
                              (ogent-zen--reviewer-id))
  (ogent-zen--set-entry-value target "OGENT_REVIEW_NOTE" note))

(defun ogent-zen--resolve-review-target (&optional target-kind)
  "Return review target info plist for TARGET-KIND.
TARGET-KIND is one of nil, `run', or `response'."
  (let* ((request (ogent-zen--transcript-request-or-error))
         (response (pcase target-kind
                     ('run nil)
                     ('response
                      (or (ogent-zen--current-response-heading)
                          (ogent-zen--first-response-heading request)
                          (user-error "This Zen transcript has no response")))
                     (_ (ogent-zen--current-response-heading))))
         (target (or response request)))
    (list :request request
          :response response
          :target target
          :kind (if response 'response 'run)
          :model (and response
                      (save-excursion
                        (goto-char response)
                        (ogent-zen--response-model-id
                         (org-get-heading t t t t)))))))

(defun ogent-zen--update-review-target (target &rest properties)
  "Apply review PROPERTIES to TARGET, then sync legacy and visible metadata."
  (while properties
    (let ((property (pop properties))
          (value (pop properties)))
      (ogent-zen--set-entry-value target property value)))
  (ogent-zen--sync-legacy-review target)
  (ogent-zen--sync-review-drawer target))

(defun ogent-zen--set-review-state (state &optional target-kind)
  "Apply review STATE to the current Zen transcript TARGET-KIND."
  (let* ((info (ogent-zen--resolve-review-target target-kind))
         (request (plist-get info :request))
         (response (plist-get info :response))
         (target (plist-get info :target))
         (model (plist-get info :model)))
    (save-excursion
      (pcase state
        ((or `nil "clear")
         (ogent-zen--clear-review-properties target)
         (org-entry-delete target "OGENT_REVIEW")
         (ogent-zen--sync-review-drawer target))
        ("accepted"
         (ogent-zen--stamp-review target nil)
         (ogent-zen--update-review-target
          target
          "OGENT_DECISION" "accepted"
          "OGENT_REVIEW_STATUS" "reviewed"
          "OGENT_LINEAGE" "current"
          "OGENT_OUTCOME" "done")
         (when response
           (ogent-zen--clear-sibling-accepted-responses request response))
         (ogent-zen--stamp-review request nil)
         (ogent-zen--update-review-target
          request
          "OGENT_DECISION" (unless response "accepted")
          "OGENT_REVIEW_STATUS" "reviewed"
          "OGENT_LINEAGE" "current"
          "OGENT_SELECTED_MODEL" model))
        ("useful"
         (ogent-zen--stamp-review target nil)
         (ogent-zen--update-review-target
          target
          "OGENT_USEFULNESS" "useful"
          "OGENT_REVIEW_STATUS" "reviewed")
         (when response
           (ogent-zen--stamp-review request nil)
           (ogent-zen--update-review-target
            request
            "OGENT_REVIEW_STATUS" "reviewed"
            "OGENT_SELECTED_MODEL" model)))
        ("needs-review"
         (ogent-zen--stamp-review target nil)
         (ogent-zen--update-review-target
          target
          "OGENT_DECISION" nil
          "OGENT_USEFULNESS" nil
          "OGENT_REVIEW_STATUS" "needs-review"))
        ("stale"
         (ogent-zen--stamp-review target nil)
         (ogent-zen--update-review-target
          target
          "OGENT_LINEAGE" "stale"))
        ("superseded"
         (ogent-zen--stamp-review target nil)
         (ogent-zen--update-review-target
          target
          "OGENT_LINEAGE" "superseded"))
        ("rejected"
         (ogent-zen--stamp-review target nil)
         (ogent-zen--update-review-target
          target
          "OGENT_DECISION" "rejected"
          "OGENT_REVIEW_STATUS" "reviewed"))
        ("failed"
         (ogent-zen--stamp-review target nil)
         (ogent-zen--update-review-target
          target
          "OGENT_OUTCOME" "failed"
          "OGENT_REVIEW_STATUS" "reviewed"))
        (_
         (user-error "Unknown Zen review state: %s" state)))
      (when response
        (ogent-zen--sync-request-selected-model request)
        (ogent-zen--sync-review-drawer request))
      (ogent-zen-refresh-at request))))

(transient-define-infix ogent-zen--review-target-infix ()
  "Select the Zen review target for transient review actions."
  :description "Target"
  :class 'transient-option
  :key "-t"
  :argument "--target="
  :choices '("auto" "run" "response")
  :init-value (lambda (obj) (oset obj value "auto")))

(defun ogent-zen--review-menu-target-kind ()
  "Return the explicit review target selected in `ogent-zen-review-menu'."
  (let* ((args (ignore-errors (transient-args 'ogent-zen-review-menu)))
         (target (or (and args (transient-arg-value "--target=" args))
                     "auto")))
    (pcase target
      ("run" 'run)
      ("response" 'response)
      (_ nil))))

(defun ogent-zen--review-menu-apply-state (state)
  "Apply review STATE using the current review-menu target."
  (let ((target-kind (ogent-zen--review-menu-target-kind)))
    (if target-kind
        (ogent-zen--set-review-state state target-kind)
      (pcase state
        ("accepted" (ogent-zen-mark-accepted))
        ("rejected" (ogent-zen-mark-rejected))
        ("useful" (ogent-zen-mark-useful))
        ("needs-review" (ogent-zen-mark-needs-review))
        ("stale" (ogent-zen-mark-stale))
        ((or `nil "clear") (ogent-zen-clear-review))
        (_ (ogent-zen--set-review-state state))))))

(defun ogent-zen--review-menu-mark-accepted ()
  "Mark the selected Zen review target as accepted."
  (interactive)
  (ogent-zen--review-menu-apply-state "accepted"))

(defun ogent-zen--review-menu-mark-rejected ()
  "Mark the selected Zen review target as rejected."
  (interactive)
  (ogent-zen--review-menu-apply-state "rejected"))

(defun ogent-zen--review-menu-mark-useful ()
  "Mark the selected Zen review target as useful."
  (interactive)
  (ogent-zen--review-menu-apply-state "useful"))

(defun ogent-zen--review-menu-mark-needs-review ()
  "Mark the selected Zen review target as needing review."
  (interactive)
  (ogent-zen--review-menu-apply-state "needs-review"))

(defun ogent-zen--review-menu-mark-stale ()
  "Mark the selected Zen review target as stale."
  (interactive)
  (ogent-zen--review-menu-apply-state "stale"))

(defun ogent-zen--review-menu-clear ()
  "Clear review metadata from the selected Zen review target."
  (interactive)
  (ogent-zen--review-menu-apply-state nil))

;;;###autoload
(defun ogent-zen-set-review (state)
  "Set the review STATE for the Zen request or response at point."
  (interactive
   (list (let ((choice (completing-read
                        "Review state: "
                        (append
                         (mapcar (lambda (entry)
                                   (symbol-name (car entry)))
                                 ogent-zen--review-states)
                         '("clear"))
                        nil t)))
           (unless (string= choice "clear")
             choice))))
  (ogent-zen--set-review-state state))

;;;###autoload (autoload 'ogent-zen-review-menu "ogent-zen" nil t)
(transient-define-prefix ogent-zen-review-menu ()
  "Review the current Zen run or response."
  :value '("--target=auto")
  ["Target"
   (ogent-zen--review-target-infix)]
  ["Review"
   ("a" "Accept" ogent-zen--review-menu-mark-accepted)
   ("x" "Reject" ogent-zen--review-menu-mark-rejected)
   ("u" "Useful" ogent-zen--review-menu-mark-useful)
   ("m" "Needs review" ogent-zen--review-menu-mark-needs-review)
   ("s" "Stale" ogent-zen--review-menu-mark-stale)
   ("S" "Superseded" ogent-zen-mark-superseded)
   ("f" "Failed" ogent-zen-mark-failed)
   ("r" "Set state" ogent-zen-set-review)
   ("c" "Clear" ogent-zen--review-menu-clear)
   ("d" "Dashboard" ogent-review-dashboard)
   ("." "Describe" ogent-review-describe)]
  ["Quit"
   ("q" "Quit menu" transient-quit-one)])

;;;###autoload
(defun ogent-zen-accept-response ()
  "Accept the current Zen response and select it for the parent request."
  (interactive)
  (ogent-zen--set-review-state "accepted" 'response))

;;;###autoload
(defun ogent-zen-reject-response ()
  "Reject the current Zen response."
  (interactive)
  (ogent-zen--set-review-state "rejected" 'response))

;;;###autoload
(defun ogent-zen-mark-accepted ()
  "Mark the Zen request or response at point as accepted."
  (interactive)
  (ogent-zen--set-review-state "accepted"))

;;;###autoload
(defun ogent-zen-mark-useful ()
  "Mark the Zen request or response at point as useful."
  (interactive)
  (ogent-zen--set-review-state "useful"))

;;;###autoload
(defun ogent-zen-mark-needs-review ()
  "Mark the Zen request or response at point as needing review."
  (interactive)
  (ogent-zen--set-review-state "needs-review"))

;;;###autoload
(defun ogent-zen-mark-stale ()
  "Mark the Zen request or response at point as stale."
  (interactive)
  (ogent-zen--set-review-state "stale"))

;;;###autoload
(defun ogent-zen-mark-superseded ()
  "Mark the Zen request or response at point as superseded."
  (interactive)
  (ogent-zen--set-review-state "superseded"))

;;;###autoload
(defun ogent-zen-mark-rejected ()
  "Mark the Zen request or response at point as rejected."
  (interactive)
  (ogent-zen--set-review-state "rejected"))

;;;###autoload
(defun ogent-zen-mark-failed ()
  "Mark the Zen request or response at point as failed."
  (interactive)
  (ogent-zen--set-review-state "failed"))

;;;###autoload
(defun ogent-zen-clear-review ()
  "Clear the review state for the Zen request or response at point."
  (interactive)
  (ogent-zen--set-review-state nil))

;;; Zen dispatch

;;;###autoload (autoload 'ogent-zen-dispatch "ogent-zen" nil t)
(transient-define-prefix ogent-zen-dispatch ()
  "Dispatch menu for Zen Org transcripts."
  [["Run"
    ("RET" "Run subtree" ogent-run-subtree)
    ("!" "Rerun" ogent-zen-rerun)
    ("r" "Run region" ogent-zen-run-region)
    ("E" "Edit DWIM" ogent-zen-edit-dwim)
    ("A" "Apply last edit" ogent-zen-apply-last-edit)]
   ["Review"
    ("a" "Accept" ogent-zen-mark-accepted)
    ("x" "Reject" ogent-zen-mark-rejected)
    ("u" "Useful" ogent-zen-mark-useful)
    ("m" "Needs review" ogent-zen-mark-needs-review)
    ("s" "Stale" ogent-zen-mark-stale)
    ("c" "Clear" ogent-zen-clear-review)
    ("d" "Dashboard" ogent-review-dashboard)]
   ["Navigate"
    ("n" "Next run" ogent-zen-next-run :transient t)
    ("p" "Previous run" ogent-zen-previous-run :transient t)
    ("e" "Show error" ogent-zen-show-error)
    ("t" "Show tool calls" ogent-zen-show-tool-calls)
    ("TAB" "Toggle transcript" ogent-zen-toggle-transcript :transient t)]
   ["Display"
    ("D" "Cycle density" ogent-zen-cycle-density :transient t)
    ("b" "Toggle breadcrumbs" ogent-zen--toggle-breadcrumbs :transient t)
    ("l" "Toggle lanes" ogent-zen--toggle-visual-lanes :transient t)]])

(defvar-local ogent-review-dashboard-source-buffer nil
  "Source Org buffer shown by the current review dashboard.")

(defun ogent-zen--review-item-heading-p ()
  "Return non-nil when point is on a reviewable Zen heading."
  (or (ogent-zen--response-heading-p)
      (ogent-zen--request-heading-p)))

(defun ogent-zen--review-item-state (&optional target)
  "Return the queue state for TARGET or point."
  (or (let ((outcome (ogent-zen--review-outcome target)))
        (and (eq outcome 'failed) 'failed))
      (let ((lineage (ogent-zen--review-lineage target)))
        (and (eq lineage 'stale) 'stale))
      (let ((status (ogent-zen--review-status-value target)))
        (and (eq status 'needs-review) status))
      (let ((decision (ogent-zen--review-decision target)))
        (and (memq decision '(accepted rejected)) decision))
      (let ((usefulness (ogent-zen--review-usefulness target)))
        (and (eq usefulness 'useful) usefulness))
      (and (eq (ogent-zen--review-status-value target) 'reviewed)
           (org-entry-get (or target (point)) "OGENT_SELECTED_MODEL")
           'accepted)
      (let ((lineage (ogent-zen--review-lineage target)))
        (and (eq lineage 'superseded) lineage))
      'unreviewed))

(defun ogent-zen--request-reviewable-p ()
  "Return non-nil when the current request should appear in review queues."
  (or (not (ogent-zen--first-response-heading (point)))
      (ogent-zen--review-decision)
      (ogent-zen--review-status-value)
      (ogent-zen--review-usefulness)
      (ogent-zen--review-lineage)
      (ogent-zen--legacy-review-state)))

(defun ogent-zen--review-item-label ()
  "Return a compact label for the review item at point."
  (cond
   ((ogent-zen--response-heading-p)
    (format "response %s: %s"
            (ogent-zen--response-model-id (org-get-heading t t t t))
            (or (ogent-zen--response-title-from-text
                 (ogent-zen--response-body-text (point)))
                "answer")))
   ((ogent-zen--request-heading-p)
    (or (org-entry-get (point) "OGENT_RESULT_TITLE")
        (ogent-zen--request-display-title
         (substring-no-properties (org-get-heading t t t t)))))
   (t
    (substring-no-properties (org-get-heading t t t t)))))

(defun ogent-zen--collect-review-items ()
  "Return reviewable Zen items in the current buffer."
  (save-excursion
    (let (items)
      (goto-char (point-min))
      (while (re-search-forward org-heading-regexp nil t)
        (beginning-of-line)
        (when (and (ogent-zen--review-item-heading-p)
                   (or (ogent-zen--response-heading-p)
                       (ogent-zen--request-reviewable-p)))
          (push (list :marker (copy-marker (point))
                      :kind (if (ogent-zen--response-heading-p)
                                'response
                              'run)
                      :state (ogent-zen--review-item-state)
                      :path (or (ogent-zen--path-parent-label
                                 (org-entry-get (point) "OGENT_PATH"))
                                (org-entry-get (point) "OGENT_PATH"))
                      :label (ogent-zen--review-item-label))
                items))
        (forward-line 1))
      (nreverse items))))

(defun ogent-zen--review-attention-p (state)
  "Return non-nil when review STATE needs attention."
  (memq state '(unreviewed needs-review stale failed)))

(defun ogent-zen--jump-review-item (item)
  "Jump to review ITEM."
  (let ((marker (plist-get item :marker)))
    (unless (and (markerp marker) (marker-buffer marker))
      (user-error "Review item no longer exists"))
    (pop-to-buffer (marker-buffer marker))
    (goto-char marker)
    (when (fboundp 'org-fold-show-subtree)
      (org-fold-show-subtree))
    (recenter)))

(defun ogent-zen--review-step (direction)
  "Jump to the next pending review item in DIRECTION."
  (let* ((origin (point))
         (items (ogent-zen--collect-review-items))
         (positions
          (mapcar (lambda (item)
                    (cons (marker-position (plist-get item :marker)) item))
                  items))
         (ordered (sort positions (lambda (a b) (< (car a) (car b)))))
         target)
    (setq target
          (if (> direction 0)
              (or (cl-find-if
                   (lambda (entry)
                     (and (> (car entry) origin)
                          (ogent-zen--review-attention-p
                           (plist-get (cdr entry) :state))))
                   ordered)
                  (cl-find-if
                   (lambda (entry)
                     (ogent-zen--review-attention-p
                      (plist-get (cdr entry) :state)))
                   ordered))
            (or (cl-find-if
                 (lambda (entry)
                   (and (< (car entry) origin)
                        (ogent-zen--review-attention-p
                         (plist-get (cdr entry) :state))))
                 (reverse ordered))
                (cl-find-if
                 (lambda (entry)
                   (ogent-zen--review-attention-p
                    (plist-get (cdr entry) :state)))
                 (reverse ordered)))))
    (unless target
      (user-error "No Zen review items need attention"))
    (ogent-zen--jump-review-item (cdr target))))

(defconst ogent-review-dashboard--states
  '(unreviewed needs-review stale failed accepted useful rejected superseded)
  "Review states rendered by `ogent-review-dashboard-mode'.")

(defun ogent-review-dashboard--state-label (state)
  "Return a human label for review STATE."
  (or (alist-get state '((unreviewed . "Unreviewed")
                         (needs-review . "Needs review")
                         (stale . "Stale")
                         (failed . "Failed")
                         (accepted . "Accepted")
                         (useful . "Useful")
                         (rejected . "Rejected")
                         (superseded . "Superseded")))
      (symbol-name state)))

(defun ogent-review-dashboard--state-face (state)
  "Return the semantic face for review STATE."
  (pcase state
    ((or 'accepted 'useful) 'ogent-theme-success)
    ((or 'rejected 'failed) 'ogent-theme-error)
    ((or 'needs-review 'stale 'superseded) 'ogent-theme-warning)
    (_ 'ogent-theme-muted)))

(defvar ogent-review-dashboard-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "RET") #'ogent-review-dashboard-visit)
    (define-key map (kbd "g") #'ogent-review-dashboard-refresh)
    (define-key map (kbd "n") #'ogent-review-dashboard-next-item)
    (define-key map (kbd "p") #'ogent-review-dashboard-previous-item)
    (define-key map (kbd "TAB") #'ogent-section-toggle)
    (define-key map (kbd "<backtab>") #'ogent-section-cycle)
    (define-key map (kbd "M-n") #'ogent-section-next)
    (define-key map (kbd "M-p") #'ogent-section-prev)
    (define-key map (kbd "^") #'ogent-section-up)
    (define-key map (kbd "a") #'ogent-review-dashboard-mark-accepted)
    (define-key map (kbd "x") #'ogent-review-dashboard-mark-rejected)
    (define-key map (kbd "u") #'ogent-review-dashboard-mark-useful)
    (define-key map (kbd "m") #'ogent-review-dashboard-mark-needs-review)
    (define-key map (kbd "s") #'ogent-review-dashboard-mark-stale)
    (define-key map (kbd "?") #'ogent-review-dashboard-dispatch)
    (define-key map (kbd "q") #'quit-window)
    map)
  "Keymap for `ogent-review-dashboard-mode'.")

(ogent-section-define-mode ogent-review-dashboard-mode "Ogent-Review"
                           "Major mode for browsing Zen review queues."
  :group 'ogent-zen
  (ogent-section-configure-buffer)
  (setq-local buffer-read-only t)
  (setq-local truncate-lines t)
  (setq-local revert-buffer-function #'ogent-review-dashboard-refresh)
  (setq-local header-line-format
              '(:eval (ogent-review-dashboard--header-line))))

(defun ogent-review-dashboard--marker-at-point ()
  "Return the review marker on the current dashboard line."
  (ogent-section-item-at-point 'ogent-review-marker))

(defun ogent-review-dashboard--item-key-at-point ()
  "Return a stable key for the dashboard item at point."
  (when-let ((marker (ogent-review-dashboard--marker-at-point)))
    (and (markerp marker)
         (marker-buffer marker)
         (list (marker-buffer marker) (marker-position marker)))))

(defun ogent-review-dashboard--header-line ()
  "Return the review dashboard header line."
  (ogent-section-header-line
   "Review"
   (and (buffer-live-p ogent-review-dashboard-source-buffer)
        (buffer-name ogent-review-dashboard-source-buffer))
   '("?" . "menu")
   '("g" . "refresh")
   '("RET" . "visit")))

(defun ogent-review-dashboard-visit ()
  "Visit the review item at point."
  (interactive)
  (let ((marker (ogent-review-dashboard--marker-at-point)))
    (unless (and (markerp marker) (marker-buffer marker))
      (user-error "No review item on this line"))
    (pop-to-buffer (marker-buffer marker))
    (goto-char marker)
    (when (fboundp 'org-fold-show-subtree)
      (org-fold-show-subtree))
    (recenter)))

(defun ogent-review-dashboard--item-text (item)
  "Return display text for dashboard ITEM."
  (let ((kind (if (eq (plist-get item :kind) 'response) "response" "run"))
        (label (or (plist-get item :label) "untitled"))
        (path (plist-get item :path)))
    (concat "  "
            (propertize kind 'face 'ogent-theme-muted)
            " "
            label
            (if (and path (not (string-empty-p path)))
                (concat (propertize " · " 'face 'ogent-theme-muted)
                        (propertize path 'face 'ogent-theme-muted))
              ""))))

(defun ogent-review-dashboard--insert-state-section (state items)
  "Insert the review dashboard section for STATE from ITEMS."
  (let* ((state-items
          (cl-remove-if-not
           (lambda (item) (eq (plist-get item :state) state))
           items))
         (count (length state-items))
         (face (ogent-review-dashboard--state-face state))
         (heading (concat
                   (propertize (ogent-review-dashboard--state-label state)
                               'face 'ogent-theme-section-heading)
                   (when (> count 0)
                     (concat " " (ogent-theme-count-badge count face))))))
    (let ((section
           (ogent-section-with (ogent-review-dashboard-state)
               heading
             (if state-items
                 (dolist (item state-items)
                   (ogent-section-insert-item-line
                    (ogent-review-dashboard--item-text item)
                    'ogent-review-marker
                    (plist-get item :marker)
                    "RET visits this review item"))
               (insert (propertize "  No items\n" 'face 'ogent-theme-muted))))))
      (when (and section
                 (memq state '(accepted useful rejected superseded))
                 (ogent-section-usable-p)
                 (fboundp 'magit-section-hide))
        (magit-section-hide section)))))

(defun ogent-review-dashboard--insert (items)
  "Insert review dashboard ITEMS."
  (ogent-section-with-root (ogent-review-dashboard-root)
    (dolist (state ogent-review-dashboard--states)
      (ogent-review-dashboard--insert-state-section state items))))

(defun ogent-review-dashboard-refresh ()
  "Refresh the current review dashboard."
  (interactive)
  (unless (buffer-live-p ogent-review-dashboard-source-buffer)
    (user-error "Dashboard source buffer is gone"))
  (let ((inhibit-read-only t))
    (ogent-section-preserve-point (#'ogent-review-dashboard--item-key-at-point)
      (erase-buffer)
      (ogent-review-dashboard--insert
       (with-current-buffer ogent-review-dashboard-source-buffer
         (ogent-zen--collect-review-items))))))

(defun ogent-review-dashboard-next-item ()
  "Move point to the next visible review item."
  (interactive)
  (if-let ((pos (ogent-section-visible-item-position
                 'ogent-review-marker 'next)))
      (goto-char pos)
    (user-error "No next review item")))

(defun ogent-review-dashboard-previous-item ()
  "Move point to the previous visible review item."
  (interactive)
  (if-let ((pos (ogent-section-visible-item-position
                 'ogent-review-marker 'previous)))
      (goto-char pos)
    (user-error "No previous review item")))

(defun ogent-review-dashboard-mark (state)
  "Mark the dashboard item at point with review STATE."
  (interactive
   (list (let ((choice (completing-read
                        "Review state: "
                        '("accepted" "rejected" "useful" "needs-review"
                          "stale" "clear")
                        nil t)))
           (unless (string= choice "clear")
             choice))))
  (let ((marker (ogent-review-dashboard--marker-at-point)))
    (unless (and (markerp marker) (marker-buffer marker))
      (user-error "No review item on this line"))
    (with-current-buffer (marker-buffer marker)
      (save-excursion
        (goto-char marker)
        (ogent-zen--set-review-state state 'run)))
    (ogent-review-dashboard-refresh)))

(defun ogent-review-dashboard-mark-accepted ()
  "Mark the dashboard item at point as accepted."
  (interactive)
  (ogent-review-dashboard-mark "accepted"))

(defun ogent-review-dashboard-mark-rejected ()
  "Mark the dashboard item at point as rejected."
  (interactive)
  (ogent-review-dashboard-mark "rejected"))

(defun ogent-review-dashboard-mark-useful ()
  "Mark the dashboard item at point as useful."
  (interactive)
  (ogent-review-dashboard-mark "useful"))

(defun ogent-review-dashboard-mark-needs-review ()
  "Mark the dashboard item at point as needing review."
  (interactive)
  (ogent-review-dashboard-mark "needs-review"))

(defun ogent-review-dashboard-mark-stale ()
  "Mark the dashboard item at point as stale."
  (interactive)
  (ogent-review-dashboard-mark "stale"))

(defun ogent-review-dashboard-clear ()
  "Clear review metadata from the dashboard item at point."
  (interactive)
  (ogent-review-dashboard-mark nil))

;;;###autoload (autoload 'ogent-review-dashboard-dispatch "ogent-zen" nil t)
(transient-define-prefix ogent-review-dashboard-dispatch ()
  "Dispatch menu for Zen review dashboards."
  [["Mark"
    ("a" "Accept" ogent-review-dashboard-mark-accepted)
    ("x" "Reject" ogent-review-dashboard-mark-rejected)
    ("u" "Useful" ogent-review-dashboard-mark-useful)
    ("m" "Needs review" ogent-review-dashboard-mark-needs-review)
    ("s" "Stale" ogent-review-dashboard-mark-stale)
    ("c" "Clear" ogent-review-dashboard-clear)]
   ["Navigate"
    ("RET" "Visit" ogent-review-dashboard-visit)
    ("n" "Next item" ogent-review-dashboard-next-item :transient t)
    ("p" "Previous item" ogent-review-dashboard-previous-item :transient t)
    ("TAB" "Toggle section" ogent-section-toggle :transient t)
    ("M-n" "Next section" ogent-section-next :transient t)
    ("M-p" "Previous section" ogent-section-prev :transient t)
    ("^" "Up section" ogent-section-up :transient t)]
   ["View"
    ("g" "Refresh" ogent-review-dashboard-refresh :transient t)
    ("q" "Quit menu" transient-quit-one)]])

(with-eval-after-load 'evil
  (when (fboundp 'ogent-evil-display-mode-setup)
    (ogent-evil-display-mode-setup
     'ogent-review-dashboard-mode ogent-review-dashboard-mode-map
     'ogent-review-dashboard-mode-hook #'ogent-review-dashboard-refresh)))

;;;###autoload
(defun ogent-review-dashboard ()
  "Show a Zen review dashboard for the current Org buffer."
  (interactive)
  (unless (derived-mode-p 'org-mode)
    (user-error "Review dashboard requires an Org buffer"))
  (let ((source (current-buffer))
        (buffer (get-buffer-create "*ogent-review*")))
    (with-current-buffer buffer
      (ogent-review-dashboard-mode)
      (setq-local ogent-review-dashboard-source-buffer source)
      (ogent-review-dashboard-refresh))
    (pop-to-buffer buffer)))

;;;###autoload
(defun ogent-review-describe ()
  "Explain the current review target and stored metadata."
  (interactive)
  (if-let ((request (ogent-zen--transcript-request-heading)))
      (let* ((info (ogent-zen--resolve-review-target
                    (if (ogent-zen--current-response-heading)
                        'response
                      'run)))
             (target (plist-get info :target)))
        (with-help-window "*ogent-review*"
          (save-excursion
            (goto-char target)
            (princ (format "Target: %s\n"
                           (if (plist-get info :response)
                               (format "response %s"
                                       (plist-get info :model))
                             "run")))
            (princ (format "Primary state: %s\n"
                           (or (ogent-zen--effective-review-state) 'unreviewed)))
            (dolist (property (append ogent-zen--review-properties
                                      '("OGENT_REVIEW" "OGENT_SELECTED_MODEL")))
              (when-let ((value (org-entry-get (point) property)))
                (princ (format "%s: %s\n" property value)))))))
    (with-help-window "*ogent-review*"
      (princ "Completion review item.\n")
      (princ "Use C-c , a/x/n/p to accept, reject, or navigate completions.\n"))))

;;;###autoload
(defun ogent-review-next ()
  "Move to the next review item, using Zen or completion context."
  (interactive)
  (if (ogent-zen--transcript-request-heading)
      (ogent-zen--review-step 1)
    (call-interactively #'ogent-completion-next)))

;;;###autoload
(defun ogent-review-previous ()
  "Move to the previous review item, using Zen or completion context."
  (interactive)
  (if (ogent-zen--transcript-request-heading)
      (ogent-zen--review-step -1)
    (call-interactively #'ogent-completion-prev)))

;;;###autoload
(defun ogent-review-reject ()
  "Reject the current review item, using Zen or completion semantics."
  (interactive)
  (if (ogent-zen--transcript-request-heading)
      (if (ogent-zen--current-response-heading)
          (ogent-zen-reject-response)
        (ogent-zen--set-review-state "rejected" 'run))
    (call-interactively #'ogent-completion-reject)))

;;;###autoload
(defun ogent-review-useful ()
  "Mark the current Zen review item useful."
  (interactive)
  (unless (ogent-zen--transcript-request-heading)
    (user-error "Useful review is only available for Zen transcripts"))
  (ogent-zen--set-review-state "useful"))

;;;###autoload
(defun ogent-review-defer ()
  "Mark the current Zen review item as needing review."
  (interactive)
  (unless (ogent-zen--transcript-request-heading)
    (user-error "Deferred review is only available for Zen transcripts"))
  (ogent-zen--set-review-state "needs-review"))

;;;###autoload
(defun ogent-review-stale ()
  "Mark the current Zen review item stale."
  (interactive)
  (unless (ogent-zen--transcript-request-heading)
    (user-error "Stale review is only available for Zen transcripts"))
  (ogent-zen--set-review-state "stale"))

;;;###autoload
(defun ogent-zen-run-scope (scope &optional models preset templates)
  "Run Zen SCOPE with normal tree context preservation.
MODELS, PRESET, and TEMPLATES are forwarded to request dispatch unchanged."
  (let* ((start-marker (ogent-zen-scope-start-marker scope))
         (end-marker (ogent-zen-scope-end-marker scope))
         (region-start (ogent-zen--marker-position start-marker))
         (region-end (ogent-zen--marker-position end-marker))
         (heading-point (ogent-zen-scope-heading-point scope))
         (prompt (ogent-zen--scope-prompt scope)))
    (ogent-ui--dispatch-request
     (current-buffer) region-start region-end prompt models preset templates
     heading-point
     (lambda (context)
       (ogent-zen--context-transform-for-scope context scope)))))

;;;###autoload
(defun ogent-run-subtree (&optional models preset templates)
  "Run the current Org subtree as an ogent prompt.
The bullet at point (heading plus body and user children) becomes the
prompt; ancestor bullets are sent with full content as parent context.
When point is inside a generated transcript, the owning user bullet is
run instead.  MODELS, PRESET, and TEMPLATES are forwarded to the
request dispatch unchanged."
  (interactive)
  (ogent-zen-run-scope
   (ogent-zen--scope-at-point 'subtree)
   models preset templates))

;;;###autoload
(defun ogent-zen-run-region (question &optional models preset templates)
  "Ask QUESTION about the active region with Zen tree context.
MODELS, PRESET, and TEMPLATES are forwarded to request dispatch unchanged."
  (interactive
   (list (read-string "Ask about selected text: ")))
  (ogent-zen-run-scope
   (ogent-zen--scope-at-point 'region question nil)
   models preset templates))

;;;###autoload
(defun ogent-zen-edit-region (instruction &optional models preset templates)
  "Rewrite the active region according to INSTRUCTION with Zen context.
MODELS, PRESET, and TEMPLATES are forwarded to request dispatch unchanged."
  (interactive
   (list (read-string "Rewrite selected text: ")))
  (ogent-zen-run-scope
   (ogent-zen--scope-at-point 'region instruction t)
   models preset templates))

;;;###autoload
(defun ogent-zen-rewrite-paragraph (instruction &optional models preset templates)
  "Rewrite the paragraph at point according to INSTRUCTION with Zen context.
MODELS, PRESET, and TEMPLATES are forwarded to request dispatch unchanged."
  (interactive
   (list (read-string "Rewrite paragraph: ")))
  (ogent-zen-run-scope
   (ogent-zen--scope-at-point 'paragraph instruction t)
   models preset templates))

;;;###autoload
(defun ogent-zen-rewrite-sentence (instruction &optional models preset templates)
  "Rewrite the sentence at point according to INSTRUCTION with Zen context.
MODELS, PRESET, and TEMPLATES are forwarded to request dispatch unchanged."
  (interactive
   (list (read-string "Rewrite sentence: ")))
  (ogent-zen-run-scope
   (ogent-zen--scope-at-point 'sentence instruction t)
   models preset templates))

;;;###autoload
(defun ogent-zen-edit-dwim (instruction &optional models preset templates)
  "Rewrite the active region or nearest text element according to INSTRUCTION.
MODELS, PRESET, and TEMPLATES are forwarded to request dispatch unchanged."
  (interactive
   (list (read-string "Rewrite here: ")))
  (ogent-zen-run-scope
   (ogent-zen--scope-at-point nil instruction t)
   models preset templates))

;;;###autoload
(defun ogent-zen-rerun ()
  "Re-run the Zen transcript at point, or run the current bullet.
On a generated `Request:' / `Response' transcript, delete that
transcript and dispatch the owning bullet again: edit the bullet, then
re-run.  Anywhere else this behaves like `ogent-run-subtree'.  A
still-streaming transcript must be aborted before it can be re-run.
The deletion and the new run form one undoable change group."
  (interactive)
  (unless (derived-mode-p 'org-mode)
    (user-error "Run subtree requires an Org buffer"))
  (let ((request (ogent-zen--transcript-request-heading)))
    (if (null request)
        (ogent-run-subtree)
      (save-excursion
        (goto-char request)
        (let ((info (ogent-zen--src-info (ogent-zen--subtree-end))))
          (when (member (car-safe info) '("waiting" "typing" "tool"))
            (user-error "This run is still streaming; abort it first"))))
      (let* ((edit-p (equal (org-entry-get request "OGENT_KIND") "edit"))
             (scope (and edit-p
                         (ogent-zen-edit--scope-from-transcript request)))
             (parent (save-excursion
                       (goto-char request)
                       (and (org-up-heading-safe) (point)))))
        (unless parent
          (user-error "No user bullet above this run"))
        (atomic-change-group
          (goto-char request)
          (delete-region (point)
                         (save-excursion (org-end-of-subtree t t) (point)))
          (if scope
              (ogent-zen-run-scope scope)
            (goto-char parent)
            (ogent-run-subtree)))))))

(defun ogent-zen--ctrl-c-ctrl-c ()
  "Re-run the Zen transcript at point for `org-ctrl-c-ctrl-c-hook'.
Return non-nil only when point is on a generated Zen transcript."
  (when (and ogent-zen-mode
             (ogent-zen--transcript-request-heading))
    (ogent-zen-rerun)
    t))

(provide 'ogent-zen)
;;; ogent-zen.el ends here

# Scorer A paired calibration

These are same-model qualitative judgments, not measured agent success rates. The baseline was independently scored from exact b3caf930 source and actual probes using the current scoring criteria, without importing historical numeric scores or another scorer's judgments. Baseline build output is actual human output; `--json` is unavailable. Historical passes are outside this paired comparison.

The same applicability choices apply to both sides:

- Raw positional SDK helpers earn one-call ergonomics credit. Method-name intent is applicable and zero where direct misspellings and underscore/family aliases are void functions. Named dispatch aliases do not repair the raw Lisp method name.
- Raw writes, edits and shell execution own no approval gate. Their safety is applicable and zero even when a registered wrapper gates the same operation. Validation and cancellation receive correctness credit only.
- Read-only lookup/search/doctor methods receive safety1000 with `n/a:true`. Build compile/recompile/clean only change regenerable bytecode; protected offline fixtures isolate user stores, so those also receive safety n/a.
- Legacy strings are human data at parseability250; native named-key SDK objects use the SDK adaptation. Callback event methods retain their own legacy contract. New named APIs have separate extension rows and no baseline.
- Make help/clean/offline use the disclosed basic process/human-output partial parseability250 anchor. Actual baseline compiler failures preserve Make status but emit timestamped ANSI logs despite NO_COLOR/CI/TERM=dumb; the stderr logger limits composability to250. Current build reports contain real volatile PIDs and helper paths, so both baseline and current build determinism remain250 for their different observed reasons.

Exact top-level source-form identity and paired probes keep unchanged raw async/write/edit, enabled listing and doctor scores unchanged. Scoped clean and offline preflight behavior also retain their scores. Reported paired changes come from observed structured raw results/snapshots, newly registered semantic aliases, typed wrapper errors, and actual machine build reports/discovery. Existing baseline pagination/error/doctor tests already earned their corresponding regression credit.

The first baseline SDK run was detected as loading current source because the protected helper prepends current lisp paths. Its transcript is archived as setup contamination and excluded. The scored rerun explicitly selects baseline paths after the helper and asserts the loaded read-file definition path. Source snapshots are checked against git blobs. Small real build fixtures run exact helpers with actual Emacs; they do not replace or stub makem. Full shared-project compile/test was not run by this scorer.


## Shared incremental revalidation at ff4e96c

Current source is `ff4e96c21d5fb3ffe79843fbce8392390d1c8bf4`; the retained
independent numerical judgments were selected at
`a2fa8ce0533b4a508fb641f343fa55b15fd6fc60`. This update is one shared incremental
validation of those judgments, not new independent blind full readings of the
nineteen surfaces. The original raw A/B/T rows remain in the immutable
`interim_a2fa8ce_scoring.tar.gz` archive. All numerical vectors, paired baseline
bytes and earlier runtime transcripts/target markers are unchanged.

The coordinator repaired two discoveries made during the 021 refresh: selected
raw-byte filenames were silently filtered by structured glob before Unicode
validation, and Emacs 30 returned UTF-8 unibyte JSON that actual gptel could not
nest in a request. The invalidated 021 evidence retains both logger failures and
the genuine actual-gptel serializer failure in
[interim validation](../scorerA/incremental_021cca4/validation_021_pre_repair.json).
The final logger normalizes only its evidence representation; the actual
transport probe receives the product result unchanged and applies actual
gptel tool-call processing, the actual OpenAI backend result adapter and the
actual request JSON serializer. A second pending fixture call prevents FSM
advancement or network dispatch. Both runtimes now encode the original Unicode
content successfully. No provider, authentication or inference request was made.

Four new processes on real Emacs 29.1/30.2 produce **34 valid UTF-8 JSON records**:
28 behavior records and six identity guards. They cover valid/empty Unicode,
raw-byte rejection, physical raw-byte flat/recursive glob refusal, structured
read/glob repeat bytes, named calls/continuations/immediate callbacks, batch
list/vector composition, whole preflight and fail-fast, discovery/schema,
protected local doctor JSON, actual gptel tool objects and request nesting.
No full native suite or build battery was rerun by this refresh. Source guards
verify all 194 tracked production/test/build files before and after execution.
The focused citation guard fingerprints 21 files; 13 have identical Git blobs.
Actual parsed source forms identify 163 unchanged executable definitions and
six changed definitions; the private JSON-text helper is new. Thus ledger,
process, approval, raw mutation and registry evidence retain explicit unchanged
body/blob support despite localized serializer changes within larger modules.

The repairs restore the intended existing contracts within the selected bands.
They do not introduce aliases, new schemas, leases or rollback. The same anchor
interpretations and all original numbers therefore remain justified. Existing
actual Makefile/makem reports remain old executions: both owners are byte-for-byte
identical to a2fa, and 27 existing JSON reports were reparsed without new build
commands or relabeling their raw source targets. Build volatility limits remain.

[Final validation](../scorerA/incremental_final/validation.json),
[source identities](../scorerA/incremental_final/source_identities.json),
[definition identities](../scorerA/incremental_final/definition_identities.json),
[reused build reports](../scorerA/incremental_final/reused_build_reports.json) and
[preservation](../scorerA/incremental_final/preservation.json) distinguish fresh
execution from reuse. All >700 evidence remains concrete; current source hashes
and 100 citation offsets are refreshed, while 353 old runtime citations retain
their original lines and artifact hashes. A's 196 baseline artifacts and the
original B nineteen/T nine paired baseline rows remain byte-identical.

# Scorer A paired calibration

These are same-model qualitative judgments, not measured agent success rates. The baseline was independently scored from exact b3caf930 source and actual probes using the current scoring criteria, without importing historical numeric scores or another scorer's judgments. Baseline build output is actual human output; `--json` is unavailable. Historical passes are outside this paired comparison.

The same applicability choices apply to both sides:

- Raw positional SDK helpers earn one-call ergonomics credit. Method-name intent is applicable and zero where direct misspellings and underscore/family aliases are void functions. Named dispatch aliases do not repair the raw Lisp method name.
- Raw writes, edits and shell execution own no approval gate. Their safety is applicable and zero even when a registered wrapper gates the same operation. Validation and cancellation receive correctness credit only.
- Read-only lookup/search/doctor methods receive safety1000 with `n/a:true`. Build compile/recompile/clean only change regenerable bytecode; protected offline fixtures isolate user stores, so those also receive safety n/a.
- Legacy strings are human data at parseability250; native named-key SDK objects use the SDK adaptation. Callback event methods retain their own legacy contract. New named APIs have separate extension rows and no baseline.
- Make help/clean/offline use the disclosed basic process/human-output partial parseability250 anchor. Actual baseline compiler failures preserve Make status but emit timestamped ANSI logs despite NO_COLOR/CI/TERM=dumb; the stderr logger limits composability to250. Current build reports contain real volatile PIDs and helper paths, so both baseline and current build determinism remain250 for their different observed reasons.

Exact top-level source-form identity and paired probes keep unchanged raw async/write/edit, enabled listing and doctor scores unchanged. Scoped clean and offline preflight behavior also retain their scores. Reported paired changes come from observed structured raw results/snapshots, newly registered semantic aliases, typed wrapper errors, and actual machine build reports/discovery. Existing baseline pagination/error/doctor tests already earned their corresponding regression credit.

The first baseline SDK run was detected as loading current source because the protected helper prepends current lisp paths. Its transcript is archived as setup contamination and excluded. The scored rerun explicitly selects baseline paths after the helper and asserts the loaded read-file definition path. Source snapshots are checked against git blobs. Small real build fixtures run exact helpers with actual Emacs; they do not replace or stub makem. Full shared-project compile/test was not run by this scorer.

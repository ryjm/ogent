# Pass 3 intermediate handoff —ledger-corrected freeze pending

The user's second full implementation batch ships eleven tested production
behavior upgrades on `master` inside `/workspace/ogent`. Baseline is
`b3caf9300c7336ef812ed061158f851c5a47ccf7`; intermediate production snapshot is `967eb054e13104d05e818656a2b78f037cc0effd`; the ledger-corrected final freeze is pending. No branch, PR, provider
authentication or inference was used. This document records completed evidence
and explicitly unfinished delivery gates.

## What changed

| ID | Implemented behavior | Primary commit | Regression wrapper |
|---|---|---|---|
| R013 | Named approval-aware calls with typed outcomes | `2fbc156` | `audit/regression_tests/R013__named_calls.test.sh` |
| R014 | Bounded file pages with exact long-line continuation | `0829b08` | `audit/regression_tests/R014__structured_reads.test.sh` |
| R015 | Complete discovery through structured file pagination | `a1793a8` | `audit/regression_tests/R015__complete_glob_pages.test.sh` |
| R016 | Follow guarded tool continuations in one call | `e9c9af4` | `audit/regression_tests/R016__continuation_calls.test.sh` |
| R017 | Familiar exact verbs with collision-safe policy resolution | `a2b3922` | `audit/regression_tests/R017__common_verbs.test.sh` |
| R018 | Structured search and bounded real process outcomes | `1cde7ab` | `audit/regression_tests/R018__structured_processes.test.sh` |
| R019 | Async agent calls with one precise terminal callback and ledger | `3ced858` | `audit/regression_tests/R019__async_sdk.test.sh` |
| R020 | Preflighted batches of declared read-only calls | `974eb31` | `audit/regression_tests/R020__read_only_batches.test.sh` |
| R021 | Live callable contracts, executable examples and result schema | `d6263d1` | `audit/regression_tests/R021__live_contracts.test.sh` |
| R022 | Structured JSON contracts for registered model tools | `66bc5e8` | `audit/regression_tests/R022__model_json_contract.test.sh` |
| R023 | Actual build/test JSON with typed failures and recovery | `b974cd7` | `audit/regression_tests/R023__actual_build_reports.test.sh` |


Versioned named calls, complete bounded file/search pages and guarded continuations
let agents consume results without parsing presentation text or guessing restart
positions. Real process outcomes separate channels, exit/timeout/cancellation and
retained partial output. Async callbacks and read-only batches share the existing
approval/review/ledger owners. Live descriptions/examples/schema expose real call
shapes; optional model JSON and actual makem JSON extend explicit contracts.

Followups include frozen arguments/targets and object hash content, schema cache
refresh, Unicode ripgrep candidate groups, correct structured history replay/status,
JSON-safe boundary failures and compiler EOF/source locations. They remain part
of the original eleven changes, not additional recommendation counts.

## Completed paired measurements —967 intermediate snapshot

Completed same-criteria paired aggregation for intermediate `967eb05` compares
19 original surfaces with genuine baseline `b3caf93`: mean **605.26 → 656.21**,
all-surface median **+11**, and median **77.5** over the ten positively changed
original surfaces. Nine original surfaces gain at least 100 points on a dimension;
no paired dimension/surface regresses. Six new APIs remain unpaired current-only
records, excluded from the paired mean. All A/B/third readings are published.

These are valid rubric judgments for this intermediate snapshot, not completed
measurements of the future ledger-corrected freeze. Eleven tested behavior
upgrades share surfaces and do not establish eleven unique causal numeric gains.
The main paired artifacts use calibrated baseline pass 3/current pass 4; these
pass_3 reports identify the implementation batch. Historical pass 1/2 records
remain unchanged. `rubric_reconciliation_pass_3.md` retains applicability and
third-reading decisions. Prior 9ac13b2 scoring/audit states remain in
`evidence/pass_3/interim_9ac13b2_scoring.tar.gz` and
`evidence/pass_3/interim_9ac13b2_audit.tar.gz`. Root will archive the complete
967eb05 state before promoting any later source snapshot.


Build JSON credit is limited to historical help/compile/recompile and new
lint/test/runner extension coverage. The unchanged offline-test target receives
no build-JSON output credit.

## Completed proof and pending promotion gates

Intermediate production snapshot is `967eb054e13104d05e818656a2b78f037cc0effd`; the next final freeze is pending. Source/test-only correction
`967eb05` belongs to R018. GNU and ripgrep now share metadata-selected sorted
files, include file-link paths, and skip descendant directory links. Selected
non-UTF-8 filenames fail explicitly; excluded file contents are not opened.
Raw-NUL binary classification, including late NUL and UTF BOM cases, runs inside
the owned async process before matching/counting. Ripgrep receives exact ordered
file argv in 128-name batches, without JSON path remapping or new dependencies.

The deliberate cost is a per-file classifier read plus a second read of text
candidates, all under the existing process timeout/cancel/cleanup owner.
Focused SDK/process/debug suites pass 193 tests (43/51/99) on Emacs 29/30;
style/checkdoc and warning-gated compilation also pass. Full native checks remain
separate.

The reviewed `967eb05` snapshot is **intermediate**, not the final completion
freeze. `phase7_pass_3_review_round 7.md` reports a substantive P2: a terminal
ledger filesystem failure can suppress the asynchronous SDK/model callback.
The integration owner accepted the finding and a ledger-recovery source fix is
in progress. Its commit/freeze is **PENDING_NEW_FINAL_FREEZE**. No future fix or
pass is claimed by these files.

Round 5 was clean at old 9ac13b2; rounds 6 and 7 were unclean. After the new fix
and source freeze, reviews **PENDING_REVIEW_ROUND_8** and
**PENDING_REVIEW_ROUND_9** must be consecutively clean. Native supported-version
validation is **PENDING_FINAL_NATIVE_REPORT**; root delivery/CI remains
**PENDING_ROOT_FINAL_VALIDATION_AND_DELIVERY**. The completed intermediate tests,
proofs and scores do not replace these gates.

`verification/pass_3/regression_proof.json` is now complete at exact `967eb05`:
all eleven genuine baseline failures and current passes are proven. Its final
integrity check validates source/fixture identities, complete execution, zero
current skips and zero timeouts. Current R018 executes 51 process plus two
integration tests (53); R013 overlaps 43 SDK tests and R023 has 23 real-runner
shell cases. The old `9ac13b2` proof remains valid intermediate history under
`verification/pass_3/regressions/interim-9ac13b2/`. Do not add overlapping
selectors or mix ERT and shell count units. Passing these selected regressions
does not negate the new independently reproduced ledger failure.


| Gate | Current result |
|---|---|
| Production source | `967eb054e13104d05e818656a2b78f037cc0effd` |
| Shared paired measurements | Intermediate `967eb05`:605.26→656.21, median+11; final source pending |
| Positively changed originals | Intermediate `967eb05`:ten, median77.5 |
| ≥100-point dimensional gains | Intermediate `967eb05`:nine original surfaces; no unique per-commit attribution |
| New API measurements | Six current-only records; separate from paired uplift |
| R013…R023 baseline/current proofs | All eleven proven at intermediate `967eb05`; integrity passes |
| Fresh source-blind tasks | 9/9 completed, 7/9 first strategy, 94 defined round trips on historical revisions |
| Final-freeze repeated regression tasks | 9/9 completed, 89 round trips; familiarity prevents fresh-discovery/efficiency claims |
| Prior reviews 5/6 | Round 5 clean at9ac; round 6 unclean breaks streak |
| New clean-review gate | Round7 unclean; new freeze then consecutive clean rounds 8/9 required |
| Full supported-version native tests/lint/offline/isolation | **PENDING_FINAL_NATIVE_REPORT** |
| Root final validation, commit/delivery and CI | **PENDING_ROOT_FINAL_VALIDATION_AND_DELIVERY** |

Initial native lint failed before correction. Initial and invalidated-freeze
proofs remain intermediate evidence; they cannot stand for final native checks.
The intermediate `967eb05` proof has no skipped current ERT cases or timeouts. Its R023 shell cases use a
different count unit, and the broad R013 selector overlaps later wrappers.

## Practical task evidence and limits

The original fresh source-blind exercise completed **9/9** tasks, **7/9** with
the first strategy, in **94** public round trips, mostly at `07f775a` with batch `895bed7`.
The seven-line README exercise accounts for 63 calls. Its preserved
`agent_simulations/post_pass_3/summary.json` supports no comparative efficiency
claim.

The familiar `967eb05` repeated replay completed **9/9** tasks in **89** round trips,
with identical start/end SHA. It reused workflows/fixtures, so gets no fresh
first-strategy or efficiency metric. See
`agent_simulations/post_pass_3/final_freeze/summary.json`; prior `9ac13b2` is archived.
Both observed GNU fallback, a protected helper that can supply gptel doubles,
and isolated builds. Neither certifies live provider transport or full native
checks. No provider login/inference occurred.


## Durable artifacts and next operator

- `recommendations_pass_3.jsonl`: exactly R013…R023, primary commits/Beads,
  intended dimensions, source references and global numeric-attribution limits.
- `applied_changes_pass_3.jsonl`: 33 exact selected source hunks and line
  coordinates, full followup SHAs, baseline/freeze proof paths and case units.
- `recommendation_hunks_pass_3.md`: readable primary-commit source hunks and
  final evidence/status appendix. Primary hunks compare each commit to its parent.
- `playbook_pass_3.md`: verification method, review corrections, replay and limits.
- `ambition_bar_pass_3.md`: mandatory verbatim self-prompt, eleven qualitative
  upgrades versus nine numeric original surfaces, and honest median-uplift limits.
- `phase7_pass_3_review_initial.md` and round 2/3/4 reports: real findings,
  corrected in followups; no clean streak certification.

The integration owner handles root manifest/HANDOFF reconciliation, main score
promotion, final validation, source archives, staging/commits, delivery and CI.
This evidence writer does not edit production/tests, stage or commit files.
When final review/native reports arrive, replace pending fields only with actual
freeze-bound results. Any substantive finding requires a corrected new freeze
and rerunning dependent verification; preserve the same eleven recommendation IDs.

## Source archive and scope boundaries

Raw baseline source and isolated build/test fixtures under audit evidence must
stay out of tracked `.el` discovery: `makem.sh` uses `git ls-files`. The integration
owner controls exact ignore exclusions and source archives after writers finish;
these reporting files do not move, gzip or stage live scorer inputs. Baseline
source is reproducible with `git archive b3caf9300c7336ef812ed061158f851c5a47ccf7 lisp makem.sh`; the recorder
checks extracted bytes against Git and retains source hash manifests. Cite any
final archive index only after its members and hashes are recorded.


Persistent resume tokens, dependent batches and transport redesign remain future
features. Fuzzy guesses are not auto-executed. Unsupported undecodable filenames
fail explicitly; snapshot guards do not promise filesystem transactions. No
provider transport, latency or comparative efficiency claim is supported.

# Pass 3 implementation playbook —967 intermediate state

This is the user's second full implementation batch. Scope is the existing
local tool/SDK/build surfaces: call, inspect, continue, compose and diagnose them.
Work lands directly on `master` inside `/workspace/ogent`; no branch, PR,
provider authentication or inference belongs to this pass.

## Implemented recommendations

| ID | Implemented behavior | Primary commit | Regression wrapper |
|---|---|---|---|
| R013 | Named approval-aware calls with typed outcomes | `2fbc156` | `audit/regression_tests/R013__named_calls.test.sh` |
| R014 | Bounded file pages with exact long-line continuation | `0829b08` | `audit/regression_tests/R014__structured_reads.test.sh` |
| R015 | Complete discovery through structured file pagination | `a1793a8` | `audit/regression_tests/R015__complete_glob_pages.test.sh` |
| R016 | Follow guarded tool continuations in one call | `e9c9af4` | `audit/regression_tests/R016__continuation_calls.test.sh` |
| R017 | Familiar exact verbs with collision-safe policy resolution | `a2b3922` | `audit/regression_tests/R017__common_verbs.test.sh` |
| R018 | Structured search and bounded real process outcomes | `1cde7ab` | `audit/regression_tests/R018__structured_processes.test.sh` |
| R019 | Async agent calls with one precise terminal callback and ledger | `3ced858` | `audit/regression_tests/R019__async_sdk.test.sh` |
| R020 | Preflighted batches of declared read-only calls | `974eb31` | `audit/regression_tests/R020__read_only_batches.test.sh` |
| R021 | Live callable contracts, executable examples and result schema | `d6263d1` | `audit/regression_tests/R021__live_contracts.test.sh` |
| R022 | Structured JSON contracts for registered model tools | `66bc5e8` | `audit/regression_tests/R022__model_json_contract.test.sh` |
| R023 | Actual build/test JSON with typed failures and recovery | `b974cd7` | `audit/regression_tests/R023__actual_build_reports.test.sh` |


Eleven distinct production behaviors landed through eleven primary Conventional
Commits. Exact parent/current source coordinates and 33 complete selected hunks
are in `applied_changes_pass_3.jsonl` and `recommendation_hunks_pass_3.md`.
Those primary hunks preserve the implementation trail; final behavior also
includes the followup fixes listed in the applied ledger. Tests, whitespace,
documentation-only commits and correction followups do not increase the count.
The retrospective `priority: 0` field is explicitly unranked; empty expected
uplift maps avoid inventing ex ante estimates.

## Completed paired measurements —967 intermediate snapshot

Completed same-criteria paired aggregation for intermediate `967eb05` compares
19 original surfaces with genuine baseline `b3caf93`: mean **605.26 → 656.21**,
all-surface median **+11**, and median **77.5** over the ten positively changed
original surfaces. Nine original surfaces gain at least 100 points on a dimension;
no paired dimension/surface regresses. Six new APIs remain unpaired current-only
records, excluded from the paired mean. All A/B/third readings are published.

These are valid rubric judgments for this intermediate snapshot, not completed
measurements of the future ledger-corrected freeze. Eleven tested behavior
upgrades share surfaces and do not establish eleven unique causal numeric gains.
The main paired artifacts use calibrated baseline pass 3/current pass 4; these
pass_3 reports identify the implementation batch. Historical pass 1/2 records
remain unchanged. `rubric_reconciliation_pass_3.md` retains applicability and
third-reading decisions. Prior 9ac13b2 scoring/audit states remain in
`evidence/pass_3/interim_9ac13b2_scoring.tar.gz` and
`evidence/pass_3/interim_9ac13b2_audit.tar.gz`. Root will archive the complete
967eb05 state before promoting any later source snapshot.


Build JSON attribution covers historical make help/compile/recompile. Newly
supported lint/test and runner JSON are extension coverage. The unchanged
`make offline-test` target receives no build-JSON output credit; offline checks
validate actual local dependency integration.

## Verification and remaining gates

Intermediate production snapshot is `967eb054e13104d05e818656a2b78f037cc0effd`; the next final freeze is pending. Source/test-only correction
`967eb05` belongs to R018. GNU and ripgrep now share metadata-selected sorted
files, include file-link paths, and skip descendant directory links. Selected
non-UTF-8 filenames fail explicitly; excluded file contents are not opened.
Raw-NUL binary classification, including late NUL and UTF BOM cases, runs inside
the owned async process before matching/counting. Ripgrep receives exact ordered
file argv in 128-name batches, without JSON path remapping or new dependencies.

The deliberate cost is a per-file classifier read plus a second read of text
candidates, all under the existing process timeout/cancel/cleanup owner.
Focused SDK/process/debug suites pass 193 tests (43/51/99) on Emacs 29/30;
style/checkdoc and warning-gated compilation also pass. Full native checks remain
separate.

The reviewed `967eb05` snapshot is **intermediate**, not the final completion
freeze. `phase7_pass_3_review_round 7.md` reports a substantive P2: a terminal
ledger filesystem failure can suppress the asynchronous SDK/model callback.
The integration owner accepted the finding and a ledger-recovery source fix is
in progress. Its commit/freeze is **PENDING_NEW_FINAL_FREEZE**. No future fix or
pass is claimed by these files.

Round 5 was clean at old 9ac13b2; rounds 6 and 7 were unclean. After the new fix
and source freeze, reviews **PENDING_REVIEW_ROUND_8** and
**PENDING_REVIEW_ROUND_9** must be consecutively clean. Native supported-version
validation is **PENDING_FINAL_NATIVE_REPORT**; root delivery/CI remains
**PENDING_ROOT_FINAL_VALIDATION_AND_DELIVERY**. The completed intermediate tests,
proofs and scores do not replace these gates.

`verification/pass_3/regression_proof.json` is now complete at exact `967eb05`:
all eleven genuine baseline failures and current passes are proven. Its final
integrity check validates source/fixture identities, complete execution, zero
current skips and zero timeouts. Current R018 executes 51 process plus two
integration tests (53); R013 overlaps 43 SDK tests and R023 has 23 real-runner
shell cases. The old `9ac13b2` proof remains valid intermediate history under
`verification/pass_3/regressions/interim-9ac13b2/`. Do not add overlapping
selectors or mix ERT and shell count units. Passing these selected regressions
does not negate the new independently reproduced ledger failure.


Initial native lint failed before correction. Earlier native outputs and proofs
at invalidated `3cb0cd7`/`90818f8` remain intermediate evidence. Never relabel
them as final freeze checks. Source/fixture identities in the final proof distinguish
real baseline failures from timeouts, missing selections or invented stubs.

## Review-driven corrections

The initial review drove bounded descendant stderr drains, post-approval registry
replacement checks, failure-aware ledger terminals, component-safe glob stars,
empty-candidate regex validation and final-newline metadata. Round 2 drove
in-place metadata snapshots, JSON-safe unsupported filenames with callback-once
completion, smaller configured read defaults, explicit-file search filter parity
and structured debug history replay/error/status plus actual JSON history arrays.
Round 3 drove frozen batch tool/argument plans and shared component/recursive
filter rules. Round 4 drove copied supported object hash tables, deep metadata
content comparison, nested model schema cache refresh and Unicode wildcard
candidate parity. Existing focused suites passed before these additional probes
found real defects; review breadth matters independently of test count.

Shared corrections include `a820ac0`, `07f775a`, `0d2fea6`, `7c0d9d8`,
`895bed7`, `0f7273e`, `8e93242`, `5b0f158`, `3cb0cd7`, `ed044fb`,
`19f154a`, `90818f8`, `08dfaad`, `a99000d`, `9ac13b2`, and `967eb05`. The applied
ledger stores full SHAs and relevant mappings; none is a twelfth recommendation.

## Practical task evidence

The original fresh source-blind exercise completed **9/9** tasks, **7/9** with
the first strategy, in **94** public round trips, mostly at `07f775a` with batch `895bed7`.
The seven-line README exercise accounts for 63 calls. Its preserved
`agent_simulations/post_pass_3/summary.json` supports no comparative efficiency
claim.

The familiar `967eb05` repeated replay completed **9/9** tasks in **89** round trips,
with identical start/end SHA. It reused workflows/fixtures, so gets no fresh
first-strategy or efficiency metric. See
`agent_simulations/post_pass_3/final_freeze/summary.json`; prior `9ac13b2` is archived.
Both observed GNU fallback, a protected helper that can supply gptel doubles,
and isolated builds. Neither certifies live provider transport or full native
checks. No provider login/inference occurred.


## Evidence source archiving and build discovery

Raw baseline source and isolated build/test fixtures under audit evidence must
stay out of tracked `.el` discovery: `makem.sh` uses `git ls-files`. The integration
owner controls exact ignore exclusions and source archives after writers finish;
these reporting files do not move, gzip or stage live scorer inputs. Baseline
source is reproducible with `git archive b3caf9300c7336ef812ed061158f851c5a47ccf7 lisp makem.sh`; the recorder
checks extracted bytes against Git and retains source hash manifests. Cite any
final archive index only after its members and hashes are recorded.


## Next operator workflow and scope

Use `ogent-agent-describe`, capabilities and the guide for live call shapes.
Use `ogent-agent-call` for named policy-aware execution, `ogent-agent-next` for
returned guarded continuations, `ogent-agent-call-async` for process callbacks,
and `ogent-agent-batch` for at most 20 declared read-only calls. Select JSON
explicitly for SDK output or registered model tools. Actual build JSON uses
`makem.sh --json` or `make TASK format=json`; doctor is a different surface.

Read the regression recorder's `--help` before replay. Bind the recorded final
freeze and actual portable ripgrep path from its runtime manifest; do not assume
the host tools. Run full native checks only with supported Emacs versions and
actual local dependencies. Providers remain outside this task.

Persistent crash-resume tokens, dependent batches and transport redesign remain
future feature work. Exact aliases do not automatically execute fuzzy guesses.
Unsupported undecodable filenames fail explicitly. Snapshot guards refuse changed
pages without promising filesystem transactions. Any substantive final-review
finding requires correction, a new freeze and rerunning dependent verification.

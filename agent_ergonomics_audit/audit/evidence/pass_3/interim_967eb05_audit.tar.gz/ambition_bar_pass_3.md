# Pass 3 ambition-bar record —967 intermediate state

Source: `/home/agent/.claude/skills/agent-ergonomics-and-intuitiveness-maximization-for-cli-tools/SKILL.md`,
“Ambition Bar”, and `references/methodology/PHASES.md`. The user's request for
much more practical value triggered the second full implementation batch.

## Mandatory self-prompt, verbatim

```
That's it?? I was hoping you would get a lot more practical value out of this skill.
Where are the dramatic improvements? Re-read the playbook, look at the surfaces still
scoring below 500 on output_parseability / error_pedagogy / intent_inference /
self_documentation, and ship a substantially larger batch of high-leverage changes.
You're allowed to be ambitious. Default to acting, not deliberating.
```

The self-prompt is applied to the implemented batch and intermediate paired evidence below.
It does not authorize substituting commit count for numerical surface evidence.

## Larger apply round

| ID | Implemented behavior | Primary commit | Regression wrapper |
|---|---|---|---|
| R013 | Named approval-aware calls with typed outcomes | `2fbc156` | `audit/regression_tests/R013__named_calls.test.sh` |
| R014 | Bounded file pages with exact long-line continuation | `0829b08` | `audit/regression_tests/R014__structured_reads.test.sh` |
| R015 | Complete discovery through structured file pagination | `a1793a8` | `audit/regression_tests/R015__complete_glob_pages.test.sh` |
| R016 | Follow guarded tool continuations in one call | `e9c9af4` | `audit/regression_tests/R016__continuation_calls.test.sh` |
| R017 | Familiar exact verbs with collision-safe policy resolution | `a2b3922` | `audit/regression_tests/R017__common_verbs.test.sh` |
| R018 | Structured search and bounded real process outcomes | `1cde7ab` | `audit/regression_tests/R018__structured_processes.test.sh` |
| R019 | Async agent calls with one precise terminal callback and ledger | `3ced858` | `audit/regression_tests/R019__async_sdk.test.sh` |
| R020 | Preflighted batches of declared read-only calls | `974eb31` | `audit/regression_tests/R020__read_only_batches.test.sh` |
| R021 | Live callable contracts, executable examples and result schema | `d6263d1` | `audit/regression_tests/R021__live_contracts.test.sh` |
| R022 | Structured JSON contracts for registered model tools | `66bc5e8` | `audit/regression_tests/R022__model_json_contract.test.sh` |
| R023 | Actual build/test JSON with typed failures and recovery | `b974cd7` | `audit/regression_tests/R023__actual_build_reports.test.sh` |


Eleven tested external behavior upgrades landed through eleven primary commits.
All eleven wrappers genuinely fail on baseline and pass at intermediate `967eb05`; its
integrity checks also pass. The accepted round 7 ledger finding requires a new fix. The count excludes tests, style, docs and correctness followups.

Completed same-criteria paired aggregation for intermediate `967eb05` compares
19 original surfaces with genuine baseline `b3caf93`: mean **605.26 → 656.21**,
all-surface median **+11**, and median **77.5** over the ten positively changed
original surfaces. Nine original surfaces gain at least 100 points on a dimension;
no paired dimension/surface regresses. Six new APIs remain unpaired current-only
records, excluded from the paired mean. All A/B/third readings are published.

These are valid rubric judgments for this intermediate snapshot, not completed
measurements of the future ledger-corrected freeze. Eleven tested behavior
upgrades share surfaces and do not establish eleven unique causal numeric gains.
The main paired artifacts use calibrated baseline pass 3/current pass 4; these
pass_3 reports identify the implementation batch. Historical pass 1/2 records
remain unchanged. `rubric_reconciliation_pass_3.md` retains applicability and
third-reading decisions. Prior 9ac13b2 scoring/audit states remain in
`evidence/pass_3/interim_9ac13b2_scoring.tar.gz` and
`evidence/pass_3/interim_9ac13b2_audit.tar.gz`. Root will archive the complete
967eb05 state before promoting any later source snapshot.


The skill's numeric substantive-change definition requires at least 100 points
on one dimension. Nine original surfaces meet it at intermediate `967eb05`; the six new APIs
have no baseline counterpart. Because recommendations share surfaces, the
ledger does not claim eleven unique per-commit numeric qualifications. The
all-surface median of 11 is also below the self-prompt's 50-point trigger. The
mandatory larger apply round has been completed and its practical/numeric limits
are stated openly; final review/native gates still prevent completion.

## Breadth and required types

At least three dimensions receive concrete work: versioned read/search/process
and real-build JSON improve parseability; continuations/async/batches improve
composability; approval-aware execution and whole-batch preflight improve safety
with recovery. Exact familiar aliases address intuitiveness/intent inference;
live arguments/examples/schema address self-documentation; typed failures and
copyable corrections address error pedagogy. The dimension mapping records
intended behavior coverage rather than claiming every dimension improved.

- `ogent-agent-batch` supplies a read-investigation macro shape after complete
  preflight. Local triage already existed and is not counted as a new command.
- Existing capabilities/guide now expose live SDK/model shapes, aliases and
  examples; new describe/schema APIs make the contract inspectable.
- Explicit JSON reaches read/search/process SDKs, registered model tools and
  actual makem compilation/lint/ERT execution.
- Errors teach exact offset/column/limit/restart/review alternatives and distinguish
  real command/build failure from prerequisites and arguments.
- Declared aliases accept familiar first guesses while preserving exact-name
  precedence, collision refusal and canonical approval decisions.

## Practical evidence and remaining gates

The original fresh source-blind exercise completed **9/9** tasks, **7/9** with
the first strategy, in **94** public round trips, mostly at `07f775a` with batch `895bed7`.
The seven-line README exercise accounts for 63 calls. Its preserved
`agent_simulations/post_pass_3/summary.json` supports no comparative efficiency
claim.

The familiar `967eb05` repeated replay completed **9/9** tasks in **89** round trips,
with identical start/end SHA. It reused workflows/fixtures, so gets no fresh
first-strategy or efficiency metric. See
`agent_simulations/post_pass_3/final_freeze/summary.json`; prior `9ac13b2` is archived.
Both observed GNU fallback, a protected helper that can supply gptel doubles,
and isolated builds. Neither certifies live provider transport or full native
checks. No provider login/inference occurred.


Intermediate production snapshot is `967eb054e13104d05e818656a2b78f037cc0effd`; the next final freeze is pending. Source/test-only correction
`967eb05` belongs to R018. GNU and ripgrep now share metadata-selected sorted
files, include file-link paths, and skip descendant directory links. Selected
non-UTF-8 filenames fail explicitly; excluded file contents are not opened.
Raw-NUL binary classification, including late NUL and UTF BOM cases, runs inside
the owned async process before matching/counting. Ripgrep receives exact ordered
file argv in 128-name batches, without JSON path remapping or new dependencies.

The deliberate cost is a per-file classifier read plus a second read of text
candidates, all under the existing process timeout/cancel/cleanup owner.
Focused SDK/process/debug suites pass 193 tests (43/51/99) on Emacs 29/30;
style/checkdoc and warning-gated compilation also pass. Full native checks remain
separate.

The reviewed `967eb05` snapshot is **intermediate**, not the final completion
freeze. `phase7_pass_3_review_round 7.md` reports a substantive P2: a terminal
ledger filesystem failure can suppress the asynchronous SDK/model callback.
The integration owner accepted the finding and a ledger-recovery source fix is
in progress. Its commit/freeze is **PENDING_NEW_FINAL_FREEZE**. No future fix or
pass is claimed by these files.

Round 5 was clean at old 9ac13b2; rounds 6 and 7 were unclean. After the new fix
and source freeze, reviews **PENDING_REVIEW_ROUND_8** and
**PENDING_REVIEW_ROUND_9** must be consecutively clean. Native supported-version
validation is **PENDING_FINAL_NATIVE_REPORT**; root delivery/CI remains
**PENDING_ROOT_FINAL_VALIDATION_AND_DELIVERY**. The completed intermediate tests,
proofs and scores do not replace these gates.

`verification/pass_3/regression_proof.json` is now complete at exact `967eb05`:
all eleven genuine baseline failures and current passes are proven. Its final
integrity check validates source/fixture identities, complete execution, zero
current skips and zero timeouts. Current R018 executes 51 process plus two
integration tests (53); R013 overlaps 43 SDK tests and R023 has 23 real-runner
shell cases. The old `9ac13b2` proof remains valid intermediate history under
`verification/pass_3/regressions/interim-9ac13b2/`. Do not add overlapping
selectors or mix ERT and shell count units. Passing these selected regressions
does not negate the new independently reproduced ledger failure.


Persistent resume tokens, dependent batches and transport redesign are deferred
as feature work. Provider-backed throughput or latency was not measured. Exact
alias resolution deliberately does not auto-run fuzzy guesses; unsupported path
bytes fail explicitly. The handoff must retain these limits and may replace
pending gates only with actual freeze-bound reports.

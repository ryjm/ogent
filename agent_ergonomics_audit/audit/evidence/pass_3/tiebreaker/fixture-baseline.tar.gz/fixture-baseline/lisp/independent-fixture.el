;;; independent-fixture.el --- Actual compiler fixture -*- lexical-binding: t; -*-
;; Version: 1.0
;; Package-Requires: ((emacs "29.1"))
;;; Commentary:
;; Independent scoring fixture with no external requests.
;;; Code:
(defun independent-fixture-add (value)
  "Return VALUE plus one."
  (1+ value))
(provide 'independent-fixture)
;;; independent-fixture.el ends here

# Pass 3 ambition-bar record

Source: `/home/agent/.claude/skills/agent-ergonomics-and-intuitiveness-maximization-for-cli-tools/SKILL.md`,
“Ambition Bar”, and `references/methodology/PHASES.md`. The user's request for
much more practical value triggered the second full implementation batch.

## Mandatory self-prompt, verbatim

```
That's it?? I was hoping you would get a lot more practical value out of this skill.
Where are the dramatic improvements? Re-read the playbook, look at the surfaces still
scoring below 500 on output_parseability / error_pedagogy / intent_inference /
self_documentation, and ship a substantially larger batch of high-leverage changes.
You're allowed to be ambitious. Default to acting, not deliberating.
```

The self-prompt is applied to the final implementation and paired evidence below.
It does not authorize substituting commit count for numerical surface evidence.

## Larger apply round

| ID | Implemented behavior | Primary commit | Regression wrapper |
|---|---|---|---|
| R013 | Named approval-aware calls with typed outcomes | `2fbc156` | `audit/regression_tests/R013__named_calls.test.sh` |
| R014 | Bounded file pages with exact long-line continuation | `0829b08` | `audit/regression_tests/R014__structured_reads.test.sh` |
| R015 | Complete discovery through structured file pagination | `a1793a8` | `audit/regression_tests/R015__complete_glob_pages.test.sh` |
| R016 | Follow guarded tool continuations in one call | `e9c9af4` | `audit/regression_tests/R016__continuation_calls.test.sh` |
| R017 | Familiar exact verbs with collision-safe policy resolution | `a2b3922` | `audit/regression_tests/R017__common_verbs.test.sh` |
| R018 | Structured search and bounded real process outcomes | `1cde7ab` | `audit/regression_tests/R018__structured_processes.test.sh` |
| R019 | Async agent calls with one precise terminal callback and ledger | `3ced858` | `audit/regression_tests/R019__async_sdk.test.sh` |
| R020 | Preflighted batches of declared read-only calls | `974eb31` | `audit/regression_tests/R020__read_only_batches.test.sh` |
| R021 | Live callable contracts, executable examples and result schema | `d6263d1` | `audit/regression_tests/R021__live_contracts.test.sh` |
| R022 | Structured JSON contracts for registered model tools | `66bc5e8` | `audit/regression_tests/R022__model_json_contract.test.sh` |
| R023 | Actual build/test JSON with typed failures and recovery | `b974cd7` | `audit/regression_tests/R023__actual_build_reports.test.sh` |


Eleven tested external behavior upgrades landed through eleven primary commits.
All eleven wrappers now genuinely fail on the baseline and pass on freeze
`9ac13b23032f40eccb9a627a824be45656292056`. The count excludes tests, style, docs and correctness followups.

The final same-criteria paired measurements compare 19 original surfaces at
`b3caf9300c7336ef812ed061158f851c5a47ccf7` and `9ac13b23032f40eccb9a627a824be45656292056`. Baseline mean is **605.26**, current mean **656.21**
(**+50.95**); median uplift across all 19 is **11**. The ten original surfaces
with positive weighted uplift have median **77.5**. Nine original surfaces gain
at least 100 points in one dimension; no paired dimension or surface regresses.

These are independent same-model rubric judgments, supported by runtime/source
evidence and third-scorer adjudication for nine disagreements. They are not
agent-success measurements. The eleven tested behavior upgrades overlap existing
surfaces and cannot be counted as eleven uniquely caused numeric qualifications.
The six new SDK APIs are current-only and remain separate from the paired mean.

Artifacts use calibrated baseline pass 3 and current pass 4 in
`agent_surfaces.jsonl`; the `pass_3` recommendation/handoff filenames identify the
implementation batch. Historical pass 1/2 records remain unchanged. This resolves
the applicability drift that invalidated the first inherited-baseline comparison.
See `uplift_diff_pass_3.md` and `new_api_surfaces_pass_4.jsonl` for the paired
and separate current-only records. The exact applicability/third-reading decisions
and retained historical measurements are documented in
`rubric_reconciliation_pass_3.md`; `regression_alerts_pass_3.md` records the
regression decision.


The skill's numeric substantive-change definition requires at least 100 points
on one dimension. Nine original surfaces meet that condition; the six new APIs
have no baseline counterpart. Because recommendations share surfaces, the
ledger does not claim eleven unique per-commit numeric qualifications. The
all-surface median of 11 is also below the self-prompt's 50-point trigger. The
mandatory larger apply round has been completed and its practical/numeric limits
are stated openly; final review/native gates still prevent completion.

## Breadth and required types

At least three dimensions receive concrete work: versioned read/search/process
and real-build JSON improve parseability; continuations/async/batches improve
composability; approval-aware execution and whole-batch preflight improve safety
with recovery. Exact familiar aliases address intuitiveness/intent inference;
live arguments/examples/schema address self-documentation; typed failures and
copyable corrections address error pedagogy. The dimension mapping records
intended behavior coverage rather than claiming every dimension improved.

- `ogent-agent-batch` supplies a read-investigation macro shape after complete
  preflight. Local triage already existed and is not counted as a new command.
- Existing capabilities/guide now expose live SDK/model shapes, aliases and
  examples; new describe/schema APIs make the contract inspectable.
- Explicit JSON reaches read/search/process SDKs, registered model tools and
  actual makem compilation/lint/ERT execution.
- Errors teach exact offset/column/limit/restart/review alternatives and distinguish
  real command/build failure from prerequisites and arguments.
- Declared aliases accept familiar first guesses while preserving exact-name
  precedence, collision refusal and canonical approval decisions.

## Practical evidence and remaining gates

The original source-blind exercise completed **9/9** heterogeneous tasks,
**7/9** with the first strategy, in **94** defined public round trips. Most tasks
ran at `07f775a`; the corrected batch task was rerun at `895bed7`. The deliberately
seven-line README task accounts for 63 calls. Exact errors and retries remain in
`agent_simulations/post_pass_3/summary.json`; these are discovery evidence, not a
comparative efficiency benchmark.

The repeated regression replay at `9ac13b2` completed **9/9** tasks in **89**
round trips, with the same source SHA at start/end. It reused known public
workflows and fixtures, so it receives no fresh first-strategy or efficiency
claim. See `agent_simulations/post_pass_3/final_freeze/summary.json`. It also
verified previously missing compiler and ERT locations. Both exercises observed
GNU search fallback, used a protected helper that can supply gptel doubles, and
compiled only isolated fixture projects. They do not prove live provider
transport or full-project native validation; no provider login/inference occurred.


Final production freeze is `9ac13b23032f40eccb9a627a824be45656292056`. It includes `a99000d` for supported
object/hash-table argument snapshots, deep schema comparison and nested model
cache refresh; `9ac13b2` for real Unicode ripgrep candidate groups; and `08dfaad`
for compiler file paths when EOF diagnostics omit positions. These are followups
to the original eleven recommendations, not additional recommendations.

`verification/pass_3/regression_proof.json` now proves all eleven wrappers:
genuine baseline failures and current passes at this exact freeze, with recorded
Git source identity, unchanged fixture hashes, complete selected execution and
no skipped current cases. `verification/pass_3/regressions/integrity_check.json`
independently checks all 22 transcripts, 47 input hashes, source/fixture identity
and zero timeouts/skips; all integrity checks passed. R013 overlaps the other SDK wrappers; R018 executes
46 process and two integration tests on current while baseline failure may
short-circuit integration; R023 executes 23 actual shell-runner cases. Do not
sum overlapping selectors or mix shell cases with ERT counts as one test total.

The initial review and rounds 2/3/4 were unclean and their corrections are
included in this freeze. `phase7_pass_3_review_round5.md` is **clean** at the
exact final freeze: 188 focused tests passed on each supported Emacs version,
and an independent GNU/ripgrep fixture returned 560 identical ordered matches.
This is the first consecutive clean review. **PENDING_REVIEW_ROUND_6** must
establish the second. Final full native supported-version checks are
**PENDING_FINAL_NATIVE_REPORT**; root delivery/CI is
**PENDING_ROOT_FINAL_VALIDATION_AND_DELIVERY**. Green focused tests and wrapper
proofs do not replace the remaining gates.


Persistent resume tokens, dependent batches and transport redesign are deferred
as feature work. Provider-backed throughput or latency was not measured. Exact
alias resolution deliberately does not auto-run fuzzy guesses; unsupported path
bytes fail explicitly. The handoff must retain these limits and may replace
pending gates only with actual freeze-bound reports.

# Pass 3 implementation playbook

This is the user's second full implementation batch. Scope is the existing
local tool/SDK/build surfaces: call, inspect, continue, compose and diagnose them.
Work lands directly on `master` inside `/workspace/ogent`; no branch, PR,
provider authentication or inference belongs to this pass.

## Implemented recommendations

| ID | Implemented behavior | Primary commit | Regression wrapper |
|---|---|---|---|
| R013 | Named approval-aware calls with typed outcomes | `2fbc156` | `audit/regression_tests/R013__named_calls.test.sh` |
| R014 | Bounded file pages with exact long-line continuation | `0829b08` | `audit/regression_tests/R014__structured_reads.test.sh` |
| R015 | Complete discovery through structured file pagination | `a1793a8` | `audit/regression_tests/R015__complete_glob_pages.test.sh` |
| R016 | Follow guarded tool continuations in one call | `e9c9af4` | `audit/regression_tests/R016__continuation_calls.test.sh` |
| R017 | Familiar exact verbs with collision-safe policy resolution | `a2b3922` | `audit/regression_tests/R017__common_verbs.test.sh` |
| R018 | Structured search and bounded real process outcomes | `1cde7ab` | `audit/regression_tests/R018__structured_processes.test.sh` |
| R019 | Async agent calls with one precise terminal callback and ledger | `3ced858` | `audit/regression_tests/R019__async_sdk.test.sh` |
| R020 | Preflighted batches of declared read-only calls | `974eb31` | `audit/regression_tests/R020__read_only_batches.test.sh` |
| R021 | Live callable contracts, executable examples and result schema | `d6263d1` | `audit/regression_tests/R021__live_contracts.test.sh` |
| R022 | Structured JSON contracts for registered model tools | `66bc5e8` | `audit/regression_tests/R022__model_json_contract.test.sh` |
| R023 | Actual build/test JSON with typed failures and recovery | `b974cd7` | `audit/regression_tests/R023__actual_build_reports.test.sh` |


Eleven distinct production behaviors landed through eleven primary Conventional
Commits. Exact parent/current source coordinates and 33 complete selected hunks
are in `applied_changes_pass_3.jsonl` and `recommendation_hunks_pass_3.md`.
Those primary hunks preserve the implementation trail; final behavior also
includes the followup fixes listed in the applied ledger. Tests, whitespace,
documentation-only commits and correction followups do not increase the count.
The retrospective `priority: 0` field is explicitly unranked; empty expected
uplift maps avoid inventing ex ante estimates.

## Final paired measurements

The final same-criteria paired measurements compare 19 original surfaces at
`b3caf9300c7336ef812ed061158f851c5a47ccf7` and `9ac13b23032f40eccb9a627a824be45656292056`. Baseline mean is **605.26**, current mean **656.21**
(**+50.95**); median uplift across all 19 is **11**. The ten original surfaces
with positive weighted uplift have median **77.5**. Nine original surfaces gain
at least 100 points in one dimension; no paired dimension or surface regresses.

These are independent same-model rubric judgments, supported by runtime/source
evidence and third-scorer adjudication for nine disagreements. They are not
agent-success measurements. The eleven tested behavior upgrades overlap existing
surfaces and cannot be counted as eleven uniquely caused numeric qualifications.
The six new SDK APIs are current-only and remain separate from the paired mean.

Artifacts use calibrated baseline pass 3 and current pass 4 in
`agent_surfaces.jsonl`; the `pass_3` recommendation/handoff filenames identify the
implementation batch. Historical pass 1/2 records remain unchanged. This resolves
the applicability drift that invalidated the first inherited-baseline comparison.
See `uplift_diff_pass_3.md` and `new_api_surfaces_pass_4.jsonl` for the paired
and separate current-only records. The exact applicability/third-reading decisions
and retained historical measurements are documented in
`rubric_reconciliation_pass_3.md`; `regression_alerts_pass_3.md` records the
regression decision.


Build JSON attribution covers historical make help/compile/recompile. Newly
supported lint/test and runner JSON are extension coverage. The unchanged
`make offline-test` target receives no build-JSON output credit; offline checks
validate actual local dependency integration.

## Verification and remaining gates

Final production freeze is `9ac13b23032f40eccb9a627a824be45656292056`. It includes `a99000d` for supported
object/hash-table argument snapshots, deep schema comparison and nested model
cache refresh; `9ac13b2` for real Unicode ripgrep candidate groups; and `08dfaad`
for compiler file paths when EOF diagnostics omit positions. These are followups
to the original eleven recommendations, not additional recommendations.

`verification/pass_3/regression_proof.json` now proves all eleven wrappers:
genuine baseline failures and current passes at this exact freeze, with recorded
Git source identity, unchanged fixture hashes, complete selected execution and
no skipped current cases. `verification/pass_3/regressions/integrity_check.json`
independently checks all 22 transcripts, 47 input hashes, source/fixture identity
and zero timeouts/skips; all integrity checks passed. R013 overlaps the other SDK wrappers; R018 executes
46 process and two integration tests on current while baseline failure may
short-circuit integration; R023 executes 23 actual shell-runner cases. Do not
sum overlapping selectors or mix shell cases with ERT counts as one test total.

The initial review and rounds 2/3/4 were unclean and their corrections are
included in this freeze. `phase7_pass_3_review_round5.md` is **clean** at the
exact final freeze: 188 focused tests passed on each supported Emacs version,
and an independent GNU/ripgrep fixture returned 560 identical ordered matches.
This is the first consecutive clean review. **PENDING_REVIEW_ROUND_6** must
establish the second. Final full native supported-version checks are
**PENDING_FINAL_NATIVE_REPORT**; root delivery/CI is
**PENDING_ROOT_FINAL_VALIDATION_AND_DELIVERY**. Green focused tests and wrapper
proofs do not replace the remaining gates.


Initial native lint failed before correction. Earlier native outputs and proofs
at invalidated `3cb0cd7`/`90818f8` remain intermediate evidence. Never relabel
them as final freeze checks. Source/fixture identities in the final proof distinguish
real baseline failures from timeouts, missing selections or invented stubs.

## Review-driven corrections

The initial review drove bounded descendant stderr drains, post-approval registry
replacement checks, failure-aware ledger terminals, component-safe glob stars,
empty-candidate regex validation and final-newline metadata. Round 2 drove
in-place metadata snapshots, JSON-safe unsupported filenames with callback-once
completion, smaller configured read defaults, explicit-file search filter parity
and structured debug history replay/error/status plus actual JSON history arrays.
Round 3 drove frozen batch tool/argument plans and shared component/recursive
filter rules. Round 4 drove copied supported object hash tables, deep metadata
content comparison, nested model schema cache refresh and Unicode wildcard
candidate parity. Existing focused suites passed before these additional probes
found real defects; review breadth matters independently of test count.

Shared corrections include `a820ac0`, `07f775a`, `0d2fea6`, `7c0d9d8`,
`895bed7`, `0f7273e`, `8e93242`, `5b0f158`, `3cb0cd7`, `ed044fb`,
`19f154a`, `90818f8`, `08dfaad`, `a99000d`, and `9ac13b2`. The applied
ledger stores full SHAs and relevant mappings; none is a twelfth recommendation.

## Practical task evidence

The original source-blind exercise completed **9/9** heterogeneous tasks,
**7/9** with the first strategy, in **94** defined public round trips. Most tasks
ran at `07f775a`; the corrected batch task was rerun at `895bed7`. The deliberately
seven-line README task accounts for 63 calls. Exact errors and retries remain in
`agent_simulations/post_pass_3/summary.json`; these are discovery evidence, not a
comparative efficiency benchmark.

The repeated regression replay at `9ac13b2` completed **9/9** tasks in **89**
round trips, with the same source SHA at start/end. It reused known public
workflows and fixtures, so it receives no fresh first-strategy or efficiency
claim. See `agent_simulations/post_pass_3/final_freeze/summary.json`. It also
verified previously missing compiler and ERT locations. Both exercises observed
GNU search fallback, used a protected helper that can supply gptel doubles, and
compiled only isolated fixture projects. They do not prove live provider
transport or full-project native validation; no provider login/inference occurred.


## Evidence source archiving and build discovery

Raw baseline source and isolated build/test fixtures under audit evidence must
stay out of tracked `.el` discovery: `makem.sh` uses `git ls-files`. The integration
owner controls exact ignore exclusions and source archives after writers finish;
these reporting files do not move, gzip or stage live scorer inputs. Baseline
source is reproducible with `git archive b3caf9300c7336ef812ed061158f851c5a47ccf7 lisp makem.sh`; the recorder
checks extracted bytes against Git and retains source hash manifests. Cite any
final archive index only after its members and hashes are recorded.


## Next operator workflow and scope

Use `ogent-agent-describe`, capabilities and the guide for live call shapes.
Use `ogent-agent-call` for named policy-aware execution, `ogent-agent-next` for
returned guarded continuations, `ogent-agent-call-async` for process callbacks,
and `ogent-agent-batch` for at most 20 declared read-only calls. Select JSON
explicitly for SDK output or registered model tools. Actual build JSON uses
`makem.sh --json` or `make TASK format=json`; doctor is a different surface.

Read the regression recorder's `--help` before replay. Bind the recorded final
freeze and actual portable ripgrep path from its runtime manifest; do not assume
the host tools. Run full native checks only with supported Emacs versions and
actual local dependencies. Providers remain outside this task.

Persistent crash-resume tokens, dependent batches and transport redesign remain
future feature work. Exact aliases do not automatically execute fuzzy guesses.
Unsupported undecodable filenames fail explicitly. Snapshot guards refuse changed
pages without promising filesystem transactions. Any substantive final-review
finding requires correction, a new freeze and rerunning dependent verification.

# Pass 3 ambition-bar record — intermediate a2fa8ce

Source: `/home/agent/.claude/skills/agent-ergonomics-and-intuitiveness-maximization-for-cli-tools/SKILL.md`,
“Ambition Bar”, and `references/methodology/PHASES.md`. The user's request for
much more practical value triggered this second full implementation batch.

## Mandatory self-prompt, verbatim

```
That's it?? I was hoping you would get a lot more practical value out of this skill.
Where are the dramatic improvements? Re-read the playbook, look at the surfaces still
scoring below 500 on output_parseability / error_pedagogy / intent_inference /
self_documentation, and ship a substantially larger batch of high-leverage changes.
You're allowed to be ambitious. Default to acting, not deliberating.
```

The mandatory self-prompt was applied to the larger implementation round. It does
not authorize substituting commit count for numerical surface evidence.

## Larger apply round

| ID | Implemented behavior | Primary commit | Regression wrapper |
|---|---|---|---|
| R013 | Named approval-aware calls with typed outcomes | `2fbc156` | `audit/regression_tests/R013__named_calls.test.sh` |
| R014 | Bounded file pages with exact long-line continuation | `0829b08` | `audit/regression_tests/R014__structured_reads.test.sh` |
| R015 | Complete discovery through structured file pagination | `a1793a8` | `audit/regression_tests/R015__complete_glob_pages.test.sh` |
| R016 | Follow guarded tool continuations in one call | `e9c9af4` | `audit/regression_tests/R016__continuation_calls.test.sh` |
| R017 | Familiar exact verbs with collision-safe policy resolution | `a2b3922` | `audit/regression_tests/R017__common_verbs.test.sh` |
| R018 | Structured search and bounded real process outcomes | `1cde7ab` | `audit/regression_tests/R018__structured_processes.test.sh` |
| R019 | Async agent calls with one precise terminal callback and ledger | `3ced858` | `audit/regression_tests/R019__async_sdk.test.sh` |
| R020 | Preflighted batches of declared read-only calls | `974eb31` | `audit/regression_tests/R020__read_only_batches.test.sh` |
| R021 | Live callable contracts, executable examples and result schema | `d6263d1` | `audit/regression_tests/R021__live_contracts.test.sh` |
| R022 | Structured JSON contracts for registered model tools | `66bc5e8` | `audit/regression_tests/R022__model_json_contract.test.sh` |
| R023 | Actual build/test JSON with typed failures and recovery | `b974cd7` | `audit/regression_tests/R023__actual_build_reports.test.sh` |

Eleven tested external behavior upgrades landed through eleven primary commits.
All eleven wrappers genuinely fail on baseline and pass at `a2fa8ce`. The count
excludes tests, style, documentation and correctness followups.

## Numeric bar and attribution limits

Independent A/B readings and a third reading where needed compare **19 original
surfaces** at `b3caf93` and `a2fa8ce`: mean **605.26 → 656.21**, all-surface median
**+11**, and ten positively changed originals with median **+77.5**. Nine original
surfaces gain at least 100 points on a dimension. No paired composite score
regressed; the >50-point regression alert list is empty.

The six new APIs are current-only records with no baseline counterpart. The eleven
behavior upgrades share surfaces, so these measurements do not establish eleven
unique causal numeric gains. Judgments use the same model, a floored per-dimension
median and a floored equal-weight composite mean; they are rubric evidence rather
than provider throughput or latency measurements.

`evidence/pass_3/triangulation/aggregation.json` pins both source SHAs, actual
A/B/third-reading inputs, hashes and aggregation. Historical passes 1/2 retain all
38 original row values and historical scorecard/heatmap bytes. Prior `10f86bb`
scoring/audit states and provenance are archived in
`evidence/pass_3/interim_10f86bb_scoring.tar.gz`,
`evidence/pass_3/interim_10f86bb_audit.tar.gz` and
`evidence/pass_3/interim_10f86bb_archive.json`. Paired score artifacts use baseline
pass 3/current pass 4; these pass_3 files identify the implementation batch.

Build JSON attribution covers historical help/compile/recompile and extension
coverage for lint/test/the runner. The unchanged `make offline-test` target
receives no build-JSON output credit.

The skill's numeric substantive-change definition requires at least 100 points
on one dimension. Nine original surfaces meet it; the six new APIs lack baseline
counterparts. Because recommendations share surfaces, the ledger does not claim
eleven unique per-commit numeric qualifications. The all-surface median **+11**
remains below the self-prompt's 50-point trigger. The required larger apply round
is complete; its practical and numeric limits remain explicit.

## Breadth and required types

Versioned read/search/process and real-build JSON address output parseability;
continuations, async calls and batches address composability; approval-aware
execution and full-batch preflight address safety with recovery. Exact familiar
aliases address intuitiveness/intent inference; live arguments/examples/schema
address self-documentation; typed failures and copyable corrections address error
pedagogy. These are intended behavior dimensions, not a claim that every one
improved numerically.

- `ogent-agent-batch` supplies a read-investigation macro after complete preflight.
  Existing local triage is not counted as new.
- Existing capabilities/guide expose live SDK/model shapes, aliases and examples;
  describe/schema APIs make the callable contract inspectable.
- Explicit JSON reaches read/search/process SDKs, registered model tools and
  actual compilation/lint/ERT execution.
- Errors teach exact offset/column/limit/restart/review alternatives and distinguish
  real command/build failures from prerequisites and arguments.
- Declared aliases accept familiar exact guesses while preserving registered-name
  precedence, collision refusal and canonical approval decisions.

## Practical evidence and correctness

The original fresh source-blind exercise completed **9/9** tasks, **7/9** with
the first strategy, in **94** defined public round trips, mostly at `07f775a` with
batch `895bed7`. Paging the README seven lines at a time accounts for 63 calls.
Its preserved `agent_simulations/post_pass_3/summary.json` supports no comparative
efficiency claim.

The familiar snapshot replay completed **9/9** tasks in **89** known-workflow
round trips at `a2fa8ce`, with identical start/end SHA. It reuses workflows and
fixtures, so gets no new first-strategy or comparative efficiency metric. See
`agent_simulations/post_pass_3/final_freeze/summary.json`; earlier `10f86bb` replay
is retained under `replay_10f86bb/`. Both observed GNU fallback, a protected helper
that can supply gptel doubles and isolated builds. Neither certifies provider
transport or full native checks. No provider authentication or inference occurred.

The `a2fa8ce` followup captures a copied absolute ledger destination and enabled
state per call. Only start/finish recording binds those captured settings;
tool bodies and user callbacks keep their ambient context. Configuration changes
apply to future calls. Completion storage faults are injected at the original
captured file by renaming it and placing a directory at that path, exercising
real IO rather than changing a configuration option as a fault surrogate.

The earlier `10f86bb` repair attempts terminal recording once. A completion write
failure returns `ledger_write_failed` with retained completed data and preserves
an existing failure in `error.tool_error`. Native/model callbacks still arrive
once; legacy/UI paths retain output and show the storage warning, and streaming
cleanup completes. Recovery directs callers to inspect retained data and select a
writable ledger for future calls; effects must not be rerun merely to repair
storage. Start recording must succeed before effects, and result-construction
failures return a typed retained result. These contracts do not guarantee
persistence after a filesystem write failure.

`evidence/pass_3/ledger_context/results.json` records **213/213 focused tests plus
4/4 existing UI tests on both Emacs 29.1 and 30.2**, with zero focused skips or
unexpected results and scoped static validation passing. Three new context
regressions genuinely fail on `10f86bb` and pass on `a2fa8ce` on both versions;
32 execution cases cover origin/configuration behavior. The old modules are
preserved losslessly in `evidence/pass_3/ledger_context/baseline-source.tar.gz`
with `baseline-source-archive.json`; extracted `.el` copies stay ignored to
protect makem tracked-file discovery. Earlier focused recovery results remain in
`evidence/pass_3/ledger_recovery/results.json`. Focused checks do not substitute
for the full native matrix at a corrected final source freeze.

R018 followup `967eb05` makes GNU and ripgrep use the same metadata-selected,
sorted file list, include file-link paths and skip descendant directory links.
Selected non-UTF-8 filenames fail explicitly; excluded contents are not opened.
Raw-NUL binary classification, including late NUL and UTF BOM cases, runs inside
the owned async process before matching/counting. Ripgrep receives exact ordered
argv in groups of 128 names. This requires a classifier read and a second read of
text candidates under the existing timeout/cancel/cleanup owner, without a new
dependency or JSON path remapping.

## Completed proof and remaining gates

`verification/pass_3/regression_proof.json` is **complete at `a2fa8ce`**:
all eleven wrappers exit 1 against genuine `b3caf93` source and exit 0 against the
frozen current source, with no timeouts or skipped current ERT tests. It records
source/fixture identities, exact selectors, expected names, executed counts and
full transcript hashes. The overlapping selectors prove behavior without
assigning unique test totals or causal score uplift to individual recommendations.

| ID | Baseline executed / exit | Current executed / exit | Unit |
|---|---:|---:|---|
| R013 | 53 / 1 | 53 / 0 | ERT tests |
| R014 | 4 / 1 | 4 / 0 | ERT tests |
| R015 | 3 / 1 | 3 / 0 | ERT tests |
| R016 | 3 / 1 | 3 / 0 | ERT tests |
| R017 | 2 / 1 | 2 / 0 | ERT tests |
| R018 | 51 / 1 | 53 / 0 | ERT tests |
| R019 | 10 / 1 | 10 / 0 | ERT tests |
| R020 | 7 / 1 | 7 / 0 | ERT tests |
| R021 | 3 / 1 | 3 / 0 | ERT tests |
| R022 | 9 / 1 | 9 / 0 | ERT tests |
| R023 | 1 / 1 | 23 / 0 | Shell runner cases |

R018 stops after its 51-test baseline process failure; current executes those 51
plus two SDK integration tests. R023's baseline fails on its first actual report
case; current completes all 23 real shell-runner cases. ERT and shell counts are
separate units. Earlier proofs are preserved under
`verification/pass_3/regressions/interim-967eb05/` and `interim-10f86bb/`.

Snapshot proof integrity is **complete at `a2fa8ce`**.
`verification/pass_3/regressions/integrity_check.json` verifies 22 transcripts,
47 input hashes, Git source/fixture identities, selected/executed counts, zero
skips/timeouts and preserved historical proof. `recorder_validation.json` records
all six negative controls passing, including empty/truncated ERT, false baseline
success, current failures and incomplete shell fixtures. Integrity validation
reused the completed transcripts; no completed test was rerun for this check.

Rounds 9 and 10 are **two consecutive CLEAN independent reviews** at `a2fa8ce`,
with zero substantive or trivial findings and no intervening source edits.
Each final review run executes 108 focused tests plus one independent real-IO
probe on each supported Emacs version: 218 passing ERT executions of 109 distinct
tests, zero final skips/unexpected results. Both start/end guards preserve the SHA
and hashes of 224 tracked source, test, documentation and build files.

Round 10 additionally preserves two initial reviewer-fixture failures: its probe
used `"*"` as an approval rule, which correctly refused the call because policy
uses exact tool names. The probe was corrected to the documented `"bash"` rule;
no production source changed. Its complete history is 220 ERT executions, 218
expected and two fixture failures, zero skips. See
`phase7_pass_3_review_round9.md`, `phase7_pass_3_review_round10.md` and
`evidence/pass_3/review_round10/final/summary.json`.

**INTERMEDIATE_A2FA8CE_NATIVE_LINT_FAILED**: full native lint failed at this
snapshot on batch docstring width/imperative wording and an unused
`json-serialize` result warning. A warning-hygiene correction, a new source freeze
and dependent verification are pending. The remaining native collector cases
are still running; no full matrix result is asserted yet. Completed scores,
wrapper proof, integrity, reviews 9/10 and replay remain valid only at `a2fa8ce`.
**PENDING_ROOT_FINAL_VALIDATION_AND_DELIVERY** remains; this snapshot is not a
final promotion or delivery claim.

Persistent crash-resume tokens, dependent batches and transport redesign remain
future feature work. Exact aliases do not automatically execute fuzzy guesses;
unsupported undecodable filenames fail explicitly. Continuation snapshot guards
refuse changed pages without promising filesystem transactions. Provider-backed
throughput and latency were not measured. A substantive review finding requires
correction, a new source freeze and rerunning dependent verification.

# Pass 3 handoff — intermediate a2fa8ce

Ogent now provides named versioned tool calls, complete bounded read/search pages,
guarded continuation, read-only batching, async result delivery, live schemas and
examples, optional model JSON and actual build/test JSON. If ledger storage fails
after effects complete, callers retain tool data and receive a storage error with
advice not to rerun effects merely to repair the ledger. Each call keeps its
original ledger destination and enabled state while later configuration applies
to future calls.

This is the user's second full implementation batch, on `master` inside
`/workspace/ogent`. Baseline: `b3caf9300c7336ef812ed061158f851c5a47ccf7`. Verified intermediate production snapshot:
`a2fa8ce0533b4a508fb641f343fa55b15fd6fc60`. Eleven primary commits ship eleven tested external behaviors;
correctness followups do not increase that count. No branch, PR, provider
login or inference was used.

## Implemented behavior

| ID | Implemented behavior | Primary commit | Regression wrapper |
|---|---|---|---|
| R013 | Named approval-aware calls with typed outcomes | `2fbc156` | `audit/regression_tests/R013__named_calls.test.sh` |
| R014 | Bounded file pages with exact long-line continuation | `0829b08` | `audit/regression_tests/R014__structured_reads.test.sh` |
| R015 | Complete discovery through structured file pagination | `a1793a8` | `audit/regression_tests/R015__complete_glob_pages.test.sh` |
| R016 | Follow guarded tool continuations in one call | `e9c9af4` | `audit/regression_tests/R016__continuation_calls.test.sh` |
| R017 | Familiar exact verbs with collision-safe policy resolution | `a2b3922` | `audit/regression_tests/R017__common_verbs.test.sh` |
| R018 | Structured search and bounded real process outcomes | `1cde7ab` | `audit/regression_tests/R018__structured_processes.test.sh` |
| R019 | Async agent calls with one precise terminal callback and ledger | `3ced858` | `audit/regression_tests/R019__async_sdk.test.sh` |
| R020 | Preflighted batches of declared read-only calls | `974eb31` | `audit/regression_tests/R020__read_only_batches.test.sh` |
| R021 | Live callable contracts, executable examples and result schema | `d6263d1` | `audit/regression_tests/R021__live_contracts.test.sh` |
| R022 | Structured JSON contracts for registered model tools | `66bc5e8` | `audit/regression_tests/R022__model_json_contract.test.sh` |
| R023 | Actual build/test JSON with typed failures and recovery | `b974cd7` | `audit/regression_tests/R023__actual_build_reports.test.sh` |

Agents can consume bounded results without parsing presentation text or guessing
restart positions. Real process results separate output channels, exit/timeout/
cancellation and retained partial output. Async calls and read-only batches share
the existing approval/review/ledger owners. Live descriptions/examples/schema
expose callable shapes; model JSON and makem JSON extend explicit contracts.

Followups freeze arguments/targets/object content, refresh nested schemas, align
Unicode and binary search behavior, repair structured history replay and retain
terminal data through ledger storage failures. They remain part of the original
eleven recommendations.

## Measured outcome

Independent A/B readings and a third reading where needed compare **19 original
surfaces** at `b3caf93` and `a2fa8ce`: mean **605.26 → 656.21**, all-surface median
**+11**, and ten positively changed originals with median **+77.5**. Nine original
surfaces gain at least 100 points on a dimension. No paired composite score
regressed; the >50-point regression alert list is empty.

The six new APIs are current-only records with no baseline counterpart. The eleven
behavior upgrades share surfaces, so these measurements do not establish eleven
unique causal numeric gains. Judgments use the same model, a floored per-dimension
median and a floored equal-weight composite mean; they are rubric evidence rather
than provider throughput or latency measurements.

`evidence/pass_3/triangulation/aggregation.json` pins both source SHAs, actual
A/B/third-reading inputs, hashes and aggregation. Historical passes 1/2 retain all
38 original row values and historical scorecard/heatmap bytes. Prior `10f86bb`
scoring/audit states and provenance are archived in
`evidence/pass_3/interim_10f86bb_scoring.tar.gz`,
`evidence/pass_3/interim_10f86bb_audit.tar.gz` and
`evidence/pass_3/interim_10f86bb_archive.json`. Paired score artifacts use baseline
pass 3/current pass 4; these pass_3 files identify the implementation batch.

Build JSON attribution covers historical help/compile/recompile and extension
coverage for lint/test/the runner. The unchanged `make offline-test` target
receives no build-JSON output credit.

## Verified behavior

All eleven regression wrappers genuinely exit 1 against `b3caf93` and exit 0 at
`a2fa8ce`. There are no timeouts or skipped current ERT tests. R018 executes 51
baseline process tests and 53 current tests including two SDK integrations;
R023 fails on its first baseline report case and completes 23 current real-runner
shell cases. Selectors overlap, and ERT/shell counts remain separate units.
`verification/pass_3/regression_proof.json` preserves exact inputs, source
identities, selectors, counts and transcript hashes.

Snapshot integrity checks pass at `a2fa8ce`: 22 transcripts, 47 input hashes, source
and fixture identities, selected/executed counts and all six negative controls.
See `verification/pass_3/regressions/integrity_check.json` and
`recorder_validation.json`.

`evidence/pass_3/ledger_context/results.json` records **213/213 focused tests plus
4/4 existing UI tests on both Emacs 29.1 and 30.2**, with scoped static validation
passing. Three new context regressions fail on actual `10f86bb` source and pass
on `a2fa8ce` on both versions; 32 execution cases cover configuration behavior.
Faults at the original captured ledger path exercise real IO. Completed data,
nested tool errors, once-only callbacks and streaming cleanup survive terminal
storage failure; failed start recording prevents effects. Tools and callbacks
retain ambient context, and settings changes apply to future calls. Successful
persistence after a filesystem fault is not guaranteed.

## Independent review and delivery status

Rounds 9 and 10 are **two consecutive CLEAN independent reviews** at `a2fa8ce`,
with unchanged SHA and 224-file source guards. Each review's final runs pass 108
focused tests plus one real-IO probe on each supported Emacs version. Round 10
preserves two earlier probe-fixture failures (`"*"` instead of exact `"bash"`
approval); only the reviewer fixture changed, and all final runs pass.

**INTERMEDIATE_A2FA8CE_NATIVE_LINT_FAILED**: full native lint failed on batch
function docstring width/imperative wording and an unused `json-serialize` result.
The remaining collector cases are still running. A warning-hygiene correction,
new freeze and dependent verification are pending. Scores, proof, integrity,
reviews and replay remain valid evidence at this intermediate snapshot.
**PENDING_ROOT_FINAL_VALIDATION_AND_DELIVERY** remains.

| Gate | Actual status |
|---|---|
| Production snapshot | Intermediate `a2fa8ce0533b4a508fb641f343fa55b15fd6fc60`; native lint failed |
| Paired scoring | Complete: 19 originals; mean 605.26 → 656.21; median +11 |
| Changed originals | Ten; median +77.5 |
| Numeric qualification | Nine originals gain ≥100 on a dimension; six new APIs unpaired |
| R013…R023 baseline/current proof | Complete: all 11 baseline exit 1/current exit 0 |
| Integrity for final proof | Complete: 22 transcripts, 47 input hashes; all six negative controls pass |
| Independent reviews | Rounds 9/10 CLEAN consecutively on the same frozen source |
| Full native validation | Lint failed; remaining collector cases pending |
| Commit/push and CI | Pending |

## Practical task evidence

The original fresh source-blind exercise completed **9/9** tasks, **7/9** with
the first strategy, in **94** defined public round trips, mostly at `07f775a` with
batch `895bed7`. Paging the README seven lines at a time accounts for 63 calls.
Its preserved `agent_simulations/post_pass_3/summary.json` supports no comparative
efficiency claim.

The familiar snapshot replay completed **9/9** tasks in **89** known-workflow
round trips at `a2fa8ce`, with identical start/end SHA. It reuses workflows and
fixtures, so gets no new first-strategy or comparative efficiency metric. See
`agent_simulations/post_pass_3/final_freeze/summary.json`; earlier `10f86bb` replay
is retained under `replay_10f86bb/`. Both observed GNU fallback, a protected helper
that can supply gptel doubles and isolated builds. Neither certifies provider
transport or full native checks. No provider authentication or inference occurred.

## Durable artifacts and next focus

- `recommendations_pass_3.jsonl`: exactly R013…R023, primary commits/Beads,
  intended dimensions, source references and numeric-attribution limits.
- `applied_changes_pass_3.jsonl`: 33 exact selected primary source hunks and line
  coordinates, full followup SHAs, actual baseline/freeze proof counts and units.
- `recommendation_hunks_pass_3.md`: readable primary and followup source hunks.
- `playbook_pass_3.md`: verification method, correctness repairs and replay limits.
- `ambition_bar_pass_3.md`: mandatory verbatim self-prompt, eleven qualitative
  upgrades and honest numeric/median limits.

The next pass can prioritize crash-resume tokens, dependent batches and transport
redesign as feature work, then validate provider-backed transport separately.
For local execution, use live describe/schema/capabilities before calling the SDK;
use explicit JSON and returned continuation descriptors. Reproduce checks from
the frozen manifests and regression recorder help, with actual supported Emacs
runtimes and local dependencies.

Persistent crash-resume tokens, dependent batches and transport redesign remain
future feature work. Exact aliases do not automatically execute fuzzy guesses;
unsupported undecodable filenames fail explicitly. Continuation snapshot guards
refuse changed pages without promising filesystem transactions. Provider-backed
throughput and latency were not measured. A substantive review finding requires
correction, a new source freeze and rerunning dependent verification.

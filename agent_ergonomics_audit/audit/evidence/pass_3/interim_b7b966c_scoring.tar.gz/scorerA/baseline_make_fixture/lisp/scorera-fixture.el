;;; scorera-fixture.el --- Independent real compiler fixture -*- lexical-binding: t; -*-
;; Version: 1.0
;; Package-Requires: ((emacs "29.1"))
;;; Commentary:
;; Local fixture without ogent or provider dependencies.
;;; Code:
(defun scorera-fixture-add (n)
  "Return N plus one."
  (1+ n))
(provide 'scorera-fixture)
;;; scorera-fixture.el ends here

(defun scorera-fixture-broken ()

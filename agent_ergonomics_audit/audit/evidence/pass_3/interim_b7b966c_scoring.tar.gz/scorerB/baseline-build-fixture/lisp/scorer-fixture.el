;;; scorer-fixture.el --- Build probe -*- lexical-binding: t; -*-
;; Version: 1.0
;; Package-Requires: ((emacs "29.1"))
;;; Commentary:
;; A minimal local fixture, with no provider requests.
;;; Code:
(defun scorer-fixture-add (value)
  "Return VALUE plus one."
  (1+ value))
(provide 'scorer-fixture)
;;; scorer-fixture.el ends here

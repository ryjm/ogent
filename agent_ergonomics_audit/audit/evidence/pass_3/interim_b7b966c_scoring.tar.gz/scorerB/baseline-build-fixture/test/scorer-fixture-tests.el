;;; scorer-fixture-tests.el --- Local tests -*- lexical-binding: t; -*-
(require 'ert)
(require 'scorer-fixture)
(ert-deftest scorer-fixture-add () (should (= (scorer-fixture-add 1) 99)))

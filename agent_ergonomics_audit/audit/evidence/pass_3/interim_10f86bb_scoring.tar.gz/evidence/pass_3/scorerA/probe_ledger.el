;;; probe_ledger.el --- Actual completion IO failure probes -*- lexical-binding: t; -*-
(require 'ogent-agent)
(require 'ogent-tools)
(require 'ogent-ui-toolcalls)
(unless (equal (symbol-file 'ogent-tool-execution-call 'defun) "/work/lisp/ogent-tool-execution.el")
  (error "Ledger probe loaded unexpected execution source"))
(defun scorerA-ledger-record (probe invocation thunk)
  (let ((print-level nil) (print-length nil))
    (princ (json-serialize
            (condition-case err
                (list :probe probe :invocation invocation :outcome "returned" :result (prin1-to-string (funcall thunk)))
              (error (list :probe probe :invocation invocation :outcome "condition"
                           :condition (symbol-name (car err)) :message (error-message-string err))))))
    (princ "\n")))
(let* ((root (ogent-test--provision-store-directory 'tools))
       (ogent-tool-require-approval nil) (ogent-tools-show-progress nil) (ogent-ledger-enabled t))
  (dolist (mode '(sync async wrapper))
    (let* ((ogent-ledger-file (expand-file-name (format "%s.ndjson" mode) root))
           (executions 0) (callbacks 0) payload
           (spec (list :name 'ledger-reader :args nil :effects '((:kind read :target file :risk low))
                       :function (if (eq mode 'async)
                                     (lambda (callback)
                                       (cl-incf executions)
                                       (setq ogent-ledger-file root)
                                       (funcall callback "retained-async")
                                       "not-a-process")
                                   (lambda ()
                                     (cl-incf executions)
                                     (setq ogent-ledger-file root)
                                     (format "retained-%s" mode)))))
           (ogent-tool-registry (list spec)))
      (when (eq mode 'async) (setq spec (plist-put spec :async t)))
      (scorerA-ledger-record
       (format "actual-ledger-failure-%s" mode)
       (format "%s; custom read completes once then points ogent-ledger-file at an existing directory" mode)
       (lambda ()
         (let ((returned
                (pcase mode
                  ('sync (ogent-agent-call "ledger-reader" nil 'json))
                  ('async (ogent-agent-call-async "ledger-reader" nil
                                                (lambda (result) (cl-incf callbacks) (setq payload result)) 'json))
                  ('wrapper (funcall (ogent-tool-execution-wrapper spec 'text))))))
           (list :executions executions :callbacks callbacks :returned returned :callback-result payload)))))))

# Pass 3 handoff — candidate b7b966c

Ogent provides named versioned calls, complete bounded read/search pages,
guarded continuation, read-only batching, async results, live schemas/examples,
model JSON and actual build/test JSON. Completion ledger faults retain tool data
and typed storage recovery; calls keep their original ledger configuration.
Matching raw-byte glob names now produce an explicit failure, and nested Unicode
JSON survives serializer byte representation differences.

The user's second full implementation batch lands directly on `master` inside
`/workspace/ogent`. Baseline is `b3caf9300c7336ef812ed061158f851c5a47ccf7`. The current
candidate is `b7b966c6ac5acc15d15c8ea0c70d81653072cae9`; final promotion is pending.
Eleven primary commits implement eleven tested external behaviors. Followup
repairs do not increase that count. No branch, PR, provider login or inference
was used.

## Implemented behavior

| ID | Implemented behavior | Primary commit | Regression wrapper |
|---|---|---|---|
| R013 | Named approval-aware calls with typed outcomes | `2fbc156` | `audit/regression_tests/R013__named_calls.test.sh` |
| R014 | Bounded file pages with exact long-line continuation | `0829b08` | `audit/regression_tests/R014__structured_reads.test.sh` |
| R015 | Complete discovery through structured file pagination | `a1793a8` | `audit/regression_tests/R015__complete_glob_pages.test.sh` |
| R016 | Follow guarded tool continuations in one call | `e9c9af4` | `audit/regression_tests/R016__continuation_calls.test.sh` |
| R017 | Familiar exact verbs with collision-safe policy resolution | `a2b3922` | `audit/regression_tests/R017__common_verbs.test.sh` |
| R018 | Structured search and bounded real process outcomes | `1cde7ab` | `audit/regression_tests/R018__structured_processes.test.sh` |
| R019 | Async agent calls with one precise terminal callback and ledger | `3ced858` | `audit/regression_tests/R019__async_sdk.test.sh` |
| R020 | Preflighted batches of declared read-only calls | `974eb31` | `audit/regression_tests/R020__read_only_batches.test.sh` |
| R021 | Live callable contracts, executable examples and result schema | `d6263d1` | `audit/regression_tests/R021__live_contracts.test.sh` |
| R022 | Structured JSON contracts for registered model tools | `66bc5e8` | `audit/regression_tests/R022__model_json_contract.test.sh` |
| R023 | Actual build/test JSON with typed failures and recovery | `b974cd7` | `audit/regression_tests/R023__actual_build_reports.test.sh` |

The 33 primary source hunks remain exact. `021cca4` warning hygiene and `ff4e96c`
raw-glob/Unicode corrections are followups, not additional recommendations.

## Measured outcome and verification

**PENDING_FINAL_SCORE_REFRESH** for `b7b966c`: the completed aggregation below
belongs to `ff4e96c`.

Paired aggregation at `ff4e96c` is **complete through shared incremental
validation of retained independent A/B/third readings**, rather than new blind
full readings. Across 19 original surfaces, mean **605.26 → 656.21**, all-surface
median **+11**, ten positively changed originals with median **+77.5**, and nine
originals gain at least 100 points on a dimension. No paired composite regressed.
Six new APIs remain unpaired current-only records; the eleven upgrades share
surfaces and do not establish eleven unique causal numeric gains.

`evidence/pass_3/triangulation/aggregation.json` pins the actual baseline/current
inputs and hashes. `evidence/pass_3/scorerA/incremental_final/validation.json` and
`evidence/pass_3/tiebreaker/refresh-ff4e96c.json` distinguish the `a2fa8ce` judgment source from the
verified `ff4e96c` target. All 59 scorer numerical vectors are retained. Four
fresh probe processes produce 34 records (28 behavior, six identity guards),
including actual-gptel Unicode serialization on both supported runtimes.
219 source citations are checked/refreshed; 353 prior runtime citations and 27
old build reports are explicitly reused with unchanged Makefile/makem bytes.
This is same-model rubric evidence using floored medians/equal-weight composites;
provider throughput and latency were not measured. Historical passes 1/2 retain
all 38 original row values and historical scorecard/heatmap bytes.

Build JSON credit covers historical help/compile/recompile and lint/test/runner
extension coverage. The unchanged `make offline-test` target receives no
build-JSON output credit.

The eleven-wrapper genuine baseline/current refresh for `b7b966c` is running:
**PENDING_FINAL_REGRESSION_PROOF** and **PENDING_FINAL_INTEGRITY_CHECK**. Fixtures
changed for structured raw-root validation, so earlier selector counts cannot be
relabeled as current proof.

All eleven wrappers genuinely fail on `b3caf93` and pass at the prior `ff4e96c`
snapshot; integrity checks verified 22 transcripts/47 input hashes and all six
negative controls. The completed snapshot proof and identities are preserved in
`verification/pass_3/regressions/interim-ff4e96c/`; older `021cca4` proof remains
separate. They do not replace the new candidate refresh. Overlapping selectors
do not establish unique totals or causal score attribution; ERT and R023 shell
counts remain separate units.

`evidence/pass_3/raw_filename_glob/repair_summary.json` records 5/5 compiled boundary
tests and strict scoped compilation/checkdoc/indentation passing on both supported
Emacs versions. Physical byte-FF reproduction genuinely fails on `021cca4`.
Actual-gptel tool FSM/request serialization is exercised offline; provider traffic,
authentication and inference remain zero.

`b7b966c` validates resolved structured glob/search roots before enumeration or
target classification, including explicit/default empty or excluded raw-byte
directories. Glob also validates its reflected pattern. Unsupported values now
produce the same typed refusal in native plist, JSON and async callback-once
paths, while valid Unicode roots retain actual nonempty counts. Two new SDK
regressions fail on real `ff4e96c` on both runtimes. Scoped strict compilation,
checkdoc, canonical indentation and **9/9 compiled boundary tests pass on both
Emacs versions**; `evidence/pass_3/raw_root_contract/` preserves before/after
source evidence and logs. These remain scoped checks, not full native gates.

## Current gates

Round 12 is **NOT_CLEAN** at `ff4e96c`: explicit raw-byte empty/excluded roots
could return native success while JSON later refused them. `b7b966c` repairs that
finding. The earlier round 11 matching-raw-filename finding was repaired in
`ff4e96c`. Review 13 is running; review 14 follows only if 13 is clean:
**PENDING_REVIEW_ROUND_13**, **PENDING_REVIEW_ROUND_14**. The new freeze resets the
clean streak. Earlier CLEAN rounds 9/10 remain historical evidence at `a2fa8ce`.
Round 10 preserves its two initial evidence-fixture allow-rule failures and all
218 final passing executions; these were not product defects or source repairs.

The `a2fa8ce` full native matrix passed **7/8**, with lint failing on warning
hygiene. Its actual results and compressed transcripts are preserved in
`verification/pass_3/native_checks_interim_a2fa8ce.json` and
`native_interim_a2fa8ce/`; these are intermediate evidence. Full candidate native
validation is **PENDING_FINAL_NATIVE_REPORT**. Final artifact validation, delivery
and CI remain **PENDING_ROOT_FINAL_VALIDATION_AND_DELIVERY**.

| Gate | Actual status |
|---|---|
| Source | Candidate `b7b966c6ac5acc15d15c8ea0c70d81653072cae9`; final promotion pending |
| Candidate scoring | Pending root refresh; ff4e96c scores preserved as snapshot evidence |
| Candidate wrapper proof/integrity | Pending; complete ff4e96c proof preserved separately |
| Current clean review streak | Pending reviews 13/14; round 12 was unclean |
| Full native | Pending; earlier a2fa8ce matrix was 7/8, lint failed |
| Delivery and CI | Pending |

## Practical task evidence

The original fresh source-blind exercise completed **9/9** tasks, **7/9** with
the first strategy, in **94** defined public round trips, mostly at `07f775a` with
batch `895bed7`. The seven-line README exercise accounts for 63 calls. Its
preserved summary supports no comparative efficiency claim.

The familiar `b7b966c` replay is complete **9/9** in **89** known-workflow round
trips with identical source SHA and clean start/end path guards. It reuses tasks
and fixtures, so has no fresh first-strategy or comparative efficiency metric.
`agent_simulations/post_pass_3/final_freeze/summary.json` records actual SDK/build
calls, including expected compiler/ERT failure exits with typed source positions.
The prior `ff4e96c` replay is preserved with all 40 files in `replay_ff4e96c/`, and
303 historical artifacts remain byte-identical. GNU fallback and protected
gptel doubles were observed; minimal independent fixtures executed real makem
compilation and ERT. The replay does not certify full native checks or live
provider transport.

## Durable artifacts and next focus

The recommendation/applied ledgers preserve exactly R013…R023, primary commits,
Beads, intended dimensions, precise source hunks and honest attribution. The
playbook records verification and corrections; the ambition record preserves the
mandatory verbatim self-prompt; the readable hunk file reproduces all selected
primary/followup evidence. Archived snapshots remain inspectable.

Persistent crash-resume tokens, dependent batches and transport redesign remain
future feature work. Exact aliases do not execute fuzzy guesses automatically;
undecodable selected filenames fail explicitly. Snapshot guards reject changed
pages without promising filesystem transactions. Provider-backed throughput or
latency was not measured. Any substantive review finding requires a corrected
freeze and rerunning dependent verification.

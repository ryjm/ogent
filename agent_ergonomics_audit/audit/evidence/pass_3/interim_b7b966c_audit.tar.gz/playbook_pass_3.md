# Pass 3 implementation playbook — candidate b7b966c

The user's second full implementation batch lands directly on `master` inside
`/workspace/ogent`. Baseline is `b3caf9300c7336ef812ed061158f851c5a47ccf7`. The current
candidate is `b7b966c6ac5acc15d15c8ea0c70d81653072cae9`; final promotion is pending.
Eleven primary commits implement eleven tested external behaviors. Followup
repairs do not increase that count. No branch, PR, provider login or inference
was used.

## Implemented recommendations

| ID | Implemented behavior | Primary commit | Regression wrapper |
|---|---|---|---|
| R013 | Named approval-aware calls with typed outcomes | `2fbc156` | `audit/regression_tests/R013__named_calls.test.sh` |
| R014 | Bounded file pages with exact long-line continuation | `0829b08` | `audit/regression_tests/R014__structured_reads.test.sh` |
| R015 | Complete discovery through structured file pagination | `a1793a8` | `audit/regression_tests/R015__complete_glob_pages.test.sh` |
| R016 | Follow guarded tool continuations in one call | `e9c9af4` | `audit/regression_tests/R016__continuation_calls.test.sh` |
| R017 | Familiar exact verbs with collision-safe policy resolution | `a2b3922` | `audit/regression_tests/R017__common_verbs.test.sh` |
| R018 | Structured search and bounded real process outcomes | `1cde7ab` | `audit/regression_tests/R018__structured_processes.test.sh` |
| R019 | Async agent calls with one precise terminal callback and ledger | `3ced858` | `audit/regression_tests/R019__async_sdk.test.sh` |
| R020 | Preflighted batches of declared read-only calls | `974eb31` | `audit/regression_tests/R020__read_only_batches.test.sh` |
| R021 | Live callable contracts, executable examples and result schema | `d6263d1` | `audit/regression_tests/R021__live_contracts.test.sh` |
| R022 | Structured JSON contracts for registered model tools | `66bc5e8` | `audit/regression_tests/R022__model_json_contract.test.sh` |
| R023 | Actual build/test JSON with typed failures and recovery | `b974cd7` | `audit/regression_tests/R023__actual_build_reports.test.sh` |

The applied ledger preserves **33 exact selected primary source hunks** plus
full followup SHAs/hunks. Primary hunks compare each commit to its parent.
Retrospective `priority: 0` is explicitly unranked; empty expected-uplift maps
avoid inventing ex ante estimates.

## Paired measurements

**PENDING_FINAL_SCORE_REFRESH** for `b7b966c`: fresh root probes/incremental
provenance are running. The completed aggregation below belongs to `ff4e96c`.

Paired aggregation at `ff4e96c` is **complete through shared incremental
validation of retained independent A/B/third readings**, rather than new blind
full readings. Across 19 original surfaces, mean **605.26 → 656.21**, all-surface
median **+11**, ten positively changed originals with median **+77.5**, and nine
originals gain at least 100 points on a dimension. No paired composite regressed.
Six new APIs remain unpaired current-only records; the eleven upgrades share
surfaces and do not establish eleven unique causal numeric gains.

`evidence/pass_3/triangulation/aggregation.json` pins the actual baseline/current
inputs and hashes. `evidence/pass_3/scorerA/incremental_final/validation.json` and
`evidence/pass_3/tiebreaker/refresh-ff4e96c.json` distinguish the `a2fa8ce` judgment source from the
verified `ff4e96c` target. All 59 scorer numerical vectors are retained. Four
fresh probe processes produce 34 records (28 behavior, six identity guards),
including actual-gptel Unicode serialization on both supported runtimes.
219 source citations are checked/refreshed; 353 prior runtime citations and 27
old build reports are explicitly reused with unchanged Makefile/makem bytes.
This is same-model rubric evidence using floored medians/equal-weight composites;
provider throughput and latency were not measured. Historical passes 1/2 retain
all 38 original row values and historical scorecard/heatmap bytes.

Build JSON credit covers historical help/compile/recompile and lint/test/runner
extension coverage. The unchanged `make offline-test` target receives no
build-JSON output credit.

## Behavioral proof

The eleven-wrapper genuine baseline/current refresh for `b7b966c` is running:
**PENDING_FINAL_REGRESSION_PROOF** and **PENDING_FINAL_INTEGRITY_CHECK**. Fixtures
changed for structured raw-root validation, so earlier selector counts cannot be
relabeled as current proof.

All eleven wrappers genuinely fail on `b3caf93` and pass at the prior `ff4e96c`
snapshot; integrity checks verified 22 transcripts/47 input hashes and all six
negative controls. The completed snapshot proof and identities are preserved in
`verification/pass_3/regressions/interim-ff4e96c/`; older `021cca4` proof remains
separate. They do not replace the new candidate refresh. Overlapping selectors
do not establish unique totals or causal score attribution; ERT and R023 shell
counts remain separate units.

## Correctness repairs

`967eb05` aligns GNU/ripgrep candidate ordering, file-link and directory-link
scope, raw-NUL binary classification and Unicode glob filtering. Classifier and
text reads remain under the existing process timeout/cancel/cleanup owner.

`10f86bb` retains completed data through terminal ledger storage failure, delivers
one callback, preserves an existing `error.tool_error` and exposes recovery that
warns against rerunning completed effects. `a2fa8ce` captures each call's copied
absolute ledger destination and enabled state, binding only recording. Tools and
callbacks retain ambient context; changed settings apply to future calls. Real
completion faults at the captured path retain data and streaming cleanup; failed
start recording prevents effects. Filesystem failure does not guarantee durable
terminal persistence. Focused `a2fa8ce` evidence records 213+4 passing tests per
supported runtime in `evidence/pass_3/ledger_context/results.json`.

`021cca4` fixes batch docstring/checkdoc hygiene and consumes the Unicode
validation serializer result so compiled code retains validation. `ff4e96c`
validates matching structured glob paths before regular-file metadata filtering;
physical undecodable filenames now produce `unsupported_output` instead of an
empty list. Legacy glob behavior keeps its existing optional validation policy.
A shared JSON text helper decodes UTF-8 serializer bytes when Emacs returns an
unibyte string, preserving nested Unicode through result/model transport and
doctor JSON output.

`evidence/pass_3/raw_filename_glob/repair_summary.json` pins scoped strict
compilation, checkdoc, canonical indentation and **5/5 compiled boundary ERT tests
on both Emacs 29.1 and 30.2**, with zero skips/unexpected results. Physical byte-FF
glob reproduction fails against real `021cca4` on both versions. The initial
new-test indentation validation failure remains recorded. Two SDK regressions
cover raw glob sync plist/JSON and callback-once flat/recursive/excluded-Unicode
behavior, plus nested Unicode tool/doctor JSON. An actual-gptel offline regression
covers the tool FSM and provider-request serializer. Offline probes exercise
constructor/process-call/parser/encoder behavior with **zero provider traffic,
authentication or inference**; they do not certify live provider transport.

`b7b966c` validates resolved structured glob/search roots before enumeration or
target classification, including explicit/default empty or excluded raw-byte
directories. Glob also validates its reflected pattern. Unsupported values now
produce the same typed refusal in native plist, JSON and async callback-once
paths, while valid Unicode roots retain actual nonempty counts. Two new SDK
regressions fail on real `ff4e96c` on both runtimes. Scoped strict compilation,
checkdoc, canonical indentation and **9/9 compiled boundary tests pass on both
Emacs versions**; `evidence/pass_3/raw_root_contract/` preserves before/after
source evidence and logs. These remain scoped checks, not full native gates.

## Review and native gates

Round 12 is **NOT_CLEAN** at `ff4e96c`: explicit raw-byte empty/excluded roots
could return native success while JSON later refused them. `b7b966c` repairs that
finding. The earlier round 11 matching-raw-filename finding was repaired in
`ff4e96c`. Review 13 is running; review 14 follows only if 13 is clean:
**PENDING_REVIEW_ROUND_13**, **PENDING_REVIEW_ROUND_14**. The new freeze resets the
clean streak. Earlier CLEAN rounds 9/10 remain historical evidence at `a2fa8ce`.
Round 10 preserves its two initial evidence-fixture allow-rule failures and all
218 final passing executions; these were not product defects or source repairs.

The `a2fa8ce` full native matrix passed **7/8**, with lint failing on warning
hygiene. Its actual results and compressed transcripts are preserved in
`verification/pass_3/native_checks_interim_a2fa8ce.json` and
`native_interim_a2fa8ce/`; these are intermediate evidence. Full candidate native
validation is **PENDING_FINAL_NATIVE_REPORT**. Final artifact validation, delivery
and CI remain **PENDING_ROOT_FINAL_VALIDATION_AND_DELIVERY**.

## Practical task evidence

The original fresh source-blind exercise completed **9/9** tasks, **7/9** with
the first strategy, in **94** defined public round trips, mostly at `07f775a` with
batch `895bed7`. The seven-line README exercise accounts for 63 calls. Its
preserved summary supports no comparative efficiency claim.

The familiar `b7b966c` replay is complete **9/9** in **89** known-workflow round
trips with identical source SHA and clean start/end path guards. It reuses tasks
and fixtures, so has no fresh first-strategy or comparative efficiency metric.
`agent_simulations/post_pass_3/final_freeze/summary.json` records actual SDK/build
calls, including expected compiler/ERT failure exits with typed source positions.
The prior `ff4e96c` replay is preserved with all 40 files in `replay_ff4e96c/`, and
303 historical artifacts remain byte-identical. GNU fallback and protected
gptel doubles were observed; minimal independent fixtures executed real makem
compilation and ERT. The replay does not certify full native checks or live
provider transport.

## Using the implemented surfaces

Use live describe/schema/capabilities and the guide for call shapes. Use
`ogent-agent-call` for named policy-aware execution, `ogent-agent-next` for returned
guarded continuations, `ogent-agent-call-async` for callback delivery and
`ogent-agent-batch` for up to 20 declared read-only calls. Select JSON explicitly.
Actual build JSON uses `makem.sh --json` or `make TASK format=json`; doctor remains
a separate surface. Read the regression recorder's help, bind exact freeze/tool
paths from its manifests and use actual supported Emacs/local dependencies.

Prior `10f86bb` and `a2fa8ce` scoring/audit snapshots remain archived with hash
indexes in `evidence/pass_3/interim_*_archive.json`. The `021cca4` proof archive
records its complete files and hashes. `evidence/pass_3/source_fixture_archives.json`
records 12 archives/408 source and fixture members. Raw `.el` copies stay ignored
because makem discovers tracked files with `git ls-files`. Ledger-context old
modules remain losslessly archived with `baseline-source-archive.json` hashes.

Persistent crash-resume tokens, dependent batches and transport redesign remain
future feature work. Exact aliases do not execute fuzzy guesses automatically;
undecodable selected filenames fail explicitly. Snapshot guards reject changed
pages without promising filesystem transactions. Provider-backed throughput or
latency was not measured. Any substantive review finding requires a corrected
freeze and rerunning dependent verification.
